# Writing a JA plugin

> Part of the JA Framework documentation. Start with `README.md` for the CMS itself.

A plugin is a folder in `ja-plugins/` with one PHP class (the bundled `ja-security-suite` is a good worked example). It can add admin screens, front-end routes,
shortcodes, settings fields, CSS/JS and hook into events. Plugins are optional, and the framework keeps
working if one breaks.

---

## 1. Layout and naming

```text
ja-plugins/ja-events/
  ja-events.php     required — defines the class JA\Plugins\Events
  plugin.json       optional — name, version, description, author
  assets/           optional — CSS/JS, queued with Assets
```

- The folder id uses lowercase letters, numbers and hyphens. The main file is `<id>/<id>.php`.
- The class is `JA\Plugins\<StudlyName>`: the id without a leading `ja-`, in StudlyCase.
  `ja-events` → `Events`, `ja-my-plugin` → `MyPlugin`, `rediscache` → `Rediscache`.
- The **admin slug** is the id without a leading `ja-` (`ja-events` → `events`). The admin screen opens at
  `?view=<slug>`.

`plugin.json` (every field optional — the Plugins screen falls back to the folder name):

```json
{ "name": "Events", "version": "1.0.0", "description": "Event listings.", "author": "You" }
```

**Installing:** upload a zip on the Plugins screen. It must contain exactly one folder with
`<id>/<id>.php` inside. It is refused if that folder already exists, if the id is a core plugin, or if any
file path is unsafe. Enable it from the Installed tab.

Core plugins (`ja-media`, `ja-menus`, `ja-themes`, `ja-plugins`, `ja-settings`) are always on and cannot be
disabled, uninstalled or replaced.

---

## 2. The class

Every method is optional and static.

| Method | When it runs |
|---|---|
| `init()` | on every request while the plugin is enabled (see section 3) |
| `onActivate($db)` | when enabled. Create tables here. **Throw** to refuse to enable; the message is shown |
| `onDeactivate($db)` | when disabled |
| `onUninstall($db)` | just before the folder is deleted. Drop tables here |
| `renderAdmin($db, $csrf)` | returns the HTML for `?view=<slug>` |
| `handleSave($db, $post)` | receives POSTs from that screen (section 4) |
| `bootFrontend($db)` | makes the plugin selectable as the **homepage plugin** in Settings |

`$db` is a PDO connection (exceptions on, associative fetch, real prepared statements).

---

## 3. When plugins load

- **Admin panel:** core plugins, then every enabled plugin.
- **Public site:** every enabled plugin (core plugins are not loaded).
- **Login page:** every enabled plugin, so a plugin can block or throttle requests there too.

So `init()` runs a lot — keep it light, and only register what each context needs. To do something only in
the admin, check for it:

```php
$in_admin = strpos(str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? ''), '/ja-admin/') !== false;
```

A plugin that throws from `init()` is skipped and logged instead of taking the site down, so you can still
reach the admin to disable it.

---

## 4. Admin screens and forms

1. Add a sidebar entry in `init()`: `AdminMenu::add('Events', 'events', '📅');` — the slug must match the
   plugin's slug.
2. `renderAdmin($db, $csrf)` returns an HTML string. The core wraps it in the admin layout.
3. **Every form must POST with a CSRF field.** Include `csrf` (the `$csrf` passed in) and a `ja_action`
   value that names what the form does:

   ```php
   $html  = "<form method='POST' class='ja-card'>";
   $html .= "<input type='hidden' name='csrf' value='" . htmlspecialchars($csrf) . "'>";
   $html .= "<input type='hidden' name='ja_action' value='events_save'>";
   // …fields…
   $html .= "<button type='submit' class='ja-btn ja-btn-primary'>Save</button></form>";
   ```
4. `handleSave($db, $post)` receives `$_POST`. Check `$post['ja_action']`. What you return is shown to the admin:
   - a **string** → shown as the message. Start it with `✅` for success or `❌` for an error
   - `false` → "Could not save changes."
   - anything else → "Changes saved!"
5. **Never change data from a link (GET).** For one-click actions such as Delete or Enable, use a POST button:

   ```php
   use JA\Core\AdminUI;

   // postButton($label, $action, $fields, $csrf, $class = '', $confirm = '', $title = '')
   AdminUI::postButton('Delete', 'events_delete', ['id' => $id], $csrf, 'action-delete', 'Delete this event?');
   ```

   It posts back to the current URL, so `?view=…&tab=…` is preserved. `$label` is output as-is, so pass a
   literal, never user input.
6. **Reserved action names** are handled by the core before your plugin sees them. Prefix your own, e.g.
   `events_save`, and don't reuse: `plugin_toggle`, `plugin_uninstall`, `theme_activate`, `theme_delete`,
   `media_delete`, `page_delete`.

### Adding fields to the Settings screen

```php
if (class_exists('JA\\Plugins\\Settings', false)) {   // only loaded in the admin
    Settings::registerField('events_per_page', 'Events per page', 'text', 'Default 10', '10');
}
```

`registerField($key, $label, $type = 'text', $help = '', $default = '')`. Types: `text`, `textarea`,
`checkbox` (stored `1`/`0`). Keys use lowercase letters, numbers and underscores — prefix them with your
plugin name. Core option names are rejected. Read the value anywhere with `Options::get('events_per_page')`.

---

## 5. The public site

**Routes** — claim a URL from `init()`:

```php
use JA\Core\Router;

Router::add('/events', [self::class, 'index']);
Router::add('/events/{slug}', [self::class, 'show']);          // {slug} arrives in $params
Router::add('/events/join', [self::class, 'join'], 'POST');    // third argument: HTTP method

public static function show(array $params, $db) {
    return ['title' => 'An event', 'content' => '<p>…</p>'];
}
```

A handler returns a **page array** (`title`, `content`, optionally `hide_title`) for the theme to render,
`null` ("I handled it myself"), or `false` ("not mine, keep looking"). Routes are tried in the order
registered, before the homepage plugin's fallback.

**Shortcodes** — `[events limit="5"]` in page content:

```php
use JA\Core\Shortcodes;

Shortcodes::register('events', function (array $attrs) {
    return '<ul>…</ul>';           // $attrs = ['limit' => '5']
});
```

**Other helpers:** `SiteMenus::get('primary')` returns menu items for a theme location; `Content::set($page)`
sets the page the theme renders (route handlers do this for you).

---

## 6. CSS and JS

Put files in `ja-plugins/<id>/assets/` and queue them. They are printed by the theme's (or admin's)
`head` / `body_end` hooks, once per handle. Don't echo `<style>` or `<script>` blocks, and pass data to your
script with `data-*` attributes.

```php
use JA\Core\Assets;

Assets::style('events', Assets::pluginUrl('ja-events', 'assets/events.css'));                 // public site
Assets::script('events-js', Assets::pluginUrl('ja-events', 'assets/events.js'));              // footer, public site
Assets::style('events-admin', Assets::pluginUrl('ja-events', 'assets/admin.css'), 'admin');   // admin screens
Assets::script('events-admin-js', $url, true, 'admin');   // script($handle, $url, $in_footer = true, $context = 'front')
```

`pluginUrl()` adds a `?v=` timestamp so browsers pick up changes straight away. Use the `'admin'` context
for anything on an admin screen.

---

## 7. Hooks

Register with `Hooks::action($slot, $callback, $priority = 10)` or `Hooks::filter(...)`. A filter callback
receives the value and must return it (changed or not).

**Actions** (`Hooks::fire`):

| Slot | Arguments | Fired |
|---|---|---|
| `head`, `body_start`, `body_end` | — | by the theme, in the page |
| `content_before`, `content_after` | `$ja_page` | around the page content |
| `admin_head`, `admin_body_end` | — | by the admin layout |
| `frontend_route` | `$uri, $db` | when no `Router` route matched |
| `page_save` | `array` (`id`, `title`, `slug`, `is_home`, `in_menu`, `status`) | after a page is saved |
| `media_upload` | `$id, $filename` | after an upload |
| `options_update` | `$name, $value` | whenever an option is saved |
| `admin_action` | `$action, $id, $result_message` | after a one-click admin action (enable/disable/uninstall plugin, activate/delete theme, delete media or page) |
| `login_link_requested` | `$email, $issued` | someone asks for a login link |
| `login_success` | `$email` | a login link is used successfully |
| `login_failed` | `$reason` | an invalid or expired link is used |

**Filters** (`Hooks::apply`):

| Slot | Arguments | Purpose |
|---|---|---|
| `page_title` | `$title` | change a page title before display |
| `page_content` | `$html` | change page content before display |
| `menu_items` | `$items, $slot` | change menu items |
| `login_allowed` | `$allowed, $email` | return `false` to refuse a login link request |

---

## 8. Data

- Use `JA\Core\Database::getConnection()` (the same PDO as `$db`). Always use **prepared statements**.
- Create your tables in `onActivate` with `CREATE TABLE IF NOT EXISTS`, name them `ja_<plugin>_…`, and drop
  them in `onUninstall`.
- Read and write settings with `Options::get($name, $default)` and `Options::set($name, $value)`.
  `Options::set()` also invalidates any options cache and fires `options_update`.
  If you ever change `ja_options` with raw SQL, call `Options::forgetCache()` afterwards.

### Options cache drivers

The framework ships no cache. A plugin can supply one by implementing `JA\Core\OptionsBackend` and
installing `ja-content/options-cache.php`, which the core loads at startup. The admin panel, login page
and command line never use it. See `CACHE.md`.

---

## 9. Full example

```php
<?php
namespace JA\Plugins;

use JA\Core\{AdminMenu, AdminUI, Assets, Database, Router, Shortcodes};

class Events {

    public static function init() {
        AdminMenu::add('Events', 'events', '📅');
        Router::add('/events', [self::class, 'index']);
        Shortcodes::register('events', [self::class, 'shortcode']);
        Assets::style('events', Assets::pluginUrl('ja-events', 'assets/events.css'));

        if (class_exists('JA\\Plugins\\Settings', false)) {
            Settings::registerField('events_per_page', 'Events per page', 'text', '', '10');
        }
    }

    public static function onActivate($db) {
        $db->exec("CREATE TABLE IF NOT EXISTS ja_events_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }

    public static function onUninstall($db) {
        $db->exec("DROP TABLE IF EXISTS ja_events_items");
    }

    public static function index(array $params, $db) {
        $rows = $db->query("SELECT title FROM ja_events_items ORDER BY id DESC")->fetchAll();
        $html = '<ul>';
        foreach ($rows as $row) $html .= '<li>' . htmlspecialchars($row['title']) . '</li>';
        return ['title' => 'Events', 'content' => $html . '</ul>'];
    }

    public static function shortcode(array $attrs) {
        return '<p>Upcoming events…</p>';
    }

    public static function renderAdmin($db, $csrf = '') {
        $h = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
        $html  = "<h1 class='ja-page-header'>Events</h1><div class='ja-card'>";
        $html .= "<form method='POST'><input type='hidden' name='csrf' value='" . $h($csrf) . "'>";
        $html .= "<input type='hidden' name='ja_action' value='events_add'>";
        $html .= "<input type='text' name='title' class='ja-input' placeholder='Event title'>";
        $html .= "<button type='submit' class='ja-btn ja-btn-primary'>Add</button></form>";

        foreach ($db->query("SELECT id, title FROM ja_events_items ORDER BY id DESC")->fetchAll() as $row) {
            $html .= "<p>" . $h($row['title']) . ' '
                   . AdminUI::postButton('Delete', 'events_delete', ['id' => $row['id']], $csrf, 'ja-btn ja-btn-danger ja-btn-sm', 'Delete this event?')
                   . "</p>";
        }
        return $html . "</div>";
    }

    public static function handleSave($db, $post) {
        $action = $post['ja_action'] ?? '';

        if ($action === 'events_add') {
            $title = trim((string) ($post['title'] ?? ''));
            if ($title === '') return '❌ Enter a title.';
            $db->prepare("INSERT INTO ja_events_items (title) VALUES (?)")->execute([$title]);
            return '✅ Event added.';
        }
        if ($action === 'events_delete') {
            $db->prepare("DELETE FROM ja_events_items WHERE id = ?")->execute([(int) ($post['id'] ?? 0)]);
            return '✅ Event deleted.';
        }
        return true;
    }
}
```

---

## 10. Checklist

1. Folder id and file name match (`ja-events/ja-events.php`), and the class name follows the naming rule.
2. Escape everything you print with `htmlspecialchars()`; use prepared statements for every query.
3. Every form has the `csrf` field and a prefixed `ja_action`. Changes only ever happen on POST.
4. `init()` is cheap and only registers what it needs; admin-only code is guarded.
5. CSS/JS goes through `Assets`, in the right context.
6. Create tables in `onActivate`, drop them in `onUninstall`, and prefix table and option names.
7. Test enabling, disabling and uninstalling, and that a thrown error in `onActivate` shows a clear message.
