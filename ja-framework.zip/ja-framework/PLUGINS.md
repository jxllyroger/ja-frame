# Writing a JA plugin

## Layout

```
ja-plugins/ja-events/
  ja-events.php     required — defines the class JA\Plugins\Events
  plugin.json       optional — name, version, description, author
```

Folder names use lowercase letters, numbers and hyphens. The class name is the folder
name without a leading `ja-`, in StudlyCase: `ja-events` → `Events`, `ja-my-plugin` → `MyPlugin`.
Install by uploading a zip containing that one folder; enable it from **Plugins**.

## The class

```php
<?php
namespace JA\Plugins;

use JA\Core\{Hooks, Router, Assets, AdminMenu, Shortcodes};

class Events {
    public static function init() {                    // every request while enabled
        AdminMenu::add('Events', 'events', '📅');       // admin sidebar → ?view=events
        Router::add('/events', [self::class, 'index']);
        Router::add('/events/{slug}', [self::class, 'show']);
        Assets::style('events', Assets::pluginUrl('ja-events', 'events.css'));
        Settings::registerField('events_per_page', 'Events per page', 'text', '', '10');
        Shortcodes::register('events', fn($a) => '<ul>…</ul>');
    }

    public static function onActivate($db)   {}  // create tables; throw to abort enabling
    public static function onDeactivate($db) {}
    public static function onUninstall($db)  {}  // drop tables; runs before the folder is deleted

    public static function renderAdmin($db, $csrf = '') { return '<h1>Events</h1>'; }
    public static function handleSave($db, $post)       { return true; }
    // handleSave returns: false = failed, a string = message to show, anything else = saved

    public static function index(array $params, $db) {
        return ['title' => 'Events', 'content' => '<p>…</p>', 'is_html' => true];
    }
}
```

Route handlers return a page array, `null` ("I handled it"), or `false` ("not mine").

## Extension points

| API | Purpose |
|---|---|
| `Router::add($pattern, $handler)` | Front-end URLs, with `{param}` placeholders |
| `Assets::style()/script()` | Queue CSS/JS (`'admin'` context for the admin) |
| `Settings::registerField()` | Add a field to the Settings screen |
| `Hooks::action()/filter()` | `head`, `body_end`, `content_before`, `page_content`, … |
| `Shortcodes::register()` | `[tag attr="x"]` in page content |
| `AdminMenu::add()` | Admin sidebar entry |
| `Content::set()` | Set the page the theme renders (route handlers do this for you) |
| `SiteMenus::get('primary')` | Menu items for a theme location |
| `AdminUI::postButton()` | A one-button POST form (CSRF included) for row actions |
| `bootFrontend($db)` | Makes the plugin selectable as the homepage plugin |

Core plugins (media, menus, themes, plugins, settings) are listed in one place,
`JA\Core\Plugins::$required`, and cannot be disabled, uninstalled or replaced.
A plugin that throws in `init()` is skipped and logged instead of breaking the site.

## Notes

- `Hooks` now only does actions and filters. The old `Hooks::add_menu_item`, `set_content`,
  `get_menu`, `register_shortcode`, `do_shortcode`, … still work as deprecated delegates.
- State-changing links must be POST: use `AdminUI::postButton()` and handle the action in your
  `handleSave()`. Don't put the CSRF token in a URL.
- Put plugin CSS/JS in `ja-plugins/<id>/assets/` and queue it with `Assets::style()/script()`
  (the `'admin'` context for admin screens) instead of echoing `<style>`/`<script>` blocks.
  Pass data to your script with `data-*` attributes.

## Security and audit hooks

| Hook | Arguments | Fired when |
|---|---|---|
| `login_link_requested` (action) | `$email, $issued` | someone asks for a login link |
| `login_success` (action) | `$email` | a login link is used successfully |
| `login_failed` (action) | `$reason` | an invalid or expired link is used |
| `admin_action` (action) | `$action, $id, $result_message` | a one-click admin action runs (enable/disable/uninstall plugin, activate/delete theme, delete media or page) |
| `options_update` (action) | `$name, $value` | any option is saved |
| `login_allowed` (filter) | `$allowed, $email` | before a login link is issued — return `false` to refuse |

Plugins are loaded on the login page, so a plugin can block or throttle requests there too.
