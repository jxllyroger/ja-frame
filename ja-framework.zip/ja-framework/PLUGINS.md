# Writing a JA plugin

## Layout

```
ja-plugins/ja-events/
  ja-events.php     required — defines the class JA\Plugins\Events
  plugin.json       optional — name, version, description, author
```

Folder names use lowercase letters, numbers and hyphens. The class name is the folder
name without a leading `ja-`, in StudlyCase: `ja-events` → `Events`, `ja-my-plugin` → `MyPlugin`.
Install by uploading a zip containing that one folder; enable it from **Plugins**.

## The class

```php
<?php
namespace JA\Plugins;

use JA\Core\{Hooks, Router, Assets};

class Events {
    public static function init() {                    // every request while enabled
        Hooks::add_menu_item('Events', 'events', '📅'); // admin sidebar → ?view=events
        Router::add('/events', [self::class, 'index']);
        Router::add('/events/{slug}', [self::class, 'show']);
        Assets::style('events', Assets::pluginUrl('ja-events', 'events.css'));
        Settings::registerField('events_per_page', 'Events per page', 'text', '', '10');
        Hooks::register_shortcode('events', fn($a) => '<ul>…</ul>');
    }

    public static function onActivate($db)   {}  // create tables; throw to abort enabling
    public static function onDeactivate($db) {}
    public static function onUninstall($db)  {}  // drop tables; runs before the folder is deleted

    public static function renderAdmin($db, $csrf = '') { return '<h1>Events</h1>'; }
    public static function handleSave($db, $post)       { return true; }
    // handleSave returns: false = failed, a string = message to show, anything else = saved

    public static function index(array $params, $db) {
        return ['title' => 'Events', 'content' => '<p>…</p>', 'is_html' => true];
    }
}
```

Route handlers return a page array, `null` ("I handled it"), or `false` ("not mine").

## Extension points

| API | Purpose |
|---|---|
| `Router::add($pattern, $handler)` | Front-end URLs, with `{param}` placeholders |
| `Assets::style()/script()` | Queue CSS/JS (`'admin'` context for the admin) |
| `Settings::registerField()` | Add a field to the Settings screen |
| `Hooks::action()/filter()` | `head`, `body_end`, `content_before`, `page_content`, … |
| `Hooks::register_shortcode()` | `[tag attr="x"]` in page content |
| `Hooks::add_menu_item()` | Admin sidebar entry |
| `bootFrontend($db)` | Makes the plugin selectable as the homepage plugin |

Core plugins (media, menus, themes, plugins, settings) are listed in one place,
`JA\Core\Plugins::$required`, and cannot be disabled, uninstalled or replaced.
A plugin that throws in `init()` is skipped and logged instead of breaking the site.
