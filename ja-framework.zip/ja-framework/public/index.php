<?php
/**
 * JA Framework - Public Entry Point
 */
 
if (!file_exists(__DIR__ . '/../.env') && file_exists(__DIR__ . '/install.php')) {
    header('Location: /install.php');
    exit;
}
 
require_once __DIR__ . '/../ja-core/autoload.php';

use JA\Core\Database;
use JA\Core\Hooks;
use JA\Core\Options;
use JA\Core\Plugins;

try {
    $db = Database::getConnection();

    // Boot only user-enabled plugins
    Plugins::loadFrontend();

    // Ask the configured frontend plugin to set page content
    $frontend_plugin = Options::get('frontend_plugin', '');
    if ($frontend_plugin) {
        $clean_name = ucfirst(str_replace('ja-', '', $frontend_plugin));
        $class_name = 'JA\\Plugins\\' . $clean_name;
        if (class_exists($class_name, false) && method_exists($class_name, 'bootFrontend')) {
            $class_name::bootFrontend($db);
        }
    }

    $ja_page = Hooks::get_content();

    if (!$ja_page) {
        $ja_page = [
            'title'   => 'Welcome',
            'content' => '<p>Everything is modular.</p>',
            'is_html' => true,
        ];
    }

    // Load the active theme, fall back to ja-clean
    $active_theme = Options::get('active_theme', 'ja-clean');
    $theme_file   = JA_ROOT . '/ja-themes/' . basename($active_theme) . '/index.php';
    if (!file_exists($theme_file)) {
        $theme_file = JA_ROOT . '/ja-themes/ja-clean/index.php';
    }

    require_once $theme_file;

} catch (Exception $e) {
    die('JA Framework Boot Error: ' . $e->getMessage());
}
