<?php
/**
 * JA Framework - Public Entry Point
 */
 
if (!file_exists(__DIR__ . '/../.env') && file_exists(__DIR__ . '/install.php')) {
    header('Location: /install.php');
    exit;
}
 
require_once __DIR__ . '/../ja-core/autoload.php';

use JA\Core\Database;
use JA\Core\Hooks;
use JA\Core\Options;
use JA\Core\Plugins;
use JA\Core\Router;
use JA\Core\Content;
use JA\Core\Assets;

try {
    $db = Database::getConnection();

    // Plugin CSS/JS queued with Assets:: is printed by the theme's head/body_end hooks
    Assets::boot();

    // Boot only user-enabled plugins (they register routes, hooks and assets in init())
    Plugins::loadFrontend();

    // 1) Routes registered with Router::add()
    // 2) Otherwise, any plugin listening on the frontend_route action
    if (!Router::dispatch($db)) {
        Hooks::fire('frontend_route', $_SERVER['REQUEST_URI'] ?? '/', $db);
    }

    // If nobody claimed it, fall back to the configured frontend plugin
    if (!Content::get()) {
        $frontend_plugin = Options::get('frontend_plugin', '');
        if ($frontend_plugin && Plugins::isValidId($frontend_plugin) && Plugins::isActive($frontend_plugin)) {
            $class_name = Plugins::fqcn($frontend_plugin);
            if (class_exists($class_name, false) && method_exists($class_name, 'bootFrontend')) {
                $class_name::bootFrontend($db);
            }
        }
    }

    $ja_page = Content::get();

    if (!$ja_page) {
        $ja_page = [
            'title'   => 'Welcome',
            'content' => '<p>Everything is modular.</p>',
            'is_html' => true,
        ];
    }

    // Load the active theme, fall back to ja-clean
    $active_theme = Options::get('active_theme', 'ja-clean');
    $theme_file   = JA_ROOT . '/ja-themes/' . basename($active_theme) . '/index.php';
    if (!file_exists($theme_file)) {
        $theme_file = JA_ROOT . '/ja-themes/ja-clean/index.php';
    }

    require_once $theme_file;

} catch (Exception $e) {
    die('JA Framework Boot Error: ' . $e->getMessage());
}
