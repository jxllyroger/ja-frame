<?php
/**
 * JA Framework - Installer
 * Place at public/install.php and access via browser.
 * Deletes itself on successful installation.
 */

define('JA_ROOT', dirname(__DIR__));

// -------------------------------------------------------
// Guard: already installed?
// -------------------------------------------------------
if (file_exists(JA_ROOT . '/.env')) {
    die(render_page('Already installed', '
        <div class="notice error">
            <strong>JA Framework is already installed.</strong>
            A <code>.env</code> file already exists. If you need to reinstall,
            remove <code>.env</code> from the site root first.
        </div>
    '));
}

// -------------------------------------------------------
// Ensure uploads dir exists so the writable test is accurate
// -------------------------------------------------------
$uploads_dir = __DIR__ . '/uploads';
if (!is_dir($uploads_dir)) {
    @mkdir($uploads_dir, 0755, true);
}
clearstatcache(true, $uploads_dir);
clearstatcache(true, __DIR__);

// -------------------------------------------------------
// Requirements check
// -------------------------------------------------------
$reqs = [
    'PHP 8.1+' => version_compare(PHP_VERSION, '8.1.0', '>='),
    'PDO MySQL' => extension_loaded('pdo_mysql'),
    'ZipArchive' => extension_loaded('zip'),
    'finfo'     => extension_loaded('fileinfo'),
    '.env writable' => is_writable(JA_ROOT),
    'uploads writable' => is_writable($uploads_dir) || is_writable(__DIR__),
];

$req_fail = array_filter($reqs, fn($v) => !$v);

// -------------------------------------------------------
// Timezones list (common set)
// -------------------------------------------------------
$timezones = DateTimeZone::listIdentifiers();

// -------------------------------------------------------
// Handle POST
// -------------------------------------------------------
$errors  = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db_host    = trim($_POST['db_host']    ?? 'localhost');
    $db_name    = trim($_POST['db_name']    ?? '');
    $db_user    = trim($_POST['db_user']    ?? '');
    $db_pass    = $_POST['db_pass']         ?? '';
    $site_name  = trim($_POST['site_name']  ?? 'My Site');
    $slogan     = trim($_POST['slogan']     ?? '');
    $site_lang  = trim($_POST['site_lang']  ?? 'en');
    $timezone   = trim($_POST['timezone']   ?? 'UTC');
    $admin_email = strtolower(trim($_POST['admin_email'] ?? ''));

    // Validate
    if (!$db_name)    $errors[] = 'Database name is required.';
    if (!$db_user)    $errors[] = 'Database user is required.';
    if (!$admin_email || !filter_var($admin_email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'A valid admin email is required.';
    }
    if (!in_array($timezone, $timezones)) {
        $errors[] = 'Invalid timezone selected.';
    }

    if (empty($errors) && empty($req_fail)) {
        // Test DB connection and select database
        try {
            $dsn = "mysql:host={$db_host};dbname={$db_name};charset=utf8mb4";
            $pdo = new PDO($dsn, $db_user, $db_pass, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            $errors[] = 'Database connection failed: ' . $e->getMessage();
        }

        if (empty($errors)) {
            try {
                // -----------------------------------------------
                // Create tables
                // -----------------------------------------------
                $pdo->exec("
                    CREATE TABLE IF NOT EXISTS `ja_auth_tokens` (
                        `id`         int(11)      NOT NULL AUTO_INCREMENT,
                        `email`      varchar(255) NOT NULL,
                        `token`      varchar(64)  NOT NULL,
                        `expires_at` datetime     NOT NULL,
                        `used`       tinyint(1)   DEFAULT 0,
                        `used_at`    datetime     DEFAULT NULL,
                        PRIMARY KEY (`id`),
                        UNIQUE KEY `idx_token`        (`token`),
                        KEY        `idx_expires_used` (`expires_at`, `used`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                ");

                $pdo->exec("
                    CREATE TABLE IF NOT EXISTS `ja_media` (
                        `id`            int(11)      NOT NULL AUTO_INCREMENT,
                        `filename`      varchar(255) NOT NULL,
                        `original_name` varchar(255) NOT NULL,
                        `file_type`     varchar(50)  DEFAULT NULL,
                        `file_size`     int(11)      DEFAULT NULL,
                        `uploaded_at`   timestamp    NULL DEFAULT current_timestamp(),
                        PRIMARY KEY (`id`),
                        KEY `idx_uploaded_at` (`uploaded_at`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                ");

                $pdo->exec("
                    CREATE TABLE IF NOT EXISTS `ja_options` (
                        `option_name`  varchar(100) NOT NULL,
                        `option_value` text         DEFAULT NULL,
                        PRIMARY KEY (`option_name`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                ");

                $pdo->exec("
                    CREATE TABLE IF NOT EXISTS `ja_pages` (
                        `id`         int(11)      NOT NULL AUTO_INCREMENT,
                        `title`      varchar(255) NOT NULL,
                        `slug`       varchar(255) NOT NULL,
                        `content`    longtext     DEFAULT NULL,
                        `is_home`    tinyint(1)   DEFAULT 0,
                        `in_menu`    tinyint(1)   DEFAULT 0,
                        `hide_title` tinyint(1)   NOT NULL DEFAULT 0,
                        `status`     varchar(20)  DEFAULT 'published',
                        `updated_at` timestamp    NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
                        PRIMARY KEY (`id`),
                        UNIQUE KEY `idx_slug`    (`slug`),
                        KEY        `idx_is_home` (`is_home`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                ");

                // -----------------------------------------------
                // Seed default options
                // -----------------------------------------------
                $options = [
                    'site_name'       => $site_name,
                    'site_slogan'     => $slogan,
                    'site_lang'       => $site_lang,
                    'timezone'        => $timezone,
                    'active_theme'    => 'ja-clean',
                    'site_logo'       => '',
                    'site_favicon'    => '',
                    'active_plugins'  => '["ja-pages"]',
                    'frontend_plugin' => 'ja-pages',
                    'admin_email'     => $admin_email,
                    'admin_emails'    => json_encode([$admin_email]),
                    'menus'           => json_encode([
                        'menu_primary_0001' => [
                            'name'    => 'Primary',
                            'enabled' => true,
                            'items'   => [['label' => 'Home', 'url' => '/']],
                        ],
                    ]),
                    'menu_slot_primary' => 'menu_primary_0001',
                    'menu_slot_footer'  => '',
                ];

                $stmt = $pdo->prepare(
                    "INSERT INTO `ja_options` (`option_name`, `option_value`) VALUES (?, ?)
                     ON DUPLICATE KEY UPDATE `option_value` = VALUES(`option_value`)"
                );
                foreach ($options as $k => $v) {
                    $stmt->execute([$k, $v]);
                }

                // -----------------------------------------------
                // Create ja_users table
                // -----------------------------------------------
                $pdo->exec("
                    CREATE TABLE IF NOT EXISTS `ja_users` (
                        `id`           int(11)      NOT NULL AUTO_INCREMENT,
                        `email`        varchar(255) NOT NULL,
                        `display_name` varchar(100) DEFAULT NULL,
                        `avatar`       varchar(255) DEFAULT NULL,
                        `created_at`   timestamp    NULL DEFAULT current_timestamp(),
                        PRIMARY KEY (`id`),
                        UNIQUE KEY `idx_email` (`email`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                ");

                // Seed admin user row
                $pdo->prepare("INSERT IGNORE INTO ja_users (email, display_name) VALUES (?, 'Admin')")
                    ->execute([$admin_email]);
                $pdo->exec("
                    INSERT IGNORE INTO `ja_pages` (`title`, `slug`, `content`, `is_home`, `in_menu`, `status`)
                    VALUES ('Home', 'home', '<p>Welcome to {$site_name}!</p>', 1, 0, 'published')
                ");

                // -----------------------------------------------
                // Create uploads directory structure
                // -----------------------------------------------
                if (!is_dir($uploads_dir)) mkdir($uploads_dir, 0755, true);

                // -----------------------------------------------
                // Write .env
                // -----------------------------------------------
                $env = implode("\n", [
                    '# JA Framework Configuration',
                    'DB_HOST=' . $db_host,
                    'DB_NAME=' . $db_name,
                    'DB_USER=' . $db_user,
                    'DB_PASS=' . $db_pass,
                    '',
                    '# Auth Settings',
                    'MAGIC_LINK_TTL=900 # 15 Minutes',
                    'SITE_URL=auto      # Set to auto for dynamic detection',
                    '',
                ]);
                file_put_contents(JA_ROOT . '/.env', $env);

                $success = true;

                // -----------------------------------------------
                // Self-delete
                // -----------------------------------------------
                register_shutdown_function(function() {
                    @unlink(__FILE__);
                });

            } catch (PDOException $e) {
                $errors[] = 'Setup failed: ' . $e->getMessage();
            }
        }
    }
}

// -------------------------------------------------------
// Helpers
// -------------------------------------------------------
function esc($s) { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

function render_page($title, $body) {
    return <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{$title} — JA Framework Installer</title>
<style>
*,*::before,*::after{box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;font-size:15px;line-height:1.6;color:#1a1a1a;background:#f0f0ee;margin:0;padding:20px}
.wrap{max-width:640px;margin:40px auto}
.logo{font-size:13px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:#888;margin-bottom:24px}
h1{font-size:24px;font-weight:600;margin:0 0 6px}
.sub{color:#666;font-size:14px;margin:0 0 32px}
.card{background:#fff;border:1px solid #e5e5e3;border-radius:10px;padding:24px;margin-bottom:20px}
.card h2{margin:0 0 18px;font-size:16px;font-weight:600}
label{display:block;font-size:13px;font-weight:500;color:#555;margin-bottom:5px}
input,select{display:block;width:100%;padding:10px 12px;font-size:14px;font-family:inherit;color:#1a1a1a;background:#fafafa;border:1px solid #ddd;border-radius:7px;margin-bottom:16px;-webkit-appearance:none;appearance:none}
input:focus,select:focus{outline:none;border-color:#666;background:#fff;box-shadow:0 0 0 3px rgba(0,0,0,.06)}
select{background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%23666' stroke-width='1.5' fill='none' stroke-linecap='round'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 12px center;padding-right:32px}
button{display:block;width:100%;padding:12px;font-size:15px;font-weight:500;font-family:inherit;background:#111;color:#fff;border:none;border-radius:7px;cursor:pointer;transition:background .15s;margin-top:8px}
button:hover{background:#333}
.notice{padding:12px 16px;border-radius:7px;font-size:14px;margin-bottom:20px}
.notice.error{background:#fdecea;color:#c62828;border:1px solid #ffcdd2}
.notice.success{background:#e8f5e9;color:#2e7d32;border:1px solid #c8e6c9}
.notice.warn{background:#fffde7;color:#f57f17;border:1px solid #fff9c4}
.req-list{list-style:none;padding:0;margin:0}
.req-list li{padding:6px 0;font-size:14px;border-bottom:1px solid #f5f5f5;display:flex;justify-content:space-between}
.req-list li:last-child{border:none}
.pass{color:#2e7d32;font-weight:500}
.fail{color:#c62828;font-weight:500}
code{background:#f5f5f5;padding:1px 5px;border-radius:4px;font-size:13px}
.hint{font-size:12px;color:#888;margin:-10px 0 16px}
@media(max-width:640px){.wrap{margin:20px auto}.card{padding:16px}}
</style>
</head>
<body>
<div class="wrap">
  <div class="logo">JA Framework</div>
  {$body}
</div>
</body>
</html>
HTML;
}

// -------------------------------------------------------
// Success screen
// -------------------------------------------------------
if ($success) {
    echo render_page('Installed', '
        <h1>Installation complete</h1>
        <p class="sub">JA Framework is ready to use.</p>
        <div class="notice success">
            <strong>✅ Everything is set up.</strong> This installer has deleted itself.
        </div>
        <div class="card">
            <h2>Next steps</h2>
            <p style="font-size:14px;margin:0 0 12px;">Head to your admin panel to log in:</p>
            <p style="margin:0"><a href="/ja-admin/dashboard.php" style="color:#111;font-weight:500;">/ja-admin/dashboard.php</a></p>
        </div>
        <div class="card">
            <h2>Notes</h2>
            <ul style="font-size:14px;margin:0;padding-left:20px;color:#555">
                <li>Your <code>.env</code> file has been written to the site root.</li>
                <li>The <code>ja-pages</code> plugin is enabled and set as your homepage plugin.</li>
                <li>Log in with the magic link sent to your admin email.</li>
            </ul>
        </div>
    ');
    exit;
}

// -------------------------------------------------------
// Requirements screen
// -------------------------------------------------------
$req_html = '<ul class="req-list">';
foreach ($reqs as $label => $pass) {
    $cls  = $pass ? 'pass' : 'fail';
    $mark = $pass ? '✓' : '✗';
    $req_html .= "<li><span>{$label}</span><span class='{$cls}'>{$mark}</span></li>";
}
$req_html .= '</ul>';

// -------------------------------------------------------
// Error display
// -------------------------------------------------------
$error_html = '';
if (!empty($errors)) {
    $error_html = '<div class="notice error"><strong>Please fix the following:</strong><ul style="margin:8px 0 0;padding-left:18px">';
    foreach ($errors as $e) {
        $error_html .= '<li>' . esc($e) . '</li>';
    }
    $error_html .= '</ul></div>';
}

$req_warn = '';
if (!empty($req_fail)) {
    $req_warn = '<div class="notice warn"><strong>⚠ Requirements not met.</strong> Fix the failing checks before installing.</div>';
}

// Build timezone select
$tz_opts = '';
$current_tz = $_POST['timezone'] ?? 'America/Chicago';
foreach ($timezones as $tz) {
    $sel     = $tz === $current_tz ? ' selected' : '';
    $tz_opts .= "<option value='" . esc($tz) . "'{$sel}>" . esc($tz) . "</option>";
}

// Build language select (common set)
$langs = ['en' => 'English', 'es' => 'Spanish', 'fr' => 'French', 'de' => 'German', 'pt' => 'Portuguese', 'it' => 'Italian', 'nl' => 'Dutch', 'pl' => 'Polish', 'ru' => 'Russian', 'zh' => 'Chinese', 'ja' => 'Japanese', 'ar' => 'Arabic'];
$lang_opts = '';
$current_lang = $_POST['site_lang'] ?? 'en';
foreach ($langs as $code => $name) {
    $sel       = $code === $current_lang ? ' selected' : '';
    $lang_opts .= "<option value='" . esc($code) . "'{$sel}>" . esc($name) . " ({$code})</option>";
}

$val_db_host = esc($_POST['db_host'] ?? 'localhost');
$val_db_name = esc($_POST['db_name'] ?? '');
$val_db_user = esc($_POST['db_user'] ?? '');
$val_db_pass = esc($_POST['db_pass'] ?? '');

$body = <<<HTML
<h1>Install JA Framework</h1>
<p class="sub">Fill in the details below to get started.</p>

{$req_warn}
{$error_html}

<div class="card">
  <h2>Requirements</h2>
  {$req_html}
</div>

<form method="POST">

  <div class="card">
    <h2>Database</h2>
    <label>Host</label>
    <input type="text" name="db_host" value="{$val_db_host}" placeholder="localhost">
    <label>Database name</label>
    <input type="text" name="db_name" value="{$val_db_name}" placeholder="my_database" required>
    <label>Username</label>
    <input type="text" name="db_user" value="{$val_db_user}" placeholder="db_user" required autocomplete="off">
    <label>Password</label>
    <input type="password" name="db_pass" value="{$val_db_pass}" autocomplete="new-password">
    <p class="hint">The database must already exist and the user must have full privileges on it.</p>
  </div>

  <div class="card">
    <h2>Site</h2>
    <label>Site name</label>
    <input type="text" name="site_name" value="" placeholder="My Site" required>
    <label>Slogan <span style="font-weight:400;color:#aaa">(optional)</span></label>
    <input type="text" name="slogan" value="" placeholder="Just another JA site">
    <label>Language</label>
    <select name="site_lang">{$lang_opts}</select>
    <label>Timezone</label>
    <select name="timezone">{$tz_opts}</select>
  </div>

  <div class="card">
    <h2>Admin</h2>
    <label>Admin email address</label>
    <input type="email" name="admin_email" value="" placeholder="you@example.com" required>
    <p class="hint">Magic login links will be sent to this address. You can add more from Settings after install.</p>
  </div>

  <button type="submit" <?= !empty($req_fail) ? 'disabled style="opacity:.5;cursor:not-allowed"' : '' ?>>
    Install JA Framework
  </button>

</form>
HTML;

echo render_page('Install', $body);