<?php
define('JA_BYPASS_CACHE', true);   // admin and login never use an options cache
require_once __DIR__ . '/../ja-core/autoload.php';

use JA\Core\Database;
use JA\Core\Auth;
use JA\Core\Mail;
use JA\Core\Hooks;
use JA\Core\Plugins;

\JA\Core\Session::start();

$db      = Database::getConnection();
$auth    = new Auth($db);
$message = '';

// Plugins run here too, so IP blocking, login throttling and the audit log cover the login page
Plugins::loadFrontend();

// Handle token click from email
if (isset($_GET['token'])) {
    $session = $auth->validateToken($_GET['token']);
    if ($session) {
        \JA\Core\Session::login($session['email']);   // new session id and CSRF token
        Hooks::fire('login_success', $session['email']);
        header("Location: " . JA_BASE_URL . "/ja-admin/dashboard.php");
        exit;
    } else {
        $message = "Invalid or expired link. Please request a new one.";
        Hooks::fire('login_failed', 'Invalid or expired login link');
    }
}

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'], $_POST['csrf'])) {
    // CSRF check
    if (!is_string($_POST['csrf']) || !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'])) {
        $message = "Invalid request. Please try again.";
    } else {
        $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);

        if (!Hooks::apply('login_allowed', true, $email)) {
            $message = "❌ Too many login requests. Please wait a few minutes and try again.";
        } else {
            $link = $auth->generateLink($email);
            Hooks::fire('login_link_requested', $email, $link !== null);

            // Always show the same message whether email is allowed or not
            // to avoid leaking which addresses are valid admins
            if ($link && Mail::sendMagicLink($email, $link)) {
                $message = "✅ If that address is authorised, a magic link is on its way. Check your inbox.";
            } elseif (!$link) {
                $message = "✅ If that address is authorised, a magic link is on its way. Check your inbox.";
            } else {
                $message = "❌ Error sending email. Please check your server mail settings.";
            }
        }
    }
}

// Generate CSRF token for this session
$_SESSION['csrf'] ??= bin2hex(random_bytes(32));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JA Admin Login</title>
    <link rel="stylesheet" href="<?= JA_BASE_URL ?>/ja-themes/default/style.css">
    <style>
        body { background: #f0f0ee; }
        .login-wrap { max-width: 400px; margin: 10vh auto; padding: 0 20px; }
        .login-card { background: #fff; border: 1px solid #e5e5e3; border-radius: 10px; padding: 32px; text-align: center; }
        .login-card h2 { margin: 0 0 6px; font-size: 20px; }
        .login-card p  { margin: 0 0 24px; color: #666; font-size: 14px; }
        .login-input { width: 100%; padding: 11px 14px; margin-bottom: 14px; border: 1px solid #ddd; border-radius: 7px;
                       font-size: 15px; font-family: inherit; box-sizing: border-box; background: #fafafa; }
        .login-input:focus { outline: none; border-color: #666; background: #fff; }
        .login-btn { width: 100%; padding: 12px; background: #111; color: #fff; border: none; border-radius: 7px;
                     font-size: 15px; font-family: inherit; cursor: pointer; transition: background 0.15s; }
        .login-btn:hover { background: #333; }
        .msg { padding: 10px 14px; margin-bottom: 20px; border-radius: 7px; background: #f4f4f4; font-size: 14px; text-align: left; }
    </style>
</head>
<body>
    <div class="login-wrap">
        <div class="login-card">
            <h2>JA Framework</h2>
            <p>Passwordless admin login</p>

            <?php if ($message): ?>
                <div class="msg"><?= htmlspecialchars($message) ?></div>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf']) ?>">
                <input type="email" name="email" class="login-input" placeholder="Email address" required autofocus>
                <button type="submit" class="login-btn">Send magic link</button>
            </form>
        </div>
    </div>
</body>
</html>
