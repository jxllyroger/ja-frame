<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>JA Admin</title>
  <link rel="stylesheet" href="admin-style.css">
  <style>
  .topbar-visit{display:inline-flex;align-items:center;gap:6px;font-size:13px;color:#666;text-decoration:none;padding:5px 8px;border-radius:6px;transition:background .15s,color .15s}.topbar-visit:hover{background:#f0f0ee;color:#111}.topbar-visit svg{flex-shrink:0}
  .ja-user-menu{position:relative}
  .ja-user-btn{display:flex;align-items:center;gap:8px;background:none;border:1px solid #e5e5e3;border-radius:8px;padding:5px 10px 5px 6px;cursor:pointer;font-family:inherit;font-size:13px;color:#333;transition:background .15s,border-color .15s}.ja-user-btn:hover{background:#f0f0ee;border-color:#ccc}
  .ja-avatar-img{width:26px;height:26px;border-radius:50%;object-fit:cover;flex-shrink:0}
  .ja-avatar-initials{width:26px;height:26px;border-radius:50%;background:#111;color:#fff;font-size:11px;font-weight:600;display:flex;align-items:center;justify-content:center;flex-shrink:0}
  .ja-user-name{max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .ja-user-dropdown{display:none;position:absolute;top:calc(100% + 8px);right:0;background:#fff;border:1px solid #e5e5e3;border-radius:10px;min-width:200px;box-shadow:0 4px 20px rgba(0,0,0,.1);overflow:hidden;z-index:200}
  .ja-user-menu.open .ja-user-dropdown{display:block}
  .ja-user-dropdown-email{padding:12px 14px 8px;font-size:12px;color:#888;border-bottom:1px solid #f0f0ee;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .ja-user-dropdown-item{display:block;padding:10px 14px;font-size:14px;color:#333;text-decoration:none;transition:background .15s}.ja-user-dropdown-item:hover{background:#f0f0ee}
  .ja-user-dropdown-logout{color:#c62828;border-top:1px solid #f0f0ee}.ja-user-dropdown-logout:hover{background:#fdecea}
  #ja-admin-footer{display:flex;align-items:center;justify-content:space-between;padding:10px 20px;font-size:12px;color:#aaa;border-top:1px solid #e5e5e3;background:#fff;flex-shrink:0}
  @media(max-width:640px){.ja-user-name{display:none}.topbar-visit .nav-text{display:none}}
  </style>
  <?php \JA\Core\Hooks::fire('admin_head'); ?>
</head>
<body>

<div id="sidebar">
  <div class="sidebar-header">
    <span class="brand-text">JA Framework</span>
    <span class="brand-icon">⚡</span>
  </div>

  <?php foreach($core_menu as $item): ?>
    <a class="nav-item <?= $current_view === $item['slug'] ? 'active' : '' ?>" href="?view=<?= $item['slug'] ?>">
      <span class="icon"><?= $item['icon'] ?></span>
      <span class="nav-text"><?= $item['label'] ?></span>
    </a>
  <?php endforeach; ?>

  <?php $dynamic_items = \JA\Core\Hooks::get_menu_items(); if (!empty($dynamic_items)): ?>
    <div class="section-label"><span class="brand-text">Plugins</span></div>
    <?php foreach($dynamic_items as $item): ?>
      <a class="nav-item <?= $current_view === $item['slug'] ? 'active' : '' ?>" href="?view=<?= $item['slug'] ?>">
        <span class="icon"><?= $item['icon'] ?></span>
        <span class="nav-text"><?= $item['label'] ?></span>
      </a>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<div id="main">
  <div id="topbar">
    <button class="toggle-btn" onclick="document.getElementById('sidebar').classList.toggle('collapsed')" aria-label="Toggle sidebar">☰</button>

    <div style="display:flex;align-items:center;gap:12px;margin-left:auto;">

      <!-- Visit site -->
      <a href="<?= JA_BASE_URL ?>/" target="_blank" class="topbar-visit" title="Visit site">
        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
        <span class="nav-text">Visit site</span>
      </a>

      <!-- User menu -->
      <div class="ja-user-menu" id="ja-user-menu">
        <button class="ja-user-btn" onclick="document.getElementById('ja-user-menu').classList.toggle('open')" aria-label="User menu">
          <?php if (!empty($ja_current_user['avatar'])): ?>
            <img src="<?= JA_BASE_URL ?>/uploads/<?= htmlspecialchars($ja_current_user['avatar']) ?>" class="ja-avatar-img" alt="">
          <?php else: ?>
            <span class="ja-avatar-initials"><?= htmlspecialchars($ja_current_user['initials'] ?? '?') ?></span>
          <?php endif; ?>
          <span class="ja-user-name nav-text"><?= htmlspecialchars($ja_current_user['display_name'] ?? $_SESSION['ja_admin']) ?></span>
          <span style="color:#aaa;font-size:11px;">▾</span>
        </button>
        <div class="ja-user-dropdown">
          <div class="ja-user-dropdown-email"><?= htmlspecialchars($_SESSION['ja_admin']) ?></div>
          <a href="?view=profile" class="ja-user-dropdown-item">Profile</a>
          <a href="?logout=1" class="ja-user-dropdown-item ja-user-dropdown-logout">Log out</a>
        </div>
      </div>

    </div>
  </div>

  <div id="content">
    <?php if ($message): ?>
      <?php $cls = str_starts_with($message, '✅') ? 'success' : 'error'; ?>
      <div class="ja-notice <?= $cls ?>"><?= $message ?></div>
    <?php endif; ?>
    <?= $admin_output ?>
  </div>

  <div id="ja-admin-footer">
    <span>JA Framework</span>
    <span>&copy; <?= date('Y') ?></span>
  </div>
</div>

<script>
// Close user menu when clicking outside
document.addEventListener('click', function(e) {
  var menu = document.getElementById('ja-user-menu');
  if (menu && !menu.contains(e.target)) menu.classList.remove('open');
});

// Auto-inject CSRF token into every POST form
(function() {
  var token = <?= json_encode($_SESSION['csrf']) ?>;
  document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('form[method="POST"],form[method="post"]').forEach(function(f) {
      if (!f.querySelector('input[name="csrf"]')) {
        var inp = document.createElement('input');
        inp.type = 'hidden'; inp.name = 'csrf'; inp.value = token;
        f.appendChild(inp);
      }
    });
  });
})();

// Lightbox
(function() {
  var lb, lbImg, lbMeta;
  function build() {
    lb = document.createElement('div');
    lb.style.cssText = 'display:none;position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,0.9);align-items:center;justify-content:center;padding:20px;cursor:zoom-out;';
    lb.addEventListener('click', function(e) { if (e.target === lb) close(); });
    var inner = document.createElement('div');
    inner.style.cssText = 'position:relative;display:flex;flex-direction:column;align-items:center;gap:12px;max-width:min(92vw,1000px);cursor:default;';
    var btn = document.createElement('button');
    btn.textContent = '✕';
    btn.style.cssText = 'position:absolute;top:-40px;right:0;background:rgba(255,255,255,0.15);border:none;color:#fff;font-size:20px;line-height:1;padding:6px 11px;border-radius:6px;cursor:pointer;font-family:inherit;';
    btn.addEventListener('click', close);
    lbImg = document.createElement('img');
    lbImg.style.cssText = 'max-width:100%;max-height:calc(90dvh - 60px);object-fit:contain;border-radius:6px;display:block;';
    lbMeta = document.createElement('div');
    lbMeta.style.cssText = 'color:rgba(255,255,255,0.65);font-size:13px;text-align:center;';
    inner.appendChild(btn); inner.appendChild(lbImg); inner.appendChild(lbMeta);
    lb.appendChild(inner); document.body.appendChild(lb);
  }
  function open(src, meta) {
    if (!lb) build();
    lbImg.src = src; lbMeta.textContent = meta || '';
    lb.style.display = 'flex'; document.body.style.overflow = 'hidden';
  }
  function close() {
    if (!lb) return;
    lb.style.display = 'none'; lbImg.src = ''; document.body.style.overflow = '';
  }
  document.addEventListener('keydown', function(e) { if (e.key === 'Escape') close(); });
  window.jaLightboxOpen = open; window.jaLightboxClose = close;
})();
</script>

<?php \JA\Core\Hooks::fire('admin_body_end'); ?>
</body>
</html>
