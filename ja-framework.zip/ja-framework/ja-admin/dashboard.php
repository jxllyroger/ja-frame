<?php
require_once __DIR__ . '/../ja-core/autoload.php';
session_start();

if (!isset($_SESSION['ja_admin'])) { header('Location: ../ja-login.php'); exit; }
if (isset($_GET['logout']))        { session_destroy(); header('Location: ../ja-login.php'); exit; }

use JA\Core\Database;
use JA\Core\Plugins;
use JA\Core\Media as CoreMedia;
use JA\Core\Options;

$db           = Database::getConnection();
$message      = '';
$current_view = $_GET['view'] ?? 'home';

$_SESSION['csrf'] ??= bin2hex(random_bytes(32));
$csrf = $_SESSION['csrf'];

if (random_int(1, 100) === 1) CoreMedia::pruneTokens($db);

$ja_current_user = [];
try {
    $stmt = $db->prepare("SELECT * FROM ja_users WHERE email = ? LIMIT 1");
    $stmt->execute([$_SESSION['ja_admin']]);
    $u = $stmt->fetch();
    if ($u) {
        $name = $u['display_name'] ?: $_SESSION['ja_admin'];
        $parts = explode(' ', trim($name));
        $initials = strtoupper(substr($parts[0], 0, 1) . (isset($parts[1]) ? substr($parts[1], 0, 1) : ''));
        $ja_current_user = [
            'display_name' => $name,
            'avatar'       => $u['avatar'] ?: '',
            'initials'     => $initials ?: '?',
        ];
    } else {
        $email = $_SESSION['ja_admin'];
        $db->prepare("INSERT IGNORE INTO ja_users (email, display_name) VALUES (?, 'Admin')")->execute([$email]);
        $ja_current_user = ['display_name' => 'Admin', 'avatar' => '', 'initials' => 'A'];
    }
} catch (\Exception $e) {
    $ja_current_user = ['display_name' => $_SESSION['ja_admin'], 'avatar' => '', 'initials' => '?'];
}

function ja_verify_get_token() {
    return isset($_GET['_token']) && hash_equals($_SESSION['csrf'], $_GET['_token']);
}

Plugins::loadActive();

// JSON endpoint for the editor's media picker
if (($_GET['view'] ?? '') === 'media' && isset($_GET['json']) && $_GET['json'] === '1') {
    header('Content-Type: application/json');
    $files = \JA\Core\Media::getAll($db);
    $out   = [];
    foreach ($files as $m) {
        $out[] = [
            'id'            => (int)$m['id'],
            'filename'      => $m['filename'],
            'original_name' => $m['original_name'],
            'url'           => JA_BASE_URL . '/uploads/' . $m['filename'],
        ];
    }
    echo json_encode($out);
    exit;
}

if (isset($_GET['activate']) && $current_view === 'themes') {
    if (!ja_verify_get_token()) { $message = '❌ Invalid token.'; }
    elseif (\JA\Plugins\Themes::handleActivate($db, $_GET['activate'])) { $message = '✅ Theme activated!'; }
}
if (isset($_GET['delete']) && $current_view === 'themes') {
    if (!ja_verify_get_token()) { $message = '❌ Invalid token.'; }
    elseif (\JA\Plugins\Themes::handleDelete($db, $_GET['delete'])) { $message = '✅ Theme deleted!'; }
    else { $message = '❌ Could not delete — theme may be active or is a protected default.'; }
}
if (isset($_GET['delete']) && $current_view === 'media') {
    if (!ja_verify_get_token()) { $message = '❌ Invalid token.'; }
    elseif (CoreMedia::delete($_GET['delete'], $db)) { $message = '✅ File deleted!'; }
    else { $message = '❌ Could not delete file.'; }
}
if (isset($_GET['delete']) && $current_view === 'pages') {
    if (!ja_verify_get_token()) { $message = '❌ Invalid token.'; }
    elseif (\JA\Plugins\Pages::handleDelete($db, $_GET['delete'])) { $message = '✅ Page deleted!'; }
    else { $message = '❌ Could not delete — cannot delete the home page.'; }
}
if (isset($_GET['toggle']) && $current_view === 'plugins') {
    if (ja_verify_get_token()) Plugins::toggle($_GET['toggle']);
    header('Location: ?view=plugins'); exit;
}
if (isset($_GET['toggle_menu']) && $current_view === 'menus') {
    if (ja_verify_get_token()) \JA\Plugins\Menus::handleToggle($_GET['toggle_menu']);
    header('Location: ?view=menus&menu=' . urlencode($_GET['toggle_menu'])); exit;
}
if (isset($_GET['delete_menu']) && $current_view === 'menus') {
    if (ja_verify_get_token()) \JA\Plugins\Menus::handleDeleteMenu($_GET['delete_menu']);
    header('Location: ?view=menus'); exit;
}
if (isset($_GET['delete_item']) && $current_view === 'menus') {
    if (ja_verify_get_token()) \JA\Plugins\Menus::handleDeleteItem($_GET['menu'] ?? '', $_GET['delete_item']);
    header('Location: ?view=menus&menu=' . urlencode($_GET['menu'] ?? '')); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf']) || !hash_equals($csrf, $_POST['csrf'])) {
        $message = '❌ Invalid request — please try again.';
    } else {
        $ja_action = $_POST['ja_action'] ?? '';

        if (isset($_FILES['ja_upload']) && $_FILES['ja_upload']['error'] !== UPLOAD_ERR_NO_FILE) {
            $upload_id = CoreMedia::upload($_FILES['ja_upload'], $db);
            if ($upload_id) {
                \JA\Core\Hooks::fire('media_upload', $upload_id, $_FILES['ja_upload']['name']);
                $message = '✅ Uploaded successfully!';
            } else {
                $message = '❌ Upload failed — check file type.';
            }
        } elseif (isset($_FILES['theme_zip']) && $_FILES['theme_zip']['error'] !== UPLOAD_ERR_NO_FILE) {
            $message = \JA\Plugins\Themes::handleInstall($_FILES['theme_zip']) ? '✅ Theme installed!' : '❌ Theme install failed.';
        } elseif (isset($_FILES['plugin_zip']) && $_FILES['plugin_zip']['error'] !== UPLOAD_ERR_NO_FILE) {
            $message = \JA\Plugins\Plugins::handleInstall($_FILES['plugin_zip']) ? '✅ Plugin installed! Enable it from the Installed tab.' : '❌ Plugin install failed.';
        } elseif ($ja_action === 'save_page' && class_exists('JA\\Plugins\\Pages')) {
            if (!\JA\Plugins\Pages::handleSave($db, $_POST)) {
                $message = '❌ Could not save page — check title and slug are filled in.';
            }
        } elseif ($ja_action === 'save_profile') {
            $name   = trim($_POST['display_name'] ?? '');
            $avatar = trim($_POST['avatar'] ?? '');
            $stmt   = $db->prepare("UPDATE ja_users SET display_name = ?, avatar = ? WHERE email = ?");
            $stmt->execute([$name ?: 'Admin', $avatar, $_SESSION['ja_admin']]);
            $message = '✅ Profile saved!';
            $ja_current_user['display_name'] = $name ?: 'Admin';
            $ja_current_user['avatar']        = $avatar;
        } else {
            $plugin_class = 'JA\\Plugins\\' . ucfirst($current_view);
            if (class_exists($plugin_class) && method_exists($plugin_class, 'handleSave')) {
                $plugin_class::handleSave($db, $_POST);
                $message = '✅ Changes saved!';
            }
        }
    }
}

$core_menu = [
    ['label' => 'Dashboard', 'slug' => 'home',     'icon' => '📊'],
    ['label' => 'Media',     'slug' => 'media',    'icon' => '🖼️'],
    ['label' => 'Menus',     'slug' => 'menus',    'icon' => '🗂️'],
    ['label' => 'Themes',    'slug' => 'themes',   'icon' => '🎨'],
    ['label' => 'Plugins',   'slug' => 'plugins',  'icon' => '🔌'],
    ['label' => 'Settings',  'slug' => 'settings', 'icon' => '⚙️'],
];

if ($current_view === 'home') {
    $page_count   = (int)$db->query("SELECT COUNT(*) FROM ja_pages")->fetchColumn();
    $media_count  = (int)$db->query("SELECT COUNT(*) FROM ja_media")->fetchColumn();
    $media_size   = (int)$db->query("SELECT COALESCE(SUM(file_size),0) FROM ja_media")->fetchColumn();
    $active_theme = Options::get('active_theme', 'ja-clean');
    $frontend_plg = Options::get('frontend_plugin', '');
    $plugin_list  = json_decode(Options::get('active_plugins', '[]'), true) ?: [];
    $menu_count   = count(\JA\Core\Hooks::get_all_menus());
    $recent_logins = $db->query("SELECT email, used_at FROM ja_auth_tokens WHERE used = 1 AND used_at IS NOT NULL ORDER BY used_at DESC LIMIT 5")->fetchAll();
    $recent_media  = $db->query("SELECT original_name, uploaded_at FROM ja_media ORDER BY uploaded_at DESC LIMIT 5")->fetchAll();
    $mysql_version = $db->query("SELECT VERSION()")->fetchColumn();
    $health = [
        'PHP '    . PHP_VERSION  => true,
        'MySQL '  . $mysql_version => true,
        'ZipArchive'               => extension_loaded('zip'),
        'finfo'                    => extension_loaded('fileinfo'),
        'Uploads writable'         => is_writable(JA_ROOT . '/public/uploads'),
        '.env readable'            => file_exists(JA_ROOT . '/.env'),
    ];
    if ($media_size >= 1048576)      $media_size_str = round($media_size/1048576,1).' MB';
    elseif ($media_size >= 1024)     $media_size_str = round($media_size/1024,1).' KB';
    else                             $media_size_str = $media_size.' B';

    ob_start(); ?>
    <h1 class="ja-page-header">Dashboard</h1>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">
      <div>
        <div class="ja-card" style="margin-bottom:20px;">
          <h3>Quick actions</h3>
          <div style="display:flex;flex-wrap:wrap;gap:10px;">
            <a href="?view=pages&action=new" class="ja-btn ja-btn-primary ja-btn-sm">+ New page</a>
            <a href="?view=media" class="ja-btn ja-btn-secondary ja-btn-sm">Upload media</a>
            <a href="?view=menus" class="ja-btn ja-btn-secondary ja-btn-sm">Edit menus</a>
            <a href="?view=settings" class="ja-btn ja-btn-secondary ja-btn-sm">Settings</a>
          </div>
        </div>
        <div class="ja-card" style="margin-bottom:20px;">
          <h3>Content</h3>
          <table class="ja-table">
            <tr><td>Pages</td><td style="text-align:right;font-weight:600;"><?= $page_count ?></td></tr>
            <tr><td>Media files</td><td style="text-align:right;font-weight:600;"><?= $media_count ?></td></tr>
            <tr><td>Media storage</td><td style="text-align:right;font-weight:600;"><?= $media_size_str ?></td></tr>
            <tr><td>Menus</td><td style="text-align:right;font-weight:600;"><?= $menu_count ?></td></tr>
            <tr><td>Active theme</td><td style="text-align:right;font-weight:600;"><?= htmlspecialchars($active_theme) ?></td></tr>
            <tr><td>Frontend plugin</td><td style="text-align:right;font-weight:600;"><?= htmlspecialchars($frontend_plg ?: '—') ?></td></tr>
            <tr><td>Enabled plugins</td><td style="text-align:right;font-weight:600;"><?= count($plugin_list) ?></td></tr>
          </table>
        </div>
        <div class="ja-card">
          <h3>System health</h3>
          <table class="ja-table">
            <?php foreach ($health as $label => $ok): ?>
            <tr>
              <td><?= htmlspecialchars($label) ?></td>
              <td style="text-align:right;"><?= $ok ? '<span style="color:#2e7d32;font-weight:500;">✓</span>' : '<span style="color:#c62828;font-weight:500;">✗ Check required</span>' ?></td>
            </tr>
            <?php endforeach; ?>
          </table>
        </div>
      </div>
      <div>
        <div class="ja-card" style="margin-bottom:20px;">
          <h3>Recent logins</h3>
          <?php if (empty($recent_logins)): ?>
            <p style="color:#aaa;font-size:14px;margin:0;">No login history yet.</p>
          <?php else: ?>
            <table class="ja-table">
              <thead><tr><th>Email</th><th>When</th></tr></thead>
              <tbody>
              <?php foreach ($recent_logins as $login): ?>
                <tr>
                  <td style="font-size:13px;"><?= htmlspecialchars($login['email']) ?></td>
                  <td style="font-size:12px;color:#888;white-space:nowrap;"><?= htmlspecialchars(date('M j, g:ia', strtotime($login['used_at']))) ?></td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          <?php endif; ?>
        </div>
        <div class="ja-card">
          <h3>Recent uploads</h3>
          <?php if (empty($recent_media)): ?>
            <p style="color:#aaa;font-size:14px;margin:0;">No files uploaded yet.</p>
          <?php else: ?>
            <table class="ja-table">
              <thead><tr><th>File</th><th>Uploaded</th></tr></thead>
              <tbody>
              <?php foreach ($recent_media as $file): ?>
                <tr>
                  <td style="font-size:13px;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= htmlspecialchars($file['original_name']) ?></td>
                  <td style="font-size:12px;color:#888;white-space:nowrap;"><?= htmlspecialchars(date('M j, g:ia', strtotime($file['uploaded_at']))) ?></td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <style>@media(max-width:640px){div[style*="grid-template-columns:1fr 1fr"]{grid-template-columns:1fr!important}}</style>
    <?php
    $admin_output = ob_get_clean();

} elseif ($current_view === 'profile') {
    $stmt = $db->prepare("SELECT * FROM ja_users WHERE email = ? LIMIT 1");
    $stmt->execute([$_SESSION['ja_admin']]);
    $profile = $stmt->fetch() ?: [];
    $all_media = CoreMedia::getAll($db);
    $base = JA_BASE_URL;

    ob_start(); ?>
    <h1 class="ja-page-header">Profile</h1>
    <form method="POST">
      <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf) ?>">
      <input type="hidden" name="ja_action" value="save_profile">

      <div class="ja-card" style="margin-bottom:20px;">
        <h3>Display name</h3>
        <label class="ja-label">Name shown in the admin panel</label>
        <input type="text" name="display_name" class="ja-input" value="<?= htmlspecialchars($profile['display_name'] ?? 'Admin') ?>">
        <label class="ja-label">Email (read only)</label>
        <input type="text" class="ja-input" value="<?= htmlspecialchars($_SESSION['ja_admin']) ?>" readonly style="background:#f5f5f5;color:#aaa;">
      </div>

      <div class="ja-card" style="margin-bottom:20px;">
        <h3>Avatar</h3>
        <input type="hidden" name="avatar" id="ja-avatar-val" value="<?= htmlspecialchars($profile['avatar'] ?? '') ?>">

        <?php $current_av = $profile['avatar'] ?? ''; ?>
        <div style="display:flex;align-items:center;gap:16px;margin-bottom:16px;">
          <div id="ja-avatar-preview" style="width:64px;height:64px;border-radius:50%;overflow:hidden;background:#111;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
            <?php if ($current_av): ?>
              <img src="<?= $base ?>/uploads/<?= htmlspecialchars($current_av) ?>" style="width:100%;height:100%;object-fit:cover;">
            <?php else: ?>
              <span style="color:#fff;font-size:22px;font-weight:600;"><?= htmlspecialchars($ja_current_user['initials'] ?? '?') ?></span>
            <?php endif; ?>
          </div>
          <div>
            <p style="font-size:13px;color:#555;margin:0 0 8px;">Pick an image from your media library.</p>
            <?php if ($current_av): ?>
              <button type="button" class="ja-btn ja-btn-danger ja-btn-sm" onclick="clearAvatar()">Remove avatar</button>
            <?php endif; ?>
          </div>
        </div>

        <?php if (empty($all_media)): ?>
          <p style="font-size:13px;color:#aaa;">No images in library yet. <a href="?view=media">Upload one first.</a></p>
        <?php else: ?>
          <div class="ja-media-grid">
            <?php foreach ($all_media as $m):
              $url  = htmlspecialchars($base . '/uploads/' . $m['filename']);
              $sel  = ($m['filename'] === $current_av);
            ?>
              <div class="ja-media-item <?= $sel ? 'ja-avatar-selected' : '' ?>"
                   onclick="selectAvatar('<?= htmlspecialchars($m['filename']) ?>', '<?= $url ?>', this)"
                   style="<?= $sel ? 'outline:3px solid #111;' : '' ?>">
                <img src="<?= $url ?>" alt="<?= htmlspecialchars($m['original_name']) ?>" loading="lazy">
                <div class="ja-media-caption"><?= htmlspecialchars($m['original_name']) ?></div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>

      <button type="submit" class="ja-btn ja-btn-primary">Save profile</button>
    </form>
    <script>
    function selectAvatar(filename, url, el) {
      document.getElementById('ja-avatar-val').value = filename;
      document.querySelectorAll('.ja-media-item').forEach(function(i) {
        i.style.outline = '';
      });
      el.style.outline = '3px solid #111';
      var preview = document.getElementById('ja-avatar-preview');
      preview.innerHTML = '<img src="' + url + '" style="width:100%;height:100%;object-fit:cover;">';
    }
    function clearAvatar() {
      document.getElementById('ja-avatar-val').value = '';
      document.querySelectorAll('.ja-media-item').forEach(function(i) { i.style.outline = ''; });
      document.getElementById('ja-avatar-preview').innerHTML = '<span style="color:#fff;font-size:22px;font-weight:600;"><?= htmlspecialchars($ja_current_user['initials'] ?? '?') ?></span>';
    }
    </script>
    <?php
    $admin_output = ob_get_clean();

} else {
    $plugin_class = 'JA\\Plugins\\' . ucfirst($current_view);
    if (class_exists($plugin_class) && method_exists($plugin_class, 'renderAdmin')) {
        $admin_output = $plugin_class::renderAdmin($db, $csrf);
    } else {
        $admin_output = "<h1 class='ja-page-header'>Dashboard</h1><div class='ja-card'><p class='ja-dashboard-welcome'>Welcome to JA. Select a tool from the sidebar to get started.</p></div>";
    }
}

require_once 'layout.php';
