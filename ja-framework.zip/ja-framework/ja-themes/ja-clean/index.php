<?php
use JA\Core\Options;
use JA\Core\Hooks;
use JA\Core\SiteMenus;
use JA\Core\Shortcodes;

$site_name = Options::get('site_name', 'My Site');
$site_lang = Options::get('site_lang', 'en');
$slogan    = Options::get('site_slogan', '');
$logo      = Options::get('site_logo', '');
$favicon   = Options::get('site_favicon', '');

$primary_nav = SiteMenus::get('primary');
$footer_nav  = SiteMenus::get('footer');

// Apply page_title and page_content filters
$page_title   = Hooks::apply('page_title',   $ja_page['title']   ?? '');
$page_content = Hooks::apply('page_content', $ja_page['content'] ?? '');
$show_title   = empty($ja_page['hide_title']);   // set per page in Pages → Options
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($site_lang) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?> | <?= htmlspecialchars($site_name) ?></title>
    <?php if ($favicon): ?>
        <link rel="icon" href="<?= JA_BASE_URL ?>/uploads/<?= htmlspecialchars($favicon) ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="<?= JA_BASE_URL ?>/ja-themes/ja-clean/style.css">
    <?php Hooks::fire('head'); ?>
</head>
<body>
<?php Hooks::fire('body_start'); ?>

<header class="ja-header">
    <div class="ja-container">
        <div class="ja-header-inner">
            <a href="<?= JA_BASE_URL ?>/" class="ja-brand">
                <?php if ($logo): ?>
                    <img src="<?= JA_BASE_URL ?>/uploads/<?= htmlspecialchars($logo) ?>" alt="<?= htmlspecialchars($site_name) ?>">
                <?php endif; ?>
                <div class="ja-brand-text">
                    <h1><?= htmlspecialchars($site_name) ?></h1>
                    <?php if ($slogan): ?>
                        <small><?= htmlspecialchars($slogan) ?></small>
                    <?php endif; ?>
                </div>
            </a>
            <?php if ($primary_nav): ?>
                <nav class="ja-nav" aria-label="Primary navigation">
                    <?php foreach ($primary_nav as $item): ?>
                        <a href="<?= htmlspecialchars($item['url']) ?>"><?= htmlspecialchars($item['label']) ?></a>
                    <?php endforeach; ?>
                </nav>
            <?php endif; ?>
        </div>
    </div>
</header>

<main class="ja-main">
    <div class="ja-container">
        <?php Hooks::fire('content_before', $ja_page); ?>
        <?php if ($show_title): ?>
        <h2 class="ja-page-title"><?= htmlspecialchars($page_title) ?></h2>
        <?php endif; ?>
        <div class="ja-content"><?= Shortcodes::render($page_content) ?></div>
        <?php Hooks::fire('content_after', $ja_page); ?>
    </div>
</main>

<footer class="ja-footer">
    <div class="ja-container">
        <div class="ja-footer-inner">
            <span>&copy; <?= date('Y') ?> <?= htmlspecialchars($site_name) ?></span>
            <?php if ($footer_nav): ?>
                <nav class="ja-footer-nav" aria-label="Footer navigation">
                    <?php foreach ($footer_nav as $item): ?>
                        <a href="<?= htmlspecialchars($item['url']) ?>"><?= htmlspecialchars($item['label']) ?></a>
                    <?php endforeach; ?>
                </nav>
            <?php endif; ?>
        </div>
    </div>
</footer>

<?php Hooks::fire('body_end'); ?>
</body>
</html>
