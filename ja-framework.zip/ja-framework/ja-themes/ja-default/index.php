<?php 
use JA\Core\Options;

// Fetch settings from the database
$site_name = Options::get('site_name', 'JA Framework');
$site_lang = Options::get('site_lang', 'en');
$logo = Options::get('site_logo');
$favicon = Options::get('site_favicon'); // Fetch the favicon filename
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($site_lang) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($ja_page['title']) ?> | <?= htmlspecialchars($site_name) ?></title>

    <!-- 1. The Missing Favicon Link -->
    <?php if($favicon): ?>
        <link rel="icon" href="<?= JA_BASE_URL ?>/uploads/<?= htmlspecialchars($favicon) ?>" type="image/x-icon">
    <?php endif; ?>

    <link rel="stylesheet" href="<?= JA_BASE_URL ?>/ja-themes/ja-default/style.css">
</head>
<body>
    <header style="padding: 20px; border-bottom: 1px solid #eee;">
        <div class="container" style="display:flex; align-items:center; gap:15px;">
            <?php if($logo): ?>
                <img src="<?= JA_BASE_URL ?>/uploads/<?= htmlspecialchars($logo) ?>" style="height:40px;">
            <?php endif; ?>
            <div>
                <h1 style="margin:0; font-size: 1.2rem;"><?= htmlspecialchars($site_name) ?></h1>
                <small><?= htmlspecialchars(Options::get('site_slogan', '')) ?></small>
            </div>
        </div>
    </header>

    <main style="padding: 20px;">
        <div class="container">
            <h2><?= htmlspecialchars($ja_page['title']) ?></h2>
            <article><?= nl2br(htmlspecialchars($ja_page['content'])) ?></article>
        </div>
    </main>

    <footer style="padding: 20px; border-top:1px solid #eee; margin-top:40px;">
        <div class="container">&copy; <?= date('Y') ?> <?= htmlspecialchars($site_name) ?></div>
    </footer>
</body>
</html>

