<?php
use JA\Core\Options;
use JA\Core\Hooks;
use JA\Core\SiteMenus;
use JA\Core\Shortcodes;

$site_name = Options::get('site_name', 'PIGTOE');
$site_lang = Options::get('site_lang', 'en');
$logo      = Options::get('site_logo', '');
$favicon   = Options::get('site_favicon', '');
$slogan    = Options::get('site_slogan', 'LIVE FEED');

$primary_nav = SiteMenus::get('primary');
$footer_nav  = SiteMenus::get('footer');

$page_title   = Hooks::apply('page_title',   $ja_page['title']   ?? '');
$page_content = Hooks::apply('page_content', $ja_page['content'] ?? '');
$show_title   = empty($ja_page['hide_title']);   // set per page in Pages → Options
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($site_lang) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?> | <?= htmlspecialchars($site_name) ?></title>
    <?php if ($favicon): ?>
        <link rel="icon" href="<?= JA_BASE_URL ?>/uploads/<?= htmlspecialchars($favicon) ?>">
    <?php endif; ?>
    <!-- Dynamic directory routing path fix -->
    <link rel="stylesheet" href="<?= JA_BASE_URL ?>/ja-themes/<?= basename(__DIR__) ?>/style.css">
    <?php Hooks::fire('head'); ?>
</head>
<body>
<?php Hooks::fire('body_start'); ?>

    <!-- MTV-Style Header -->
    <header>
        <div class="brand-logo"><?php if ($logo): ?><img src="<?= JA_BASE_URL ?>/uploads/<?= htmlspecialchars($logo) ?>" alt="" class="brand-img"><?php endif; ?><?= htmlspecialchars($site_name) ?></div>
        <?php if ($slogan): ?>
            <br>
            <div class="brand-sub"><?= htmlspecialchars($slogan) ?></div>
        <?php endif; ?>
    </header>

    <!-- News Ticker Belt -->
    <div class="marquee-container">
        <div class="marquee-text">
            +++ <?= htmlspecialchars($page_title) ?> FRAME LOOPS ARE ACTIVE +++ RUNNING CENTRAL CONTEXT MATRIX +++
        </div>
    </div>

    <!-- Layout Grid Container Bounds -->
    <div class="container">
        
        <!-- Left Column: Main Stream Canvas Feed -->
        <main>
            <?php Hooks::fire('content_before', $ja_page); ?>
            <div class="block">
                <?php if ($show_title): ?>
                <div class="block-header">
                    <span><?= htmlspecialchars($page_title) ?></span>
                    <span style="font-family: monospace; font-size:0.8rem; color:#000;">REC [●]</span>
                </div>
                <?php endif; ?>
                <div class="block-body">
                    <div class="ja-content"><?= Shortcodes::render($page_content) ?></div>
                </div>
            </div>
            <?php Hooks::fire('content_after', $ja_page); ?>
        </main>

        <!-- Right Column: Navigation and System Data Status Panels -->
        <aside>
            <?php if ($primary_nav): ?>
            <div class="block">
                <div class="block-header">
                    <span>Navigation</span>
                </div>
                <div class="block-body">
                    <div class="nav-grid">
                        <?php foreach ($primary_nav as $item): ?>
                            <a href="<?= htmlspecialchars($item['url']) ?>" class="btn-retro"><?= htmlspecialchars($item['label']) ?></a>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="block">
                <div class="block-header neon-pink">
                    <span>System Status</span>
                </div>
                <div class="block-body" style="font-family: monospace; font-size: 0.9rem; text-transform: none; line-height: 1.4;">
                    <p style="color: #00ffcc;">&gt; Site Identity: <?= htmlspecialchars($site_name) ?></p>
                    <p style="color: #ff0055;">&gt; HTML Template: Connected</p>
                    <p style="color: #ffff00;">&gt; Style Profile: Pure Y2K / TRL</p>
                </div>
            </div>
        </aside>

    </div>

<?php Hooks::fire('body_end'); ?>
</body>
</html>
