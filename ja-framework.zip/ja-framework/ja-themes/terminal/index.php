<?php
use JA\Core\Options;
use JA\Core\Hooks;
use JA\Core\SiteMenus;
use JA\Core\Shortcodes;

$site_name = Options::get('site_name', 'CORE_SYS');
$site_lang = Options::get('site_lang', 'en');
$logo      = Options::get('site_logo', '');
$favicon   = Options::get('site_favicon', '');
$slogan    = Options::get('site_slogan', 'MATRIX TERMINAL RE-99');

$primary_nav = SiteMenus::get('primary');
$footer_nav  = SiteMenus::get('footer');

$page_title   = Hooks::apply('page_title',   $ja_page['title']   ?? '');
$page_content = Hooks::apply('page_content', $ja_page['content'] ?? '');
$show_title   = empty($ja_page['hide_title']);   // set per page in Pages → Options
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($site_lang) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?> | <?= htmlspecialchars($site_name) ?></title>
    <?php if ($favicon): ?>
        <link rel="icon" href="<?= JA_BASE_URL ?>/uploads/<?= htmlspecialchars($favicon) ?>">
    <?php endif; ?>
    <!-- Dynamic directory resolution grabs the local path safely -->
    <link rel="stylesheet" href="<?= JA_BASE_URL ?>/ja-themes/<?= basename(__DIR__) ?>/style.css">
    <?php Hooks::fire('head'); ?>
</head>
<body>
<?php Hooks::fire('body_start'); ?>

    <div class="terminal-container">

        <!-- Console Banner Header -->
        <header class="matrix-banner">
            <div class="brand-logo">
            <?php if ($logo): ?><img src="<?= JA_BASE_URL ?>/uploads/<?= htmlspecialchars($logo) ?>" alt="" class="brand-img"><?php endif; ?>SYS::<?= htmlspecialchars($site_name) ?></div>
            <?php if ($slogan): ?>
                <span class="brand-sub">RUNNING_MODE // <?= htmlspecialchars($slogan) ?></span>
            <?php endif; ?>
        </header>

        <!-- Command Strip Menu Line -->
        <?php if ($primary_nav): ?>
        <nav class="terminal-nav" aria-label="Terminal commands">
            <?php foreach ($primary_nav as $item): ?>
                <a href="<?= htmlspecialchars($item['url']) ?>" class="btn-retro">[ <?= htmlspecialchars($item['label']) ?> ]</a>
            <?php endforeach; ?>
        </nav>
        <?php endif; ?>

        <!-- Primary Output Terminal Display Area -->
        <main>
            <?php Hooks::fire('content_before', $ja_page); ?>
            <div class="block">
                <?php if ($show_title): ?>
                <div class="block-header">
                    <span>OUTPUT_STREAM://<?= htmlspecialchars($page_title) ?>.LOG</span>
                </div>
                <?php endif; ?>
                <div class="block-body">
                    <div class="ja-content"><?= Shortcodes::render($page_content) ?></div>
                </div>
            </div>
            <?php Hooks::fire('content_after', $ja_page); ?>
        </main>

        <!-- Diagnostics Output Console Footer -->
        <footer class="matrix-footer">
            <span>&gt; STATUS_OK // INTRUDER_ALERT: FALSE // &copy; <?= date('Y') ?></span>
            <?php if ($footer_nav): ?>
                <nav aria-label="Terminal terminal outputs">
                    <?php foreach ($footer_nav as $item): ?>
                        <a href="<?= htmlspecialchars($item['url']) ?>">[ <?= htmlspecialchars($item['label']) ?> ]</a>
                    <?php endforeach; ?>
                </nav>
            <?php endif; ?>
        </footer>

    </div>

<?php Hooks::fire('body_end'); ?>
</body>
</html>
