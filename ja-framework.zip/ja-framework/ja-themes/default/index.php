<?php
use JA\Core\Options;
use JA\Core\Hooks;
use JA\Core\SiteMenus;
use JA\Core\Shortcodes;

$site_name = Options::get('site_name', 'JA Framework');
$site_lang = Options::get('site_lang', 'en');
$slogan    = Options::get('site_slogan', '');
$logo      = Options::get('site_logo', '');
$favicon   = Options::get('site_favicon', '');

$primary_nav = SiteMenus::get('primary');
$footer_nav  = SiteMenus::get('footer');

// Same filters and shortcode expansion as every other theme, so plugins work here too
$page_title   = Hooks::apply('page_title',   $ja_page['title']   ?? '');
$page_content = Hooks::apply('page_content', $ja_page['content'] ?? '');
$show_title   = empty($ja_page['hide_title']);   // set per page in Pages → Options
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($site_lang) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?> | <?= htmlspecialchars($site_name) ?></title>
    <?php if ($favicon): ?>
        <link rel="icon" href="<?= JA_BASE_URL ?>/uploads/<?= htmlspecialchars($favicon) ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="<?= JA_BASE_URL ?>/ja-themes/<?= basename(__DIR__) ?>/style.css">
    <?php Hooks::fire('head'); ?>
</head>
<body>
<?php Hooks::fire('body_start'); ?>

<header>
    <div class="container header-inner">
        <a href="<?= JA_BASE_URL ?>/" class="brand">
            <?php if ($logo): ?>
                <img src="<?= JA_BASE_URL ?>/uploads/<?= htmlspecialchars($logo) ?>" alt="<?= htmlspecialchars($site_name) ?>">
            <?php endif; ?>
            <span>
                <strong><?= htmlspecialchars($site_name) ?></strong>
                <?php if ($slogan): ?><small><?= htmlspecialchars($slogan) ?></small><?php endif; ?>
            </span>
        </a>
        <?php if ($primary_nav): ?>
            <nav aria-label="Primary navigation">
                <?php foreach ($primary_nav as $item): ?>
                    <a href="<?= htmlspecialchars($item['url']) ?>"><?= htmlspecialchars($item['label']) ?></a>
                <?php endforeach; ?>
            </nav>
        <?php endif; ?>
    </div>
</header>

<main>
    <div class="container">
        <?php Hooks::fire('content_before', $ja_page); ?>
        <?php if ($show_title): ?>
        <h2><?= htmlspecialchars($page_title) ?></h2>
        <?php endif; ?>
        <article class="ja-content"><?= Shortcodes::render($page_content) ?></article>
        <?php Hooks::fire('content_after', $ja_page); ?>
    </div>
</main>

<footer>
    <div class="container footer-inner">
        <span>&copy; <?= date('Y') ?> <?= htmlspecialchars($site_name) ?></span>
        <?php if ($footer_nav): ?>
            <nav aria-label="Footer navigation">
                <?php foreach ($footer_nav as $item): ?>
                    <a href="<?= htmlspecialchars($item['url']) ?>"><?= htmlspecialchars($item['label']) ?></a>
                <?php endforeach; ?>
            </nav>
        <?php endif; ?>
    </div>
</footer>

<?php Hooks::fire('body_end'); ?>
</body>
</html>
