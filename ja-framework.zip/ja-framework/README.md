# JA Framework

JA Framework is a small, modular content management system written in plain PHP and MySQL. It has no
build step, no Composer dependencies and no JavaScript framework. You upload the files, open the installer,
and you have a site, an admin panel, a page editor, menus, a media library, themes and plugins.

Almost everything beyond the core is a plugin or a theme, and the core is built so that a broken plugin
cannot take the site down.

**Contents**

1. [Requirements](#1-requirements)
2. [Installing](#2-installing)
3. [Folder layout](#3-folder-layout)
4. [How a request works](#4-how-a-request-works)
5. [The admin panel and signing in](#5-the-admin-panel-and-signing-in)
6. [Configuration](#6-configuration)
7. [Database](#7-database)
8. [Core classes](#8-core-classes)
9. [Media and uploads](#9-media-and-uploads)
10. [Security notes](#10-security-notes)
11. [Deploying and maintaining](#11-deploying-and-maintaining)
12. [Troubleshooting](#12-troubleshooting)
13. [More documentation](#13-more-documentation)

---

## 1. Requirements

| | |
|---|---|
| PHP | 8.1 or newer |
| PHP extensions | `pdo_mysql`, `zip` (plugin and theme installs), `fileinfo` (upload checks), `dom` (SVG checks; without it SVG uploads are refused). Some plugins use `mbstring` when present |
| Database | MySQL or MariaDB with InnoDB. The database must already exist and the user needs full rights on it |
| Web server | Apache or LiteSpeed with `mod_rewrite` and `.htaccess` enabled |
| Mail | PHP's `mail()` must work, because sign-in links are sent by email |

The site must be served from the folder that contains this project's `.htaccess`. That file sends page
requests into `public/`, lets files that really exist (such as theme and plugin stylesheets) be served as they
are, and blocks `.env`, `.sql`, `.log`, `.md` and `.sh` files.

---

## 2. Installing

1. Upload the project to your web root.
2. Make sure the web server can write to the project root (the installer writes `.env` there) and to
   `public/uploads/`.
3. Visit `/install.php`. It checks the requirements above and shows what is missing.
4. Fill in the database details, site name, language, timezone, and **your admin email address**.
5. When it finishes, the installer creates the tables, seeds the default settings, writes `.env` (including
   `SITE_URL`, the address you installed from), creates a home page and **deletes itself**.
6. Go to `/ja-login.php`, enter the admin email, and click the link that arrives in your inbox.

**Reinstalling.** The installer refuses to run if `.env` exists. To start over, empty the database and
delete `.env`, then upload `public/install.php` again.

**Changing the database details later.** Edit `.env` (see section 6).

---

## 3. Folder layout

```text
.htaccess              routes page requests into public/, blocks .env, .sql, .log, .md and .sh files,
                       and refuses direct requests for PHP files inside ja-core/, ja-plugins/, ja-themes/
.env                   database credentials (created by the installer)
ja-core/               the framework itself
  autoload.php           class autoloader; loads config.php
  src/Core/              core classes (section 8)
ja-admin/              the admin panel (dashboard, layout, styles)
ja-plugins/            plugins, one folder each. Core plugins: media, menus, pages, plugins, settings, themes
ja-themes/             themes, one folder each, plus content-base.css (shared by every theme)
ja-content/            optional; holds an options-cache driver if a cache plugin installs one
public/                the only web-facing folder
  index.php              front controller for the public site
  ja-login.php           sign-in page
  install.php            installer (removes itself)
  uploads/               uploaded files, in year/month folders (PHP can never run here)
```

---

## 4. How a request works

### The public site (`public/index.php`)

1. If there is no `.env` and the installer exists, redirect to the installer.
2. Load the autoloader. This also loads `config.php`, which defines `JA_ROOT` and `JA_BASE_URL`, loads
   every option from the database in **one query**, and sets the timezone.
3. Connect to the database and load every enabled user plugin. Their `init()` methods register routes,
   hooks, shortcodes and assets.
4. Find the page to show, in this order:
   1. a route registered with `Router::add()`;
   2. a plugin listening on the `frontend_route` hook;
   3. the **homepage plugin** (Settings → Frontend), normally Pages, which looks the URL up as a page slug.
5. If nothing claimed the request, show a built-in "Welcome" page.
6. Load the active theme's `index.php`, which receives the page as `$ja_page`. If that theme is missing,
   the `default` theme is used. If that is missing too, a plain message is shown.

### The admin panel (`ja-admin/dashboard.php`)

1. Start the session. If nobody is signed in, redirect to the sign-in page.
2. Load every core and enabled plugin.
3. Handle any submitted form. All changes happen on **POST** with a CSRF token.
4. Render the screen the `?view=` parameter names, inside the admin layout.

### Signing in (`public/ja-login.php`)

Plugins load here too, so a plugin can block or throttle requests on the sign-in page. See section 5.

---

## 5. The admin panel and signing in

There are no passwords. Signing in uses a one-time link sent by email.

1. At `/ja-login.php`, enter an email address.
2. If the address is on the **admin list**, a link is emailed. The page shows the same message whether or not
   the address is on the list, so it never reveals who is an admin.
3. The link is single-use and valid for **15 minutes** (configurable, section 6). Only a hash of it is stored
   in the database.
4. Using it starts a session. Sign out with the *Log out* button in the top-right menu.

**Sessions.** The session cookie is `HttpOnly` and `SameSite=Lax`, and `Secure` whenever the site is served over
HTTPS. The session id is replaced at sign-in, and an admin who has been idle for 8 hours is signed out.
Signing out is a POST with a CSRF token.

**Who can sign in.** Settings → *Admin access* holds one email address per line. If that list is empty, the
site owner's address from the installer is used.

**Admin sections:** Dashboard, Media, Menus, Themes, Plugins and Settings are built in. Plugins add their own
entries (Pages, for example). There is also a Profile screen with a display name and an avatar.

---

## 6. Configuration

### `.env`

Created by the installer. Plain `KEY=value` lines:

```ini
DB_HOST=localhost
DB_NAME=your_database
DB_USER=your_user
DB_PASS="your password"
SITE_URL="https://example.com"
MAGIC_LINK_TTL=900
```

| Key | Meaning |
|---|---|
| `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS` | database connection |
| `SITE_URL` | the site's address, including any sub-folder. Used for every link the site builds, including sign-in emails. Set by the installer. If it is missing, or set to `auto`, the address is detected from the request instead |
| `MAGIC_LINK_TTL` | seconds a sign-in link stays valid, from 300 to 3600 (default 900) |

**Format.** One `KEY=value` per line. Lines starting with `#` or `;` are comments and may say anything.
Put a value in double quotes if it contains spaces or special characters (inside quotes, write `\"` for a quote
and `\\` for a backslash). A plain value may end with a ` # comment`. The framework reads this file with its own
forgiving reader (`Env`), so one unusual character never makes the whole file unreadable.

The `.env` file is blocked from the web by `.htaccess`. Keep it out of backups you share and out of version control.

### Options

Everything else is stored in the `ja_options` table and read with `Options::get()` / `Options::set()`. The
installer seeds these:

| Option | Meaning |
|---|---|
| `site_name`, `site_slogan`, `site_lang` | identity, shown by the theme |
| `site_logo`, `site_favicon` | file names in `public/uploads/` |
| `timezone` | PHP timezone, applied on every request |
| `active_theme` | folder name of the active theme (default `default`) |
| `active_plugins` | JSON list of enabled user plugins |
| `frontend_plugin` | the homepage plugin (default `ja-pages`) |
| `admin_email`, `admin_emails` | the owner address, and the JSON list of addresses allowed to sign in |
| `menus`, `menu_slot_primary`, `menu_slot_footer` | menus, and which one sits in each theme location |

Themes and plugins add their own options. Theme options are stored as `theme_<theme>_<name>`.

### The site address

`JA_BASE_URL` is the address every link is built from. If `.env` has a `SITE_URL`, that is used exactly, which
is the safe setting. If not, it is detected from the request (the host name is checked, but it still comes
from the visitor), and the dashboard reminds you to add `SITE_URL`. If your domain ever changes, edit
`SITE_URL`.

---

## 7. Database

| Table | Purpose |
|---|---|
| `ja_options` | all settings (name, value) |
| `ja_pages` | pages: title, slug, content, `is_home`, `in_menu`, `hide_title`, `status` (published or draft) |
| `ja_media` | one row per uploaded file |
| `ja_users` | admin profile (display name, avatar), keyed by email |
| `ja_auth_tokens` | sign-in links (single use, 15 minute expiry; old rows are pruned automatically) |

Plugins create their own tables, named `ja_<plugin>_…`, when they are enabled.

**Schema changes.** There is no migration system. New columns are added by the plugin that needs them the
first time it runs (for example Pages adds `hide_title` to older installs). Back up before upgrading.

---

## 8. Core classes

All live in `ja-core/src/Core/` under the namespace `JA\Core`.

| Class | Purpose |
|---|---|
| `Options` | read and write settings; options are loaded once per request. Also holds the optional cache driver hook |
| `Database` | the PDO connection (exceptions on, associative rows, real prepared statements) |
| `Env` | reads the `.env` file |
| `Auth`, `Mail` | sign-in links and the email that carries them |
| `Session` | the admin session: hardened cookie, sign-in, idle timeout and sign-out |
| `Hooks` | actions and filters that plugins and themes attach to |
| `Plugins` | finds, loads, enables, disables and uninstalls plugins |
| `Router` | front-end URLs claimed by plugins |
| `Content` | the page the theme is about to render |
| `SiteMenus` | menus for the public site's theme locations |
| `Shortcodes` | `[tag]` expansion in page content |
| `AdminMenu`, `AdminUI` | the admin sidebar, and helpers such as one-button POST forms |
| `Assets` | CSS and JS queued by plugins |
| `Theme` | per-theme options and the CSS variables built from them |
| `Media` | uploads, the media library, deletion |
| `Package` | the safe zip installer shared by plugins and themes |
| `OptionsBackend` | the interface an options-cache plugin implements |

Hooks, routes, assets and the plugin API are documented in `PLUGINS.md`; the theme API is in `theme.md`.

**Autoloading.** `JA\Core\Foo` loads from `ja-core/src/Core/Foo.php`. `JA\Plugins\Foo` loads from the
matching plugin folder, **but only if that plugin is enabled or a core plugin**, so a disabled plugin can't be
reached through a URL.

---

## 9. Media and uploads

- Allowed types: JPG, PNG, GIF, ICO and SVG.
- Each file is checked twice: by extension, and by its **real content** (not the name or browser-supplied
  type), so a renamed file is rejected.
- **SVG files are validated and rejected, not cleaned.** An SVG must be well-formed XML under 1 MB with an
  `<svg>` root, and must contain no scripts, event handlers (`onload=`, `onclick=`, …), `javascript:` or
  `data:` links (small embedded PNG/JPEG/GIF/WebP images are fine), `<foreignObject>`, animation elements that
  can set links, external style imports, or entity declarations.
- Files are stored as `public/uploads/YYYY/MM/ja_<random>.<ext>`, so original names never reach the web.
- Deleting a file in the library removes the file and its database row.
- The size limit is whatever your PHP configuration allows (`upload_max_filesize` and `post_max_size`).

---

## 10. Security notes

### What the framework already does

- Sign-in links are random (256 bits), single-use, short-lived and **stored only as a hash**.
- The sign-in form does not reveal which addresses are admins.
- Admin sessions use hardened cookies, a fresh session id at sign-in, an idle timeout and a POST-only sign-out.
- Links in sign-in emails always use the configured `SITE_URL`, and the host name is validated when it has to
  be detected.
- Every change in the admin is a POST with a CSRF token; state-changing links do not exist.
- All database access uses prepared statements, and all output is escaped.
- Uploads are validated by content and stored under random names. SVGs with anything risky are rejected, and
  PHP can never run from the uploads folder.
- Plugin and theme zips are checked entry by entry before anything is extracted, and core plugins and the
  default theme cannot be replaced.
- A plugin that crashes is skipped and logged, so you can still reach the admin to disable it.
- `.env`, `.sql`, `.log`, `.md` and `.sh` files are blocked from the web, and PHP files inside `ja-core/`,
  `ja-plugins/` and `ja-themes/` refuse direct requests.

### Known limitations

1. **Email uses PHP's `mail()`.** If your host's mail is unreliable, sign-ins will be too. There is no SMTP
   option in the core.
2. **There is no built-in rate limiting.** The bundled Security Suite plugin adds login throttling, IP blocking
   and an audit log.
3. **SVG checking is rule-based.** It rejects everything on a list of known-risky constructs. It is strict,
   but not a substitute for only uploading SVGs from sources you trust.
4. **Sites installed before `SITE_URL` was pinned** still detect their address from the request until you
   add it to `.env` (the dashboard tells you).
5. **`display_errors`** is controlled by your PHP configuration. If it is on in production, an error page can
   reveal file paths.

### Hardening checklist

- Serve the site over HTTPS only (the session cookie then becomes `Secure` automatically), and make sure
  `SITE_URL` in `.env` starts with `https://`.
- Set `display_errors=Off` (and keep `log_errors=On`) in production.
- Set permissions so the web server can write only to `public/uploads/`, `ja-content/` and, while installing,
  the project root.
- Keep regular database backups.
- Enable the Security Suite plugin, and only install plugins and themes you trust. They run with full access.

---

## 11. Deploying and maintaining

**Routing.** The root `.htaccess` sends `/install.php`, `/ja-admin/…` and everything else to the right place.
It was written for LiteSpeed and works on Apache. On Nginx you will need equivalent rewrite rules:
send everything that is not an existing file to `public/index.php`, and keep `.env` and `ja-core/` from being
served.

**Upgrading.**
1. Back up the database and the files.
2. Upload the new files over the old ones. Keep your `.env`, `public/uploads/`, `ja-content/` and any plugins and
   themes of your own.
3. Open the admin and check each screen. Plugins add any new database columns the first time they run.
4. If your `.env` has no real `SITE_URL` (older installs have `SITE_URL=auto`), add your site's address, for
   example `SITE_URL="https://example.com"`.

Sign-in links requested before an upgrade to the hashed-token version stop working, so request a new one.

**Backups.** The site's state is the database plus `public/uploads/` and your own plugins and themes.

**Errors.** PHP errors go to the server's error log. Plugin failures are logged with the plugin's name.

---

## 12. Troubleshooting

| Problem | Try this |
|---|---|
| The sign-in email never arrives | Check the spam folder, and that the address is on the admin list. Confirm PHP's `mail()` works on the host. Ask the host about outgoing mail |
| "Too many login requests" | The Security Suite throttle. Wait 15 minutes |
| Sign-in emails link to the wrong address | Set `SITE_URL` in `.env` to your real address, including `https://` and any sub-folder |
| Signed out unexpectedly | Admin sessions end after 8 hours without activity. Sign in again |
| An SVG upload is rejected | It contains something the checker refuses (scripts, event handlers, external content). Re-export it as a plain SVG, or use PNG |
| Blank page or HTTP 500 | Check the PHP error log. Confirm PHP is 8.1 or newer and the extensions in section 1 are on |
| "JA Framework Error: .env file not found at …" | The file really is missing at that path. Run the installer, or restore `.env` |
| "JA Framework Error: DB_… is missing from …" | `.env` exists but lacks `DB_HOST`, `DB_NAME` or `DB_USER`. Add the line |
| "JA Framework Connection Error: …" | `.env` was read, but the database refused the connection. Check the host, name, user and password |
| "No theme found" | Restore the `default` theme folder in `ja-themes/` |
| A plugin broke something | Plugins that crash are skipped automatically. Disable it under Plugins. If you cannot reach the screen, rename its folder |
| Changed a setting and the site did not update | If a cache plugin is enabled, use its Flush button. Editing `ja_options` by hand does not clear the cache |
| Uploads fail | Check that `public/uploads/` is writable, and PHP's `upload_max_filesize` |
| Locked out of the admin | Sign in with an address on the admin list. If you removed every address, the owner address in the `admin_email` option still works. You can edit it in the database |

---

## 13. More documentation

| File | For |
|---|---|
| `PLUGINS.md` | writing plugins: the class, admin screens, routes, hooks, assets and data |
| `theme.md` | writing themes: the template, required hooks, options and CSS |
| `CACHE.md` | the optional options cache, and how to write a cache driver |
