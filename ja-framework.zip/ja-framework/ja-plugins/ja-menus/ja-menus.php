<?php
namespace JA\Plugins;
use JA\Core\SiteMenus;
use JA\Core\Assets;
use JA\Core\Options;

class Menus {
    public static function init() {
        // Menus appears in the core sidebar — no need to register via Hooks
    }

    public static function renderAdmin($db, $csrf = '') {
        $menus   = SiteMenus::all();
        $active  = $_GET['menu'] ?? (empty($menus) ? '' : array_key_first($menus));

        $html  = "<h1 class='ja-page-header'>Menus</h1>";

        // --- Menu locations card ---
        $slot_primary = Options::get('menu_slot_primary', '');
        $slot_footer  = Options::get('menu_slot_footer', '');
        $html .= "<div class='ja-card' style='margin-bottom:20px;'>";
        $html .= "<h3>Menu locations</h3>";
        $html .= "<p style='font-size:13px;color:#888;margin:-4px 0 16px;'>Assign menus to theme slots. Your active theme uses these to render navigation.</p>";
        $html .= "<form method='POST' style='display:grid;grid-template-columns:1fr 1fr;gap:16px;'>";
        $html .= "<input type='hidden' name='csrf' value='" . htmlspecialchars($csrf) . "'>";
        $html .= "<input type='hidden' name='ja_action' value='save_menu_slots'>";
        foreach (['primary' => 'Primary navigation', 'footer' => 'Footer navigation'] as $slot => $label) {
            $current = $slot === 'primary' ? $slot_primary : $slot_footer;
            $html .= "<div><label class='ja-label'>{$label}</label>";
            $html .= "<select name='menu_slot_{$slot}' class='ja-select' style='margin:0;'>";
            $html .= "<option value=''" . ($current === '' ? ' selected' : '') . ">— None —</option>";
            foreach ($menus as $key => $menu) {
                $sel   = $current === $key ? ' selected' : '';
                $html .= "<option value='" . htmlspecialchars($key) . "'{$sel}>" . htmlspecialchars($menu['name']) . "</option>";
            }
            $html .= "</select></div>";
        }
        $html .= "<div style='grid-column:1/-1;'><button type='submit' class='ja-btn ja-btn-primary'>Save locations</button></div>";
        $html .= "</form></div>";

        // --- Top bar: menu tabs + add menu form ---
        $html .= "<div style='display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:20px;'>";

        // Tabs
        foreach ($menus as $key => $menu) {
            $cls   = $active === $key ? 'ja-btn ja-btn-primary ja-btn-sm' : 'ja-btn ja-btn-secondary ja-btn-sm';
            $html .= "<a href='?view=menus&menu=" . urlencode($key) . "' class='{$cls}'>" . htmlspecialchars($menu['name']) . "</a>";
        }

        // Add menu button/form (inline popover via details/summary)
        $html .= "<details style='position:relative;'>";
        $html .= "<summary class='ja-btn ja-btn-secondary ja-btn-sm' style='list-style:none;cursor:pointer;'>+ Add menu</summary>";
        $html .= "<div style='position:absolute;top:calc(100% + 8px);left:0;background:#fff;border:1px solid #e5e5e3;border-radius:10px;padding:16px;width:260px;z-index:100;box-shadow:0 4px 16px rgba(0,0,0,.08);'>";
        $html .= "<form method='POST'>";
        $html .= "<input type='hidden' name='csrf' value='" . htmlspecialchars($csrf) . "'>";
        $html .= "<input type='hidden' name='ja_action' value='add_menu'>";
        $html .= "<label class='ja-label'>Menu name</label>";
        $html .= "<input type='text' name='menu_name' class='ja-input' placeholder='e.g. Footer' required>";
        $html .= "<button type='submit' class='ja-btn ja-btn-primary' style='width:100%'>Create</button>";
        $html .= "</form></div></details>";
        $html .= "</div>";

        // --- No menus yet ---
        if (empty($menus)) {
            $html .= "<div class='ja-card'><p style='color:#aaa;font-size:14px;margin:0;'>No menus yet. Create one above.</p></div>";
            return $html;
        }

        // --- Active menu editor ---
        if (!isset($menus[$active])) $active = array_key_first($menus);
        $menu    = $menus[$active];
        $enabled = !empty($menu['enabled']);
        $items   = $menu['items'] ?? [];

        $html .= "<div class='ja-card'>";

        // Toggle + rename + delete row
        $html .= "<div style='display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:20px;padding-bottom:20px;border-bottom:1px solid #f0f0ee;'>";

        // Enabled toggle
        $tog_label = $enabled ? 'Enabled' : 'Disabled';
        $html .= \JA\Core\AdminUI::postButton($tog_label, 'toggle_menu', ['menu_key' => $active], $csrf, 'ja-btn ja-btn-sm ' . ($enabled ? 'ja-btn-success' : 'ja-btn-secondary'));

        // Rename form
        $html .= "<form method='POST' style='display:flex;gap:8px;flex:1;min-width:180px;'>";
        $html .= "<input type='hidden' name='csrf' value='" . htmlspecialchars($csrf) . "'>";
        $html .= "<input type='hidden' name='ja_action' value='rename_menu'>";
        $html .= "<input type='hidden' name='menu_key' value='" . htmlspecialchars($active) . "'>";
        $html .= "<input type='text' name='menu_name' class='ja-input' style='margin:0;' value='" . htmlspecialchars($menu['name']) . "'>";
        $html .= "<button type='submit' class='ja-btn ja-btn-secondary ja-btn-sm'>Rename</button>";
        $html .= "</form>";

        // Delete menu
        if (count($menus) > 1) {
            $html .= \JA\Core\AdminUI::postButton('Delete', 'delete_menu', ['menu_key' => $active], $csrf, 'ja-btn ja-btn-danger ja-btn-sm', 'Delete this menu?');
        }

        $html .= "</div>";

        // Drag-drop item list
        $html .= "<div id='ja-menu-list' data-csrf='" . htmlspecialchars($csrf, ENT_QUOTES) . "' data-menu='" . htmlspecialchars($active, ENT_QUOTES) . "' style='margin-bottom:20px;'>";
        if (empty($items)) {
            $html .= "<p style='color:#aaa;font-size:14px;margin:0 0 16px;'>No items yet. Add one below.</p>";
        }
        foreach ($items as $i => $item) {
            $html .= "<div class='ja-menu-row' draggable='true' data-index='{$i}' style='display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid #f0f0ee;cursor:default;'>";
            $html .= "<span class='ja-drag-handle' style='color:#ccc;cursor:grab;font-size:18px;user-select:none;'>⠿</span>";
            // Inline edit form
            $html .= "<form method='POST' style='display:flex;gap:8px;flex:1;align-items:center;flex-wrap:wrap;'>";
            $html .= "<input type='hidden' name='csrf' value='" . htmlspecialchars($csrf) . "'>";
            $html .= "<input type='hidden' name='ja_action' value='update_item'>";
            $html .= "<input type='hidden' name='menu_key' value='" . htmlspecialchars($active) . "'>";
            $html .= "<input type='hidden' name='item_index' value='{$i}'>";
            $html .= "<input type='text' name='item_label' class='ja-input' style='margin:0;flex:1;min-width:100px;' value='" . htmlspecialchars($item['label']) . "' placeholder='Label'>";
            $html .= "<input type='text' name='item_url' class='ja-input' style='margin:0;flex:2;min-width:140px;' value='" . htmlspecialchars($item['url']) . "' placeholder='URL'>";
            $html .= "<button type='submit' class='ja-btn ja-btn-secondary ja-btn-sm'>Save</button>";
            $html .= "</form>";
            // Delete item
            $html .= \JA\Core\AdminUI::postButton('✕', 'delete_item', ['menu_key' => $active, 'item_index' => $i], $csrf, 'ja-btn ja-btn-danger ja-btn-sm', 'Remove this item?');
            $html .= "</div>";
        }
        $html .= "</div>";

        // Add item form
        $html .= "<form method='POST' style='display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end;padding-top:16px;border-top:1px solid #f0f0ee;'>";
        $html .= "<input type='hidden' name='csrf' value='" . htmlspecialchars($csrf) . "'>";
        $html .= "<input type='hidden' name='ja_action' value='add_item'>";
        $html .= "<input type='hidden' name='menu_key' value='" . htmlspecialchars($active) . "'>";
        $html .= "<div style='flex:1;min-width:120px;'><label class='ja-label'>Label</label><input type='text' name='item_label' class='ja-input' style='margin:0;' placeholder='Home' required></div>";
        $html .= "<div style='flex:2;min-width:160px;'><label class='ja-label'>URL</label><input type='text' name='item_url' class='ja-input' style='margin:0;' placeholder='/' required></div>";
        $html .= "<button type='submit' class='ja-btn ja-btn-primary'>Add item</button>";
        $html .= "</form>";

        $html .= "</div>";

        // Drag-and-drop reordering lives in assets/menus.js (reads data-csrf / data-menu from the list)
        Assets::script('ja-menus', Assets::pluginUrl('ja-menus', 'assets/menus.js'), true, 'admin');

        return $html;
    }

    public static function handleSave($db, $post) {
        $action   = $post['ja_action'] ?? '';
        $menus    = SiteMenus::all();
        $menu_key = is_string($post['menu_key'] ?? null) ? $post['menu_key'] : '';

        switch ($action) {

            case 'save_menu_slots':
                Options::set('menu_slot_primary', $post['menu_slot_primary'] ?? '');
                Options::set('menu_slot_footer',  $post['menu_slot_footer']  ?? '');
                break;

            case 'add_menu':
                $name = trim($post['menu_name'] ?? '');
                if (!$name) break;
                $key = 'menu_' . preg_replace('/[^a-z0-9]/', '_', strtolower($name)) . '_' . substr(uniqid(), -4);
                $menus[$key] = ['name' => $name, 'enabled' => true, 'items' => []];
                SiteMenus::save($menus);
                // Redirect to new menu tab
                header("Location: ?view=menus&menu=" . urlencode($key));
                exit;

            case 'rename_menu':
                if (!$menu_key || !isset($menus[$menu_key])) break;
                $name = trim($post['menu_name'] ?? '');
                if ($name) $menus[$menu_key]['name'] = $name;
                SiteMenus::save($menus);
                break;

            case 'add_item':
                if (!$menu_key || !isset($menus[$menu_key])) break;
                $label = trim($post['item_label'] ?? '');
                $url   = trim($post['item_url']   ?? '');
                if ($label && $url) {
                    $menus[$menu_key]['items'][] = ['label' => $label, 'url' => $url];
                    SiteMenus::save($menus);
                }
                break;

            case 'update_item':
                if (!$menu_key || !isset($menus[$menu_key])) break;
                $idx   = (int)($post['item_index'] ?? -1);
                $label = trim($post['item_label'] ?? '');
                $url   = trim($post['item_url']   ?? '');
                if ($idx >= 0 && isset($menus[$menu_key]['items'][$idx]) && $label && $url) {
                    $menus[$menu_key]['items'][$idx] = ['label' => $label, 'url' => $url];
                    SiteMenus::save($menus);
                }
                break;

            case 'toggle_menu':
                self::handleToggle($menu_key);
                break;

            case 'delete_menu':
                self::handleDeleteMenu($menu_key);
                break;

            case 'delete_item':
                self::handleDeleteItem($menu_key, $post['item_index'] ?? -1);
                break;

            case 'reorder_items':
                if (!$menu_key || !isset($menus[$menu_key])) break;
                $order = array_map('intval', explode(',', $post['item_order'] ?? ''));
                $items = $menus[$menu_key]['items'];
                $reordered = [];
                foreach ($order as $idx) {
                    if (isset($items[$idx])) $reordered[] = $items[$idx];
                }
                $menus[$menu_key]['items'] = $reordered;
                SiteMenus::save($menus);
                break;
        }

        return true;
    }

    // Row-action handlers, called from handleSave() (POST only)
    public static function handleToggle($menu_key) {
        $menus = SiteMenus::all();
        if (!isset($menus[$menu_key])) return;
        $menus[$menu_key]['enabled'] = empty($menus[$menu_key]['enabled']);
        SiteMenus::save($menus);
    }

    public static function handleDeleteMenu($menu_key) {
        $menus = SiteMenus::all();
        if (!isset($menus[$menu_key])) return;
        unset($menus[$menu_key]);
        SiteMenus::save($menus);

        // Don't leave a location pointing at a menu that no longer exists
        foreach (['primary', 'footer'] as $slot) {
            if (Options::get('menu_slot_' . $slot, '') === $menu_key) {
                Options::set('menu_slot_' . $slot, '');
            }
        }
    }

    public static function handleDeleteItem($menu_key, $index) {
        $menus = SiteMenus::all();
        if (!isset($menus[$menu_key]['items'])) return;
        $index = (int) $index;
        // A negative index would make array_splice remove the LAST item
        if ($index < 0 || $index >= count($menus[$menu_key]['items'])) return;
        array_splice($menus[$menu_key]['items'], $index, 1);
        SiteMenus::save($menus);
    }
}
