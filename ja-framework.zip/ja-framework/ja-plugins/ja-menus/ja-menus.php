<?php
namespace JA\Plugins;
use JA\Core\Hooks;
use JA\Core\Options;

class Menus {
    public static function init() {
        // Menus appears in the core sidebar — no need to register via Hooks
    }

    public static function renderAdmin($db, $csrf = '') {
        $menus   = Hooks::get_all_menus();
        $t       = urlencode($csrf);
        $active  = $_GET['menu'] ?? (empty($menus) ? '' : array_key_first($menus));

        $html  = "<h1 class='ja-page-header'>Menus</h1>";

        // --- Menu locations card ---
        $slot_primary = Options::get('menu_slot_primary', '');
        $slot_footer  = Options::get('menu_slot_footer', '');
        $html .= "<div class='ja-card' style='margin-bottom:20px;'>";
        $html .= "<h3>Menu locations</h3>";
        $html .= "<p style='font-size:13px;color:#888;margin:-4px 0 16px;'>Assign menus to theme slots. Your active theme uses these to render navigation.</p>";
        $html .= "<form method='POST' style='display:grid;grid-template-columns:1fr 1fr;gap:16px;'>";
        $html .= "<input type='hidden' name='csrf' value='" . htmlspecialchars($csrf) . "'>";
        $html .= "<input type='hidden' name='ja_action' value='save_menu_slots'>";
        foreach (['primary' => 'Primary navigation', 'footer' => 'Footer navigation'] as $slot => $label) {
            $current = $slot === 'primary' ? $slot_primary : $slot_footer;
            $html .= "<div><label class='ja-label'>{$label}</label>";
            $html .= "<select name='menu_slot_{$slot}' class='ja-select' style='margin:0;'>";
            $html .= "<option value=''" . ($current === '' ? ' selected' : '') . ">— None —</option>";
            foreach ($menus as $key => $menu) {
                $sel   = $current === $key ? ' selected' : '';
                $html .= "<option value='" . htmlspecialchars($key) . "'{$sel}>" . htmlspecialchars($menu['name']) . "</option>";
            }
            $html .= "</select></div>";
        }
        $html .= "<div style='grid-column:1/-1;'><button type='submit' class='ja-btn ja-btn-primary'>Save locations</button></div>";
        $html .= "</form></div>";

        // --- Top bar: menu tabs + add menu form ---
        $html .= "<div style='display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:20px;'>";

        // Tabs
        foreach ($menus as $key => $menu) {
            $cls   = $active === $key ? 'ja-btn ja-btn-primary ja-btn-sm' : 'ja-btn ja-btn-secondary ja-btn-sm';
            $html .= "<a href='?view=menus&menu=" . urlencode($key) . "' class='{$cls}'>" . htmlspecialchars($menu['name']) . "</a>";
        }

        // Add menu button/form (inline popover via details/summary)
        $html .= "<details style='position:relative;'>";
        $html .= "<summary class='ja-btn ja-btn-secondary ja-btn-sm' style='list-style:none;cursor:pointer;'>+ Add menu</summary>";
        $html .= "<div style='position:absolute;top:calc(100% + 8px);left:0;background:#fff;border:1px solid #e5e5e3;border-radius:10px;padding:16px;width:260px;z-index:100;box-shadow:0 4px 16px rgba(0,0,0,.08);'>";
        $html .= "<form method='POST'>";
        $html .= "<input type='hidden' name='csrf' value='" . htmlspecialchars($csrf) . "'>";
        $html .= "<input type='hidden' name='ja_action' value='add_menu'>";
        $html .= "<label class='ja-label'>Menu name</label>";
        $html .= "<input type='text' name='menu_name' class='ja-input' placeholder='e.g. Footer' required>";
        $html .= "<button type='submit' class='ja-btn ja-btn-primary' style='width:100%'>Create</button>";
        $html .= "</form></div></details>";
        $html .= "</div>";

        // --- No menus yet ---
        if (empty($menus)) {
            $html .= "<div class='ja-card'><p style='color:#aaa;font-size:14px;margin:0;'>No menus yet. Create one above.</p></div>";
            return $html;
        }

        // --- Active menu editor ---
        if (!isset($menus[$active])) $active = array_key_first($menus);
        $menu    = $menus[$active];
        $enabled = !empty($menu['enabled']);
        $items   = $menu['items'] ?? [];

        $html .= "<div class='ja-card'>";

        // Toggle + rename + delete row
        $html .= "<div style='display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:20px;padding-bottom:20px;border-bottom:1px solid #f0f0ee;'>";

        // Enabled toggle
        $tog_label = $enabled ? 'Enabled' : 'Disabled';
        $tog_cls   = $enabled ? 'action-enable' : 'action-disable';
        $html .= "<a href='?view=menus&menu=" . urlencode($active) . "&toggle_menu=" . urlencode($active) . "&_token={$t}' class='ja-btn ja-btn-sm " . ($enabled ? 'ja-btn-success' : 'ja-btn-secondary') . "'>{$tog_label}</a>";

        // Rename form
        $html .= "<form method='POST' style='display:flex;gap:8px;flex:1;min-width:180px;'>";
        $html .= "<input type='hidden' name='csrf' value='" . htmlspecialchars($csrf) . "'>";
        $html .= "<input type='hidden' name='ja_action' value='rename_menu'>";
        $html .= "<input type='hidden' name='menu_key' value='" . htmlspecialchars($active) . "'>";
        $html .= "<input type='text' name='menu_name' class='ja-input' style='margin:0;' value='" . htmlspecialchars($menu['name']) . "'>";
        $html .= "<button type='submit' class='ja-btn ja-btn-secondary ja-btn-sm'>Rename</button>";
        $html .= "</form>";

        // Delete menu
        if (count($menus) > 1) {
            $html .= "<a href='?view=menus&menu=" . urlencode($active) . "&delete_menu=" . urlencode($active) . "&_token={$t}' class='ja-btn ja-btn-danger ja-btn-sm' onclick='return confirm(\"Delete this menu?\")'>Delete</a>";
        }

        $html .= "</div>";

        // Drag-drop item list
        $html .= "<div id='ja-menu-list' style='margin-bottom:20px;'>";
        if (empty($items)) {
            $html .= "<p style='color:#aaa;font-size:14px;margin:0 0 16px;'>No items yet. Add one below.</p>";
        }
        foreach ($items as $i => $item) {
            $html .= "<div class='ja-menu-row' draggable='true' data-index='{$i}' style='display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid #f0f0ee;cursor:default;'>";
            $html .= "<span class='ja-drag-handle' style='color:#ccc;cursor:grab;font-size:18px;user-select:none;'>⠿</span>";
            // Inline edit form
            $html .= "<form method='POST' style='display:flex;gap:8px;flex:1;align-items:center;flex-wrap:wrap;'>";
            $html .= "<input type='hidden' name='csrf' value='" . htmlspecialchars($csrf) . "'>";
            $html .= "<input type='hidden' name='ja_action' value='update_item'>";
            $html .= "<input type='hidden' name='menu_key' value='" . htmlspecialchars($active) . "'>";
            $html .= "<input type='hidden' name='item_index' value='{$i}'>";
            $html .= "<input type='text' name='item_label' class='ja-input' style='margin:0;flex:1;min-width:100px;' value='" . htmlspecialchars($item['label']) . "' placeholder='Label'>";
            $html .= "<input type='text' name='item_url' class='ja-input' style='margin:0;flex:2;min-width:140px;' value='" . htmlspecialchars($item['url']) . "' placeholder='URL'>";
            $html .= "<button type='submit' class='ja-btn ja-btn-secondary ja-btn-sm'>Save</button>";
            $html .= "</form>";
            // Delete item
            $html .= "<a href='?view=menus&menu=" . urlencode($active) . "&delete_item={$i}&_token={$t}' class='ja-btn ja-btn-danger ja-btn-sm' onclick='return confirm(\"Remove this item?\")'>✕</a>";
            $html .= "</div>";
        }
        $html .= "</div>";

        // Add item form
        $html .= "<form method='POST' style='display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end;padding-top:16px;border-top:1px solid #f0f0ee;'>";
        $html .= "<input type='hidden' name='csrf' value='" . htmlspecialchars($csrf) . "'>";
        $html .= "<input type='hidden' name='ja_action' value='add_item'>";
        $html .= "<input type='hidden' name='menu_key' value='" . htmlspecialchars($active) . "'>";
        $html .= "<div style='flex:1;min-width:120px;'><label class='ja-label'>Label</label><input type='text' name='item_label' class='ja-input' style='margin:0;' placeholder='Home' required></div>";
        $html .= "<div style='flex:2;min-width:160px;'><label class='ja-label'>URL</label><input type='text' name='item_url' class='ja-input' style='margin:0;' placeholder='/' required></div>";
        $html .= "<button type='submit' class='ja-btn ja-btn-primary'>Add item</button>";
        $html .= "</form>";

        $html .= "</div>";

        // Drag-drop JS
        $html .= "
<script>
(function() {
    var list    = document.getElementById('ja-menu-list');
    var rows    = list ? Array.from(list.querySelectorAll('.ja-menu-row')) : [];
    var dragSrc = null;

    rows.forEach(function(row) {
        row.addEventListener('dragstart', function(e) {
            dragSrc = row;
            e.dataTransfer.effectAllowed = 'move';
            row.style.opacity = '0.4';
        });
        row.addEventListener('dragend', function() {
            row.style.opacity = '';
            list.querySelectorAll('.ja-menu-row').forEach(function(r) {
                r.style.borderTop = '';
            });
        });
        row.addEventListener('dragover', function(e) {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            list.querySelectorAll('.ja-menu-row').forEach(function(r) { r.style.borderTop = ''; });
            row.style.borderTop = '2px solid #111';
        });
        row.addEventListener('drop', function(e) {
            e.preventDefault();
            if (dragSrc === row) return;
            // Build new order
            var allRows = Array.from(list.querySelectorAll('.ja-menu-row'));
            var order   = allRows.map(function(r) { return parseInt(r.dataset.index); });
            var fromIdx = parseInt(dragSrc.dataset.index);
            var toIdx   = parseInt(row.dataset.index);
            order.splice(order.indexOf(fromIdx), 1);
            order.splice(order.indexOf(toIdx), 0, fromIdx);
            // POST new order
            var form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            var fields = {
                csrf:       " . json_encode($csrf) . ",
                ja_action:  'reorder_items',
                menu_key:   " . json_encode($active) . ",
                item_order: order.join(',')
            };
            Object.entries(fields).forEach(function(kv) {
                var inp = document.createElement('input');
                inp.name = kv[0]; inp.value = kv[1];
                form.appendChild(inp);
            });
            document.body.appendChild(form);
            form.submit();
        });
    });
})();
</script>";

        return $html;
    }

    public static function handleSave($db, $post) {
        $action   = $post['ja_action'] ?? '';
        $menus    = Hooks::get_all_menus();
        $menu_key = $post['menu_key'] ?? '';

        switch ($action) {

            case 'save_menu_slots':
                Options::set('menu_slot_primary', $post['menu_slot_primary'] ?? '');
                Options::set('menu_slot_footer',  $post['menu_slot_footer']  ?? '');
                break;

            case 'add_menu':
                $name = trim($post['menu_name'] ?? '');
                if (!$name) break;
                $key = 'menu_' . preg_replace('/[^a-z0-9]/', '_', strtolower($name)) . '_' . substr(uniqid(), -4);
                $menus[$key] = ['name' => $name, 'enabled' => true, 'items' => []];
                Hooks::save_menus($menus);
                // Redirect to new menu tab
                header("Location: ?view=menus&menu=" . urlencode($key));
                exit;

            case 'rename_menu':
                if (!$menu_key || !isset($menus[$menu_key])) break;
                $name = trim($post['menu_name'] ?? '');
                if ($name) $menus[$menu_key]['name'] = $name;
                Hooks::save_menus($menus);
                break;

            case 'add_item':
                if (!$menu_key || !isset($menus[$menu_key])) break;
                $label = trim($post['item_label'] ?? '');
                $url   = trim($post['item_url']   ?? '');
                if ($label && $url) {
                    $menus[$menu_key]['items'][] = ['label' => $label, 'url' => $url];
                    Hooks::save_menus($menus);
                }
                break;

            case 'update_item':
                if (!$menu_key || !isset($menus[$menu_key])) break;
                $idx   = (int)($post['item_index'] ?? -1);
                $label = trim($post['item_label'] ?? '');
                $url   = trim($post['item_url']   ?? '');
                if ($idx >= 0 && isset($menus[$menu_key]['items'][$idx]) && $label && $url) {
                    $menus[$menu_key]['items'][$idx] = ['label' => $label, 'url' => $url];
                    Hooks::save_menus($menus);
                }
                break;

            case 'reorder_items':
                if (!$menu_key || !isset($menus[$menu_key])) break;
                $order = array_map('intval', explode(',', $post['item_order'] ?? ''));
                $items = $menus[$menu_key]['items'];
                $reordered = [];
                foreach ($order as $idx) {
                    if (isset($items[$idx])) $reordered[] = $items[$idx];
                }
                $menus[$menu_key]['items'] = $reordered;
                Hooks::save_menus($menus);
                break;
        }

        return true;
    }

    // GET action handlers called from dashboard
    public static function handleToggle($menu_key) {
        $menus = Hooks::get_all_menus();
        if (!isset($menus[$menu_key])) return;
        $menus[$menu_key]['enabled'] = empty($menus[$menu_key]['enabled']) ? true : false;
        Hooks::save_menus($menus);
    }

    public static function handleDeleteMenu($menu_key) {
        $menus = Hooks::get_all_menus();
        unset($menus[$menu_key]);
        Hooks::save_menus($menus);
    }

    public static function handleDeleteItem($menu_key, $index) {
        $menus = Hooks::get_all_menus();
        if (!isset($menus[$menu_key])) return;
        array_splice($menus[$menu_key]['items'], (int)$index, 1);
        Hooks::save_menus($menus);
    }
}
