/* JA Menus — drag-and-drop reordering. Loaded via Assets. */
(function() {
    var list    = document.getElementById('ja-menu-list');
    var rows    = list ? Array.from(list.querySelectorAll('.ja-menu-row')) : [];
    var dragSrc = null;

    rows.forEach(function(row) {
        row.addEventListener('dragstart', function(e) {
            dragSrc = row;
            e.dataTransfer.effectAllowed = 'move';
            row.style.opacity = '0.4';
        });
        row.addEventListener('dragend', function() {
            row.style.opacity = '';
            list.querySelectorAll('.ja-menu-row').forEach(function(r) {
                r.style.borderTop = '';
            });
        });
        row.addEventListener('dragover', function(e) {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            list.querySelectorAll('.ja-menu-row').forEach(function(r) { r.style.borderTop = ''; });
            row.style.borderTop = '2px solid #111';
        });
        row.addEventListener('drop', function(e) {
            e.preventDefault();
            if (dragSrc === row) return;
            // Build new order
            var allRows = Array.from(list.querySelectorAll('.ja-menu-row'));
            var order   = allRows.map(function(r) { return parseInt(r.dataset.index); });
            var fromIdx = parseInt(dragSrc.dataset.index);
            var toIdx   = parseInt(row.dataset.index);
            order.splice(order.indexOf(fromIdx), 1);
            order.splice(order.indexOf(toIdx), 0, fromIdx);
            // POST new order
            var form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            var fields = {
                csrf:       list.dataset.csrf,
                ja_action:  'reorder_items',
                menu_key:   list.dataset.menu,
                item_order: order.join(',')
            };
            Object.entries(fields).forEach(function(kv) {
                var inp = document.createElement('input');
                inp.name = kv[0]; inp.value = kv[1];
                form.appendChild(inp);
            });
            document.body.appendChild(form);
            form.submit();
        });
    });
})();
