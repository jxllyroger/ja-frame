<?php
namespace JA\Plugins;
use JA\Core\Options;
use JA\Core\Media;

class Settings {
    private static $allowed_keys = [
        'site_name', 'site_slogan', 'site_logo', 'site_favicon',
        'site_lang', 'timezone', 'frontend_plugin',
    ];

    public static function init() {}

    public static function renderAdmin($db, $csrf = '') {
        $media = Media::getAll($db);

        // Frontend plugin discovery (cached)
        $core_plugins = ['ja-media', 'ja-settings', 'ja-themes', 'ja-plugins', 'ja-menus'];
        $enabled_list = json_decode(Options::get('active_plugins', '[]'), true) ?: [];
        $enabled_hash = md5(serialize($enabled_list));
        $cached       = json_decode(Options::get('_frontend_plugins_cache', '{}'), true) ?: [];
        if (($cached['hash'] ?? '') !== $enabled_hash) {
            $plugin_dirs = array_filter(glob(JA_ROOT . '/ja-plugins/*'), 'is_dir');
            $capable     = [];
            foreach ($plugin_dirs as $dir) {
                $id   = basename($dir);
                $file = $dir . '/' . $id . '.php';
                if (!file_exists($file) || in_array($id, $core_plugins) || !in_array($id, $enabled_list)) continue;
                if (preg_match('/function\s+bootFrontend\s*\(/', file_get_contents($file))) $capable[] = $id;
            }
            $cached = ['hash' => $enabled_hash, 'plugins' => $capable];
            Options::set('_frontend_plugins_cache', json_encode($cached));
        }
        $frontend_opts    = array_combine($cached['plugins'], $cached['plugins']);
        $current_frontend = Options::get('frontend_plugin', '');

        $html  = "<h1 class='ja-page-header'>Settings</h1>";
        $html .= "<form method='POST'>";
        $html .= "<input type='hidden' name='ja_action' value='save_settings'>";
        $html .= "<input type='hidden' name='csrf' value='" . htmlspecialchars($csrf) . "'>";

        // Site identity
        $html .= "<div class='ja-card'><h3>Site identity</h3>";
        $html .= "<label class='ja-label'>Site name</label>";
        $html .= "<input type='text' name='site_name' class='ja-input' value='" . htmlspecialchars(Options::get('site_name', 'JA')) . "'>";
        $html .= "<label class='ja-label'>Slogan</label>";
        $html .= "<input type='text' name='site_slogan' class='ja-input' value='" . htmlspecialchars(Options::get('site_slogan', '')) . "'>";
        $html .= "</div>";

        // Branding
        $html .= "<div class='ja-card'><h3>Branding</h3>";
        $html .= "<label class='ja-label'>Logo</label>";
        $html .= "<select name='site_logo' class='ja-select'><option value=''>None</option>";
        foreach ($media as $m) {
            $sel   = Options::get('site_logo', '') === $m['filename'] ? ' selected' : '';
            $html .= "<option value='" . htmlspecialchars($m['filename']) . "'{$sel}>" . htmlspecialchars($m['original_name']) . "</option>";
        }
        $html .= "</select>";
        $html .= "<label class='ja-label'>Favicon</label>";
        $html .= "<select name='site_favicon' class='ja-select'><option value=''>None</option>";
        foreach ($media as $m) {
            $sel   = Options::get('site_favicon', '') === $m['filename'] ? ' selected' : '';
            $html .= "<option value='" . htmlspecialchars($m['filename']) . "'{$sel}>" . htmlspecialchars($m['original_name']) . "</option>";
        }
        $html .= "</select></div>";

        // Frontend
        $html .= "<div class='ja-card'><h3>Frontend</h3>";
        $html .= "<label class='ja-label'>Homepage plugin</label>";
        $html .= "<select name='frontend_plugin' class='ja-select'>";
        $html .= "<option value=''" . ($current_frontend === '' ? ' selected' : '') . ">None</option>";
        foreach ($frontend_opts as $id => $label) {
            $sel   = $current_frontend === $id ? ' selected' : '';
            $html .= "<option value='" . htmlspecialchars($id) . "'{$sel}>" . htmlspecialchars($id) . "</option>";
        }
        $html .= "</select>";
        $html .= "<p style='font-size:12px;color:#888;margin:-10px 0 16px;'>The plugin that drives your public-facing homepage.</p>";
        $html .= "</div>";

        // Admin access
        $raw_emails = Options::get('admin_emails', '');
        $emails     = json_decode($raw_emails, true);
        $display    = is_array($emails) ? implode("\n", $emails) : '';
        $html .= "<div class='ja-card'><h3>Admin access</h3>";
        $html .= "<label class='ja-label'>Authorised admin emails <span style='font-weight:400;color:#888;'>(one per line)</span></label>";
        $html .= "<textarea name='admin_emails_raw' class='ja-textarea' style='min-height:100px;font-family:monospace;font-size:13px;'>" . htmlspecialchars($display) . "</textarea>";
        $html .= "<p style='font-size:12px;color:#888;margin:-10px 0 16px;'>Only these addresses can request a magic login link.</p>";
        $html .= "</div>";

        // Localisation
        $html .= "<div class='ja-card'><h3>Localisation</h3>";
        $html .= "<label class='ja-label'>Language (e.g. en, es)</label>";
        $html .= "<input type='text' name='site_lang' class='ja-input' value='" . htmlspecialchars(Options::get('site_lang', 'en')) . "'>";
        $html .= "<label class='ja-label'>Timezone</label>";
        $html .= "<input type='text' name='timezone' class='ja-input' value='" . htmlspecialchars(Options::get('timezone', 'UTC')) . "'>";
        $html .= "</div>";

        $html .= "<button type='submit' class='ja-btn ja-btn-primary'>Save settings</button>";
        $html .= "</form>";
        return $html;
    }

    public static function handleSave($db, $post) {
        if (isset($post['admin_emails_raw'])) {
            $lines  = explode("\n", $post['admin_emails_raw']);
            $emails = array_values(array_filter(array_map(fn($e) => strtolower(trim($e)), $lines)));
            Options::set('admin_emails', json_encode($emails));
        }
        foreach (self::$allowed_keys as $key) {
            if (array_key_exists($key, $post)) Options::set($key, $post[$key]);
        }
        return true;
    }
}
