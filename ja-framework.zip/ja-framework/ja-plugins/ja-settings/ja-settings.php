<?php
namespace JA\Plugins;
use JA\Core\Options;
use JA\Core\Media;
use JA\Core\Plugins as CorePlugins;

class Settings {
    private static $allowed_keys = [
        'site_name', 'site_slogan', 'site_logo', 'site_favicon',
        'site_lang', 'timezone', 'frontend_plugin',
    ];

    /** Fields added by plugins: key => [label, type, help, default] */
    private static array $extra_fields = [];

    /** Option keys a plugin may never claim — they control core behaviour. */
    private static array $reserved_keys = [
        'active_plugins', 'active_theme', 'admin_emails', 'admin_email', 'menus', 'frontend_plugin',
    ];

    public static function init() {}

    /**
     * Let a plugin add a field to the Settings screen. Call from the plugin's init().
     * The value is stored with Options::set() under $key and read with Options::get().
     *
     *   Settings::registerField('events_per_page', 'Events per page', 'text', 'Default 10', '10');
     *
     * $type is 'text', 'textarea' or 'checkbox' (checkbox stores '1' or '0').
     * Keys must be lowercase letters, numbers and underscores — prefix with your plugin name.
     */
    public static function registerField(string $key, string $label, string $type = 'text', string $help = '', string $default = ''): bool {
        if (!preg_match('/^[a-z][a-z0-9_]*$/', $key)) return false;
        if (in_array($key, self::$reserved_keys, true) || in_array($key, self::$allowed_keys, true)) return false;
        if (strpos($key, 'menu_slot_') === 0) return false;
        if (!in_array($type, ['text', 'textarea', 'checkbox'], true)) $type = 'text';

        self::$extra_fields[$key] = ['label' => $label, 'type' => $type, 'help' => $help, 'default' => $default];
        return true;
    }

    public static function renderAdmin($db, $csrf = '') {
        $media = Media::getAll($db);

        // Homepage-capable plugins: enabled user plugins that define bootFrontend()
        $frontend_opts = [];
        foreach (CorePlugins::activeList() as $id) {
            if (CorePlugins::isRequired($id) || !CorePlugins::isValidId($id)) continue;
            $class = CorePlugins::fqcn($id);
            if (class_exists($class, false) && method_exists($class, 'bootFrontend')) {
                $frontend_opts[$id] = $id;
            }
        }
        $current_frontend = Options::get('frontend_plugin', '');

        $html  = "<h1 class='ja-page-header'>Settings</h1>";
        $html .= "<form method='POST'>";
        $html .= "<input type='hidden' name='ja_action' value='save_settings'>";
        $html .= "<input type='hidden' name='csrf' value='" . htmlspecialchars($csrf) . "'>";

        // Site identity
        $html .= "<div class='ja-card'><h3>Site identity</h3>";
        $html .= "<label class='ja-label'>Site name</label>";
        $html .= "<input type='text' name='site_name' class='ja-input' value='" . htmlspecialchars(Options::get('site_name', 'JA')) . "'>";
        $html .= "<label class='ja-label'>Slogan</label>";
        $html .= "<input type='text' name='site_slogan' class='ja-input' value='" . htmlspecialchars(Options::get('site_slogan', '')) . "'>";
        $html .= "</div>";

        // Branding
        $html .= "<div class='ja-card'><h3>Branding</h3>";
        $html .= "<label class='ja-label'>Logo</label>";
        $html .= "<select name='site_logo' class='ja-select'><option value=''>None</option>";
        foreach ($media as $m) {
            $sel   = Options::get('site_logo', '') === $m['filename'] ? ' selected' : '';
            $html .= "<option value='" . htmlspecialchars($m['filename']) . "'{$sel}>" . htmlspecialchars($m['original_name']) . "</option>";
        }
        $html .= "</select>";
        $html .= "<label class='ja-label'>Favicon</label>";
        $html .= "<select name='site_favicon' class='ja-select'><option value=''>None</option>";
        foreach ($media as $m) {
            $sel   = Options::get('site_favicon', '') === $m['filename'] ? ' selected' : '';
            $html .= "<option value='" . htmlspecialchars($m['filename']) . "'{$sel}>" . htmlspecialchars($m['original_name']) . "</option>";
        }
        $html .= "</select></div>";

        // Frontend
        $html .= "<div class='ja-card'><h3>Frontend</h3>";
        $html .= "<label class='ja-label'>Homepage plugin</label>";
        $html .= "<select name='frontend_plugin' class='ja-select'>";
        $html .= "<option value=''" . ($current_frontend === '' ? ' selected' : '') . ">None</option>";
        foreach ($frontend_opts as $id => $label) {
            $sel   = $current_frontend === $id ? ' selected' : '';
            $html .= "<option value='" . htmlspecialchars($id) . "'{$sel}>" . htmlspecialchars($id) . "</option>";
        }
        $html .= "</select>";
        $html .= "<p style='font-size:12px;color:#888;margin:-10px 0 16px;'>The plugin that drives your public-facing homepage.</p>";
        $html .= "</div>";

        // Admin access
        $raw_emails = Options::get('admin_emails', '');
        $emails     = json_decode($raw_emails, true);
        $display    = is_array($emails) ? implode("\n", $emails) : '';
        $html .= "<div class='ja-card'><h3>Admin access</h3>";
        $html .= "<label class='ja-label'>Authorised admin emails <span style='font-weight:400;color:#888;'>(one per line)</span></label>";
        $html .= "<textarea name='admin_emails_raw' class='ja-textarea' style='min-height:100px;font-family:monospace;font-size:13px;'>" . htmlspecialchars($display) . "</textarea>";
        $html .= "<p style='font-size:12px;color:#888;margin:-10px 0 16px;'>Only these addresses can request a magic login link.</p>";
        $html .= "</div>";

        // Localisation
        $html .= "<div class='ja-card'><h3>Localisation</h3>";
        $html .= "<label class='ja-label'>Language (e.g. en, es)</label>";
        $html .= "<input type='text' name='site_lang' class='ja-input' value='" . htmlspecialchars(Options::get('site_lang', 'en')) . "'>";
        $html .= "<label class='ja-label'>Timezone</label>";
        $html .= "<input type='text' name='timezone' class='ja-input' value='" . htmlspecialchars(Options::get('timezone', 'UTC')) . "'>";
        $html .= "</div>";

        // Fields registered by plugins
        if (!empty(self::$extra_fields)) {
            $html .= "<div class='ja-card'><h3>Plugin settings</h3>";
            foreach (self::$extra_fields as $key => $f) {
                $name  = htmlspecialchars($key, ENT_QUOTES);
                $value = (string) Options::get($key, $f['default']);
                $label = htmlspecialchars($f['label'], ENT_QUOTES);
                if ($f['type'] === 'checkbox') {
                    $html .= "<input type='hidden' name='{$name}' value='0'>";
                    $html .= "<label class='ja-label'><input type='checkbox' name='{$name}' value='1'" . ($value === '1' ? ' checked' : '') . "> {$label}</label>";
                } elseif ($f['type'] === 'textarea') {
                    $html .= "<label class='ja-label'>{$label}</label>";
                    $html .= "<textarea name='{$name}' class='ja-textarea'>" . htmlspecialchars($value) . "</textarea>";
                } else {
                    $html .= "<label class='ja-label'>{$label}</label>";
                    $html .= "<input type='text' name='{$name}' class='ja-input' value='" . htmlspecialchars($value, ENT_QUOTES) . "'>";
                }
                if ($f['help'] !== '') {
                    $html .= "<p style='font-size:12px;color:#888;margin:-10px 0 16px;'>" . htmlspecialchars($f['help']) . "</p>";
                }
            }
            $html .= "</div>";
        }

        $html .= "<button type='submit' class='ja-btn ja-btn-primary'>Save settings</button>";
        $html .= "</form>";
        return $html;
    }

    public static function handleSave($db, $post) {
        if (isset($post['admin_emails_raw'])) {
            $lines  = explode("\n", $post['admin_emails_raw']);
            $emails = array_values(array_filter(array_map(fn($e) => strtolower(trim($e)), $lines)));
            Options::set('admin_emails', json_encode($emails));
        }
        $notice = null;

        foreach (self::$allowed_keys as $key) {
            if (!array_key_exists($key, $post)) continue;
            $value = is_string($post[$key]) ? trim($post[$key]) : '';

            if ($key === 'timezone' && !in_array($value, \DateTimeZone::listIdentifiers(), true)) {
                $notice = '❌ Other settings were saved, but that timezone isn’t valid (use a name like America/Chicago).';
                continue;
            }
            if ($key === 'frontend_plugin' && $value !== '' && !(CorePlugins::isValidId($value) && CorePlugins::isActive($value))) {
                $notice = '❌ Other settings were saved, but the chosen homepage plugin isn’t enabled.';
                continue;
            }
            Options::set($key, $value);
        }

        foreach (array_keys(self::$extra_fields) as $key) {
            if (array_key_exists($key, $post)) {
                Options::set($key, is_string($post[$key]) ? $post[$key] : '');
            }
        }

        if ($notice !== null) return $notice;
        return true;
    }
}
