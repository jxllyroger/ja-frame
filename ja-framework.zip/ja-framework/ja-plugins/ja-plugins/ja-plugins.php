<?php
namespace JA\Plugins;
use JA\Core\Plugins as CorePlugins;
use JA\Core\Package;
use JA\Core\AdminUI;

class Plugins {
    public static function init() {}

    public static function renderAdmin($db, $csrf = '') {
        $folders     = array_filter(glob(JA_ROOT . '/ja-plugins/*') ?: [], 'is_dir');
        sort($folders);
        $active_list = CorePlugins::pruneMissing();
        $tab         = ($_GET['tab'] ?? 'installed') === 'core' ? 'core' : 'installed';
        $h           = fn($s) => htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');

        $html  = "<h1 class='ja-page-header'>Plugins</h1>";

        $html .= "<div class='ja-tabs'>";
        $html .= "<a href='?view=plugins&tab=installed' class='ja-tab " . ($tab === 'installed' ? 'active' : '') . "'>Installed</a>";
        $html .= "<a href='?view=plugins&tab=core'      class='ja-tab " . ($tab === 'core'      ? 'active' : '') . "'>Core system</a>";
        $html .= "</div>";

        if ($tab === 'installed') {
            $html .= "<div class='ja-card'>";
            $html .= "<h3>Install plugin (.zip)</h3>";
            $html .= "<form method='POST' enctype='multipart/form-data'>";
            $html .= "<input type='hidden' name='csrf' value='" . $h($csrf) . "'>";
            $html .= "<div class='ja-upload-area'>";
            $html .= "<input type='file' name='plugin_zip' id='plugin_zip_input' class='ja-file-input' accept='.zip' required onchange=\"document.getElementById('plugin_zip_chosen').textContent = this.files[0]?.name || 'No file chosen'\">";
            $html .= "<label for='plugin_zip_input' class='ja-file-label'>Choose file</label>";
            $html .= "<span id='plugin_zip_chosen' class='ja-file-chosen'>No file chosen</span>";
            $html .= "<button type='submit' class='ja-btn ja-btn-primary'>Install</button>";
            $html .= "</div>";
            $html .= "<p style='font-size:12px;color:#888;margin:8px 0 0;'>The zip must contain one folder, e.g. <code>ja-events/ja-events.php</code>. Only install plugins you trust — they run with full access to the site.</p>";
            $html .= "</form></div>";
        }

        $rows = '';
        foreach ($folders as $f) {
            $id      = basename($f);
            $is_core = CorePlugins::isRequired($id);

            if (($tab === 'core' && !$is_core) || ($tab === 'installed' && $is_core)) continue;

            if (!CorePlugins::isValidId($id)) {
                $rows .= "<tr><td><strong>" . $h($id) . "</strong><div style='font-size:12px;color:#c62828;'>Folder name must use lowercase letters, numbers and hyphens.</div></td><td></td></tr>";
                continue;
            }

            $info       = CorePlugins::manifest($id);
            $is_enabled = in_array($id, $active_list, true);

            $title = "<strong>" . $h($info['name']) . "</strong>";
            if ($info['version'] !== '') $title .= " <span style='font-size:12px;color:#888;margin-left:6px;'>v" . $h($info['version']) . "</span>";
            if ($is_enabled && !$is_core) $title .= " <span style='font-size:12px;color:#2e7d32;margin-left:6px;'>enabled</span>";
            $sub = [];
            if ($info['name'] !== $id)         $sub[] = $h($id);
            if ($info['author'] !== '')        $sub[] = 'by ' . $h($info['author']);
            if ($info['description'] !== '')   $sub[] = $h($info['description']);
            if ($sub) $title .= "<div style='font-size:12px;color:#888;margin-top:2px;'>" . implode(' · ', $sub) . "</div>";

            $rows .= "<tr><td>{$title}</td><td class='ja-table-actions'>";

            if ($is_core) {
                $rows .= "<span class='action-locked'>Active &amp; locked</span>";
            } else {
                if ($is_enabled) {
                    $rows .= AdminUI::postButton('Disable', 'plugin_toggle', ['id' => $id], $csrf, 'action-disable');
                } else {
                    $rows .= AdminUI::postButton('Enable', 'plugin_toggle', ['id' => $id], $csrf, 'action-enable');
                }
                $rows .= AdminUI::postButton('Uninstall', 'plugin_uninstall', ['id' => $id], $csrf, 'action-delete', "Uninstall and delete plugin {$id}?");
            }
            $rows .= "</td></tr>";
        }

        $html .= "<div class='ja-card'>";
        $html .= "<table class='ja-table'>";
        $html .= "<thead><tr><th>Plugin</th><th></th></tr></thead><tbody>";
        $html .= $rows !== '' ? $rows : "<tr><td colspan='2' style='color:#aaa;'>No plugins here yet.</td></tr>";
        $html .= "</tbody></table></div>";
        return $html;
    }

    /**
     * @return array{ok:bool, message:string}
     */
    public static function handleInstall($zip_file) {
        $result = Package::install(
            $zip_file,
            JA_ROOT . '/ja-plugins',
            fn($id) => $id . '.php',
            CorePlugins::required()
        );

        if (!$result['ok']) {
            return ['ok' => false, 'message' => '❌ Plugin install failed: ' . htmlspecialchars($result['message'], ENT_QUOTES, 'UTF-8')];
        }
        return ['ok' => true, 'message' => '✅ Plugin installed! Enable it from the Installed tab.'];
    }
}
