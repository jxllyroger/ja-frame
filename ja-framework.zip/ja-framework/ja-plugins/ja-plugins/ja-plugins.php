<?php
namespace JA\Plugins;
use JA\Core\Plugins as CorePlugins;
use JA\Core\Options;

class Plugins {
    public static function init() {}

    public static function renderAdmin($db, $csrf = '') {
        $folders     = array_filter(glob(JA_ROOT . '/ja-plugins/*'), 'is_dir');
        $active_list = json_decode(Options::get('active_plugins', '[]'), true) ?: [];
        $tab         = $_GET['tab'] ?? 'installed';
        $t           = urlencode($csrf);

        $html  = "<h1 class='ja-page-header'>Plugins</h1>";

        $html .= "<div class='ja-tabs'>";
        $html .= "<a href='?view=plugins&tab=installed' class='ja-tab " . ($tab === 'installed' ? 'active' : '') . "'>Installed</a>";
        $html .= "<a href='?view=plugins&tab=core'      class='ja-tab " . ($tab === 'core'      ? 'active' : '') . "'>Core system</a>";
        $html .= "</div>";

        if ($tab === 'installed') {
            $html .= "<div class='ja-card'>";
            $html .= "<h3>Install plugin (.zip)</h3>";
            $html .= "<form method='POST' enctype='multipart/form-data'>";
            $html .= "<input type='hidden' name='csrf' value='" . htmlspecialchars($csrf) . "'>";
            $html .= "<div class='ja-upload-area'>";
            $html .= "<input type='file' name='plugin_zip' id='plugin_zip_input' class='ja-file-input' accept='.zip' required onchange=\"document.getElementById('plugin_zip_chosen').textContent = this.files[0]?.name || 'No file chosen'\">";
            $html .= "<label for='plugin_zip_input' class='ja-file-label'>Choose file</label>";
            $html .= "<span id='plugin_zip_chosen' class='ja-file-chosen'>No file chosen</span>";
            $html .= "<button type='submit' class='ja-btn ja-btn-primary'>Install</button>";
            $html .= "</div></form></div>";
        }

        $html .= "<div class='ja-card'>";
        $html .= "<table class='ja-table'>";
        $html .= "<thead><tr><th>Plugin</th><th></th></tr></thead><tbody>";

        foreach ($folders as $f) {
            $id      = basename($f);
            $is_core = CorePlugins::isRequired($id);

            if (($tab === 'core' && !$is_core) || ($tab === 'installed' && $is_core)) continue;

            $is_enabled = in_array($id, $active_list);
            $html .= "<tr><td><strong>" . htmlspecialchars($id) . "</strong></td>";
            $html .= "<td class='ja-table-actions'>";

            if ($is_core) {
                $html .= "<span class='action-locked'>Active &amp; locked</span>";
            } else {
                if ($is_enabled) {
                    $html .= "<a href='?view=plugins&toggle=" . urlencode($id) . "&_token={$t}' class='action-disable'>Disable</a>";
                } else {
                    $html .= "<a href='?view=plugins&toggle=" . urlencode($id) . "&_token={$t}' class='action-enable'>Enable</a>";
                }
                $html .= "<a href='?view=plugins&uninstall=" . urlencode($id) . "&_token={$t}' class='action-delete' onclick='return confirm(\"Delete plugin " . htmlspecialchars($id, ENT_QUOTES) . "?\")'>Uninstall</a>";
            }
            $html .= "</td></tr>";
        }

        $html .= "</tbody></table></div>";
        return $html;
    }

    public static function handleInstall($zip_file) {
        if ($zip_file['error'] !== UPLOAD_ERR_OK) return false;
        if (strtolower(pathinfo($zip_file['name'], PATHINFO_EXTENSION)) !== 'zip') return false;

        $zip = new \ZipArchive();
        if ($zip->open($zip_file['tmp_name']) !== true) return false;

        $target_base = realpath(JA_ROOT . '/ja-plugins');
        $plugin_name = null;

        for ($i = 0; $i < $zip->numFiles; $i++) {
            $entry = $zip->getNameIndex($i);
            $parts = explode('/', trim($entry, '/'));

            if ($plugin_name === null && !empty($parts[0])) {
                $plugin_name = $parts[0];
            }

            // Block .. in any path component
            if (strpos($entry, '..') !== false) {
                $zip->close();
                return false;
            }

            // Block anything that would land outside ja-plugins/
            $normalized = $target_base . '/' . ltrim($entry, '/');
            if (strpos($normalized, $target_base) !== 0) {
                $zip->close();
                return false;
            }
        }

        if (!$plugin_name) { $zip->close(); return false; }

        // Prevent overwriting core plugins
        $core = ['ja-media', 'ja-settings', 'ja-themes', 'ja-plugins'];
        if (in_array(basename($plugin_name), $core)) {
            $zip->close();
            return false;
        }

        $zip->extractTo(JA_ROOT . '/ja-plugins/');
        $zip->close();
        return is_dir(JA_ROOT . '/ja-plugins/' . basename($plugin_name));
    }
}
