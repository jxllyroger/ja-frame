<?php
namespace JA\Plugins;

use JA\Core\Hooks;
use JA\Core\Assets;
use JA\Core\AdminMenu;
use JA\Core\AdminUI;
use JA\Core\Options;
use JA\Core\Database;

/**
 * JA Security Suite
 *
 *  - IP blocking: single addresses and CIDR ranges, on the public site and the login page.
 *    Admins already signed in are never locked out of the admin panel.
 *  - Security headers, sent before any output.
 *  - Login throttling: limits magic-link requests per IP and per email address.
 *  - Audit log: sign-ins, failed sign-ins, settings changes, page saves, uploads, and
 *    plugin/theme/media/page actions — with who, from where, and when.
 *
 * Settings (blocked IPs, headers, throttling, retention) appear on the Settings screen.
 * Uses these core hooks: options_update, page_save, media_upload, admin_action,
 * login_success, login_failed, login_link_requested, and the login_allowed filter.
 */
class SecuritySuite {

    private static array   $changed_options     = [];
    private static bool    $shutdown_registered = false;
    private static ?string $ip                  = null;

    // ---------------------------------------------------------------
    // Boot
    // ---------------------------------------------------------------

    public static function init() {
        // Settings fields only matter in the admin, where the Settings screen is loaded
        if (class_exists('JA\\Plugins\\Settings', false)) {
            Settings::registerField('sec_ip_blacklist', 'Blocked IP addresses', 'textarea',
                'One per line, or comma-separated. Single addresses or ranges such as 203.0.113.0/24 or 2001:db8::/32. Blocked visitors cannot view the site or the login page. Admins who are already signed in keep access to the admin panel.', '');
            Settings::registerField('sec_client_ip_header', 'Real-IP header (only behind a proxy or CDN)', 'text',
                'Leave empty unless your site is behind a proxy such as Cloudflare. Then enter the header it sets, e.g. HTTP_CF_CONNECTING_IP. Only set this if you trust that proxy, because visitors can fake the header otherwise.', '');
            Settings::registerField('sec_enable_headers', 'Send security headers (clickjacking and content-type protection)', 'checkbox', '', '1');
            Settings::registerField('sec_hsts', 'Force HTTPS in browsers (HSTS). Only turn on if the whole site works over HTTPS.', 'checkbox', '', '0');
            Settings::registerField('sec_login_throttle', 'Limit login link requests (5 per IP and 3 per address, every 15 minutes)', 'checkbox', '', '1');
            Settings::registerField('sec_log_retention_days', 'Keep security log entries for (days)', 'text', '', '90');
        }

        AdminMenu::add('Security Suite', 'security-suite', '🛡️');
        Assets::style('security-admin', Assets::pluginUrl('ja-security-suite', 'assets/security-admin.css'), 'admin');

        // These run before any page output, so headers can still be sent and a blocked visitor never sees the page
        self::sendHeaders();
        self::enforceBlacklist();

        // Audit log
        Hooks::action('options_update',        [self::class, 'onOption']);
        Hooks::action('page_save',             [self::class, 'onPageSave']);
        Hooks::action('media_upload',          [self::class, 'onMediaUpload']);
        Hooks::action('admin_action',          [self::class, 'onAdminAction']);
        Hooks::action('login_success',         [self::class, 'onLoginSuccess']);
        Hooks::action('login_failed',          [self::class, 'onLoginFailed']);
        Hooks::action('login_link_requested',  [self::class, 'onLoginLink']);

        // Login throttling
        Hooks::filter('login_allowed', [self::class, 'loginAllowed']);
    }

    public static function onActivate($db) {
        $db->exec("CREATE TABLE IF NOT EXISTS ja_security_logs (
            id          INT AUTO_INCREMENT PRIMARY KEY,
            created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            ip_address  VARCHAR(45)  NOT NULL,
            event_type  VARCHAR(50)  NOT NULL,
            actor       VARCHAR(190) NULL,
            description VARCHAR(500) NOT NULL DEFAULT '',
            INDEX idx_created (created_at),
            INDEX idx_event (event_type, created_at),
            INDEX idx_ip (ip_address, event_type, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }

    public static function onDeactivate($db) {}

    public static function onUninstall($db) {
        $db->exec("DROP TABLE IF EXISTS ja_security_logs");
        $stmt = $db->prepare("DELETE FROM ja_options WHERE option_name LIKE ?");
        $stmt->execute(['sec\_%']);
        Options::forgetCache();
    }

    // ---------------------------------------------------------------
    // IP blocking
    // ---------------------------------------------------------------

    private static function enforceBlacklist(): void {
        if (PHP_SAPI === 'cli' || self::isAdminScript()) return;

        $ip = self::clientIp();
        if ($ip === '' || !self::isBlocked($ip)) return;

        self::log('IP blocked', 'Blocked a request to ' . self::requestPath(), null, true);

        http_response_code(403);
        header('Cache-Control: no-store');
        header('Content-Type: text/html; charset=utf-8');
        echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Access denied</title></head>'
           . '<body style="font-family:system-ui,sans-serif;text-align:center;padding:80px 20px;color:#333;">'
           . '<h1 style="font-size:32px;">Access denied</h1><p>Your address has been blocked by the site administrator.</p></body></html>';
        exit;
    }

    /** True if $ip matches any entry in the blocklist. */
    public static function isBlocked(string $ip): bool {
        $raw = trim((string) Options::get('sec_ip_blacklist', ''));
        if ($raw === '') return false;

        foreach (preg_split('/[\s,]+/', $raw, -1, PREG_SPLIT_NO_EMPTY) as $entry) {
            if (self::ipMatches($ip, $entry)) return true;
        }
        return false;
    }

    /** $entry is a single address or a CIDR range. IPv4 and IPv6 are compared as raw bytes. */
    private static function ipMatches(string $ip, string $entry): bool {
        $ip_bin = @inet_pton($ip);
        if ($ip_bin === false) return false;

        if (strpos($entry, '/') === false) {
            $entry_bin = @inet_pton($entry);
            return $entry_bin !== false && $entry_bin === $ip_bin;
        }

        [$net, $bits] = explode('/', $entry, 2);
        $net_bin = @inet_pton($net);
        if ($net_bin === false || strlen($net_bin) !== strlen($ip_bin) || !ctype_digit($bits)) return false;

        $bits = (int) $bits;
        if ($bits > strlen($ip_bin) * 8) return false;

        $bytes = intdiv($bits, 8);
        $rest  = $bits % 8;

        if ($bytes > 0 && substr($ip_bin, 0, $bytes) !== substr($net_bin, 0, $bytes)) return false;
        if ($rest === 0) return true;

        $mask = (0xFF << (8 - $rest)) & 0xFF;
        return (ord($ip_bin[$bytes]) & $mask) === (ord($net_bin[$bytes]) & $mask);
    }

    private static function clientIp(): string {
        if (self::$ip !== null) return self::$ip;

        $ip     = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
        $header = trim((string) Options::get('sec_client_ip_header', ''));

        if ($header !== '' && preg_match('/^HTTP_[A-Z0-9_]+$/', $header) && !empty($_SERVER[$header])) {
            $candidate = trim(explode(',', (string) $_SERVER[$header])[0]);
            if (filter_var($candidate, FILTER_VALIDATE_IP)) $ip = $candidate;
        }

        return self::$ip = (filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '');
    }

    private static function isAdminScript(): bool {
        return strpos(str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? ''), '/ja-admin/') !== false;
    }

    private static function requestPath(): string {
        $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
        return is_string($path) && $path !== '' ? $path : '/';
    }

    // ---------------------------------------------------------------
    // Security headers
    //
    // Deliberately no full Content-Security-Policy: themes and plugins use inline styles and scripts,
    // so a policy that allows them would add no real protection and a strict one would break pages.
    // frame-ancestors gives the useful part (clickjacking protection) without that risk.
    // ---------------------------------------------------------------

    private static function sendHeaders(): void {
        if (PHP_SAPI === 'cli' || headers_sent()) return;
        if (Options::get('sec_enable_headers', '1') !== '1') return;

        header('X-Frame-Options: SAMEORIGIN');
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
        header("Content-Security-Policy: frame-ancestors 'self'");

        $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? '') === '443');
        if ($https && Options::get('sec_hsts', '0') === '1') {
            header('Strict-Transport-Security: max-age=31536000');
        }
    }

    // ---------------------------------------------------------------
    // Login throttling (filter) and login events
    // ---------------------------------------------------------------

    public static function loginAllowed($allowed, $email = '') {
        if (!$allowed || Options::get('sec_login_throttle', '1') !== '1') return $allowed;

        $email = strtolower(trim((string) $email));
        try {
            $stmt = Database::getConnection()->prepare(
                "SELECT SUM(ip_address = ?) AS by_ip, SUM(actor = ?) AS by_email
                   FROM ja_security_logs
                  WHERE event_type = 'Login link requested'
                    AND created_at > (NOW() - INTERVAL 15 MINUTE)"
            );
            $stmt->execute([self::clientIp(), $email]);
            $row = $stmt->fetch();

            if ((int) ($row['by_ip'] ?? 0) >= 5 || (int) ($row['by_email'] ?? 0) >= 3) {
                self::log('Login throttled', 'Too many login link requests', $email, true);
                return false;
            }
        } catch (\Throwable $e) {
            // A logging problem must never lock people out of signing in
        }
        return $allowed;
    }

    public static function onLoginLink($email = '', $issued = false): void {
        self::log('Login link requested', $issued ? 'Link sent to an authorised address' : 'Address is not authorised', strtolower(trim((string) $email)));
    }

    public static function onLoginSuccess($email = ''): void {
        self::log('Login', 'Signed in with a login link', (string) $email);
    }

    public static function onLoginFailed($reason = ''): void {
        self::log('Login failed', (string) $reason, null);
    }

    // ---------------------------------------------------------------
    // Audit events
    // ---------------------------------------------------------------

    /** Settings saves touch many keys at once, so collect them and write one entry at the end of the request. */
    public static function onOption($name = '', $value = null): void {
        if ($name === 'active_plugins') return;   // logged as a plugin action instead
        self::$changed_options[(string) $name] = true;

        if (!self::$shutdown_registered) {
            self::$shutdown_registered = true;
            register_shutdown_function([self::class, 'flushOptionLog']);
        }
    }

    public static function flushOptionLog(): void {
        if (!self::$changed_options) return;
        $keys  = array_keys(self::$changed_options);
        $shown = implode(', ', array_slice($keys, 0, 8)) . (count($keys) > 8 ? ' and ' . (count($keys) - 8) . ' more' : '');
        self::log('Settings changed', 'Updated: ' . $shown, self::actor());
    }

    public static function onPageSave($page = null): void {
        $title = is_array($page) ? (string) ($page['title'] ?? '') : '';
        self::log('Page saved', $title !== '' ? $title : 'A page was saved', self::actor());
    }

    public static function onMediaUpload($upload_id = null, $name = ''): void {
        self::log('File uploaded', (string) $name, self::actor());
    }

    public static function onAdminAction($action = '', $id = '', $result = ''): void {
        $labels = [
            'plugin_toggle'    => 'Plugin enabled or disabled',
            'plugin_uninstall' => 'Plugin uninstalled',
            'theme_activate'   => 'Theme activated',
            'theme_delete'     => 'Theme deleted',
            'media_delete'     => 'File deleted',
            'page_delete'      => 'Page deleted',
        ];
        if (!isset($labels[$action])) return;

        $outcome = trim(strip_tags((string) $result));
        $outcome = trim((string) preg_replace('/^[^\p{L}\p{N}]+/u', '', $outcome));   // drop the leading ✅ / ❌
        self::log($labels[$action], (string) $id . ($outcome !== '' ? ' — ' . $outcome : ''), self::actor());
    }

    // ---------------------------------------------------------------
    // Logging
    // ---------------------------------------------------------------

    public static function log(string $event, string $description = '', ?string $actor = null, bool $dedupe = false): void {
        try {
            $db = Database::getConnection();
            $ip = self::clientIp();

            if ($dedupe) {
                // Don't let one noisy visitor fill the log with identical entries
                $chk = $db->prepare("SELECT 1 FROM ja_security_logs WHERE ip_address = ? AND event_type = ? AND created_at > (NOW() - INTERVAL 10 MINUTE) LIMIT 1");
                $chk->execute([$ip !== '' ? $ip : 'unknown', self::cut($event, 50)]);
                if ($chk->fetchColumn()) return;
            }

            $stmt = $db->prepare("INSERT INTO ja_security_logs (ip_address, event_type, actor, description) VALUES (?, ?, ?, ?)");
            $stmt->execute([
                $ip !== '' ? $ip : 'unknown',
                self::cut($event, 50),
                $actor !== null && $actor !== '' ? self::cut($actor, 190) : null,
                self::cut($description, 500),
            ]);

            if (random_int(1, 200) === 1) self::prune($db);
        } catch (\Throwable $e) {
            // Logging must never break the site (for example if the table does not exist yet)
        }
    }

    private static function prune($db): void {
        $days = max(1, min(3650, (int) Options::get('sec_log_retention_days', '90')));
        $db->exec("DELETE FROM ja_security_logs WHERE created_at < (NOW() - INTERVAL {$days} DAY)");
        // Hard cap, so a flood can never grow the table without limit
        $db->exec("DELETE FROM ja_security_logs WHERE id <= (SELECT id FROM (SELECT id FROM ja_security_logs ORDER BY id DESC LIMIT 1 OFFSET 20000) AS old_rows)");
    }

    private static function actor(): ?string {
        if (session_status() === PHP_SESSION_ACTIVE && !empty($_SESSION['ja_admin'])) {
            return (string) $_SESSION['ja_admin'];
        }
        return null;
    }

    private static function cut(string $text, int $max): string {
        return function_exists('mb_substr') ? mb_substr($text, 0, $max) : substr($text, 0, $max);
    }

    // ---------------------------------------------------------------
    // Admin screen
    // ---------------------------------------------------------------

    public static function renderAdmin($db, $csrf = '') {
        $h    = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
        $type = (isset($_GET['type']) && is_string($_GET['type'])) ? $_GET['type'] : '';

        try {
            self::prune($db);
            $counts = $db->query("SELECT event_type, COUNT(*) AS c FROM ja_security_logs WHERE created_at > (NOW() - INTERVAL 24 HOUR) GROUP BY event_type ORDER BY c DESC")->fetchAll();

            if ($type !== '') {
                $stmt = $db->prepare("SELECT * FROM ja_security_logs WHERE event_type = ? ORDER BY id DESC LIMIT 200");
                $stmt->execute([$type]);
                $logs = $stmt->fetchAll();
            } else {
                $logs = $db->query("SELECT * FROM ja_security_logs ORDER BY id DESC LIMIT 200")->fetchAll();
            }
        } catch (\Throwable $e) {
            return "<div class='ja-notice error'>The security log table isn't available. Disable and re-enable the plugin to recreate it.</div>";
        }

        $my_ip = self::clientIp();

        $html  = "<div class='security-suite-container'>";
        $html .= "<div class='security-suite-header'><h1 class='security-suite-title'>🛡️ Security Suite</h1>";
        if ($logs || $type !== '') {
            $html .= AdminUI::postButton('Clear all logs', 'sec_clear_logs', [], $csrf, 'ja-btn ja-btn-danger ja-btn-sm', 'Delete every security log entry? This cannot be undone.');
        }
        $html .= "</div>";

        $html .= "<p class='security-meta'>Your address: <strong>" . $h($my_ip !== '' ? $my_ip : 'unknown') . "</strong>. "
               . "Blocked IPs, headers, login limits and log retention are set under <a href='?view=settings'>Settings</a> in the Plugin settings section.</p>";

        if ($my_ip !== '' && self::isBlocked($my_ip)) {
            $html .= "<div class='security-notice'>Your current address is on the blocked list, so you can't view the public site from here. You can still use the admin panel.</div>";
        }

        // Last 24 hours, as filters
        $html .= "<p class='security-meta' style='margin-bottom:8px;'>Last 24 hours:</p><div style='display:flex;flex-wrap:wrap;gap:8px;margin-bottom:20px;'>";
        $html .= "<a href='?view=security-suite' class='security-badge " . ($type === '' ? 'security-badge-danger' : 'security-badge-info') . "'>All events</a>";
        foreach ($counts as $row) {
            $active = ($type === $row['event_type']);
            $html  .= "<a href='?view=security-suite&type=" . urlencode($row['event_type']) . "' class='security-badge " . ($active ? 'security-badge-danger' : 'security-badge-info') . "'>"
                    . $h($row['event_type']) . " · " . (int) $row['c'] . "</a>";
        }
        $html .= "</div>";

        if (!$logs) {
            $html .= "<div class='security-empty-state'><p style='font-size:18px;margin:0;'>No events recorded yet.</p></div></div>";
            return $html;
        }

        $html .= "<table class='security-log-table'><thead><tr><th>Time</th><th>Event</th><th>Who</th><th>IP address</th><th>Details</th></tr></thead><tbody>";
        foreach ($logs as $log) {
            $event = $log['event_type'];
            $badge = in_array($event, ['IP blocked'], true) ? 'security-badge-danger'
                   : (in_array($event, ['Login failed', 'Login throttled'], true) ? 'security-badge-warn'
                   : ($event === 'Login' ? 'security-badge-ok' : 'security-badge-info'));
            $row_class = $badge === 'security-badge-danger' ? " class='security-row-threat'" : '';

            $html .= "<tr{$row_class}>";
            $html .= "<td style='color:#718096;white-space:nowrap;'>" . $h($log['created_at']) . "</td>";
            $html .= "<td><span class='security-badge {$badge}'>" . $h($event) . "</span></td>";
            $html .= "<td>" . $h($log['actor'] ?? '') . "</td>";
            $html .= "<td style='font-weight:600;'>" . $h($log['ip_address']) . "</td>";
            $html .= "<td>" . $h($log['description']) . "</td>";
            $html .= "</tr>";
        }
        $html .= "</tbody></table>";
        $html .= "<p style='color:#718096;font-size:12px;margin-top:15px;'>Showing the 200 most recent entries.</p></div>";

        return $html;
    }

    /** @return bool|string  A string is shown as the message. */
    public static function handleSave($db, $post) {
        if (($post['ja_action'] ?? '') === 'sec_clear_logs') {
            try {
                $db->exec("DELETE FROM ja_security_logs");
            } catch (\Throwable $e) {
                return '❌ Could not clear the log.';
            }
            self::log('Logs cleared', 'The security log was cleared', self::actor());
            return '✅ Security log cleared.';
        }
        return true;
    }
}
