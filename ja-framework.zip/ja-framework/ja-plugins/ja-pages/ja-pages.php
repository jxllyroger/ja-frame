<?php
namespace JA\Plugins;
use JA\Core\Hooks;
use JA\Core\Options;

class Pages {
    public static function init() {
        Hooks::add_menu_item('Pages', 'pages', '📝');
    }

    // ------------------------------------------------------------------
    // Frontend
    // ------------------------------------------------------------------
    public static function bootFrontend($db) {
        $uri  = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
        $slug = trim(str_replace(
            rtrim(str_replace(['/public', '/ja-admin'], '', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/'),
            '',
            $uri
        ), '/');

        if ($slug === '' || $slug === 'index.php') {
            // Home page
            $stmt = $db->prepare("SELECT * FROM ja_pages WHERE is_home = 1 AND status = 'published' LIMIT 1");
            $stmt->execute();
            $page = $stmt->fetch();
            if ($page) Hooks::set_content($page);
            return;
        }

        // If the slug matches the home page slug, redirect to /
        $home_stmt = $db->prepare("SELECT slug FROM ja_pages WHERE is_home = 1 LIMIT 1");
        $home_stmt->execute();
        $home = $home_stmt->fetch();
        if ($home && $slug === $home['slug']) {
            header('Location: ' . JA_BASE_URL . '/', true, 301);
            exit;
        }

        $stmt = $db->prepare("SELECT * FROM ja_pages WHERE slug = ? AND status = 'published' LIMIT 1");
        $stmt->execute([$slug]);
        $page = $stmt->fetch();

        if ($page) {
            Hooks::set_content($page);
        } else {
            http_response_code(404);
            Hooks::set_content(['title' => 'Page not found', 'content' => '<p>The page you are looking for does not exist.</p>', 'is_html' => true]);
        }
    }

    // ------------------------------------------------------------------
    // Admin — list or edit view
    // ------------------------------------------------------------------
    public static function renderAdmin($db, $csrf = '') {
        $action = $_GET['action'] ?? 'list';
        $edit_id = isset($_GET['edit']) ? (int)$_GET['edit'] : null;

        if ($edit_id || $action === 'new') {
            return self::renderEditor($db, $csrf, $edit_id);
        }
        return self::renderList($db, $csrf);
    }

    private static function renderList($db, $csrf) {
        $pages = $db->query("SELECT * FROM ja_pages ORDER BY is_home DESC, title ASC")->fetchAll();
        $t     = urlencode($csrf);

        $html  = "<div style='display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;'>";
        $html .= "<h1 class='ja-page-header' style='margin:0;'>Pages</h1>";
        $html .= "<a href='?view=pages&action=new' class='ja-btn ja-btn-primary'>+ New page</a>";
        $html .= "</div>";

        $html .= "<div class='ja-card'>";
        $html .= "<table class='ja-table'>";
        $html .= "<thead><tr><th>Title</th><th>Slug</th><th>Menu</th><th></th></tr></thead><tbody>";

        foreach ($pages as $page) {
            $id       = (int)$page['id'];
            $home_tag = $page['is_home'] ? " <span style='font-size:11px;background:#e8f5e9;color:#2e7d32;padding:2px 7px;border-radius:4px;'>home</span>" : '';
            $menu_tag = $page['in_menu'] ? "<span style='font-size:11px;background:#e3f2fd;color:#1565c0;padding:2px 7px;border-radius:4px;'>in menu</span>" : '<span style="color:#ccc;font-size:13px;">—</span>';

            $html .= "<tr>";
            $html .= "<td><strong>" . htmlspecialchars($page['title']) . "</strong>{$home_tag}</td>";
            $html .= "<td><code style='font-size:12px;color:#666;'>/" . htmlspecialchars($page['slug']) . "</code></td>";
            $html .= "<td>{$menu_tag}</td>";
            $html .= "<td class='ja-table-actions'>";
            $html .= "<a href='?view=pages&edit={$id}' class='action-enable'>Edit</a>";
            if (!$page['is_home']) {
                $html .= "<a href='?view=pages&delete={$id}&_token={$t}' class='action-delete' onclick='return confirm(\"Delete this page?\")'>Delete</a>";
            }
            $html .= "</td></tr>";
        }

        $html .= "</tbody></table></div>";
        return $html;
    }

    private static function renderEditor($db, $csrf, $id = null) {
        $page = ['title' => '', 'slug' => '', 'content' => '', 'is_home' => 0, 'in_menu' => 0, 'status' => 'published'];

        if ($id) {
            $stmt = $db->prepare("SELECT * FROM ja_pages WHERE id = ?");
            $stmt->execute([$id]);
            $row = $stmt->fetch();
            if ($row) $page = $row;
        }

        $is_new  = !$id;
        $heading = $is_new ? 'New page' : 'Edit page';

        $html  = "<div style='display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;'>";
        $html .= "<h1 class='ja-page-header' style='margin:0;'>{$heading}</h1>";
        $html .= "<a href='?view=pages' class='ja-btn ja-btn-secondary'>← Back</a>";
        $html .= "</div>";

        $html .= "<form method='POST'>";
        $html .= "<input type='hidden' name='csrf' value='" . htmlspecialchars($csrf) . "'>";
        $html .= "<input type='hidden' name='ja_action' value='save_page'>";
        if ($id) $html .= "<input type='hidden' name='page_id' value='{$id}'>";

        // Title + slug
        $html .= "<div class='ja-card'>";
        $html .= "<label class='ja-label'>Title</label>";
        $html .= "<input type='text' name='title' id='ja-page-title' class='ja-input' value='" . htmlspecialchars($page['title']) . "' required>";
        $html .= "<label class='ja-label'>Slug</label>";
        if ($page['is_home']) {
            $html .= "<input type='hidden' name='slug' value='" . htmlspecialchars($page['slug']) . "'>";
            $html .= "<p style='font-size:13px;color:#888;background:#f5f5f5;padding:10px 12px;border-radius:7px;margin-bottom:16px;'>The home page is always served at <code>/</code> — no slug needed.</p>";
        } else {
            $html .= "<div style='display:flex;align-items:center;gap:8px;margin-bottom:16px;'>";
            $html .= "<span style='color:#888;font-size:14px;'>/</span>";
            $html .= "<input type='text' name='slug' id='ja-page-slug' class='ja-input' style='margin:0;' value='" . htmlspecialchars($page['slug']) . "' required>";
            $html .= "</div>";
        }
        $html .= "</div>";

        // Rich text editor
        $html .= "<div class='ja-card'>";
        $html .= "<label class='ja-label'>Content</label>";
        $html .= "<div id='ja-editor' style='min-height:300px;font-size:15px;border:1px solid #ddd;border-radius:7px;background:#fafafa;'></div>";
        $html .= "<input type='hidden' name='content' id='ja-content-input' value='" . htmlspecialchars($page['content']) . "'>";
        $html .= "</div>";

        // Options
        $html .= "<div class='ja-card'>";
        $html .= "<h3>Options</h3>";

        $in_menu_checked = $page['in_menu'] ? ' checked' : '';
        $html .= "<label style='display:flex;align-items:center;gap:10px;font-size:14px;cursor:pointer;margin-bottom:12px;'>";
        $html .= "<input type='checkbox' name='in_menu' value='1'{$in_menu_checked} style='width:auto;margin:0;'>";
        $html .= "Add to primary menu automatically</label>";

        if ($page['is_home']) {
            $html .= "<p style='font-size:13px;color:#888;margin:0;'>This is the home page — its slug cannot be changed.</p>";
        } else {
            $is_home_checked = $page['is_home'] ? ' checked' : '';
            $html .= "<label style='display:flex;align-items:center;gap:10px;font-size:14px;cursor:pointer;'>";
            $html .= "<input type='checkbox' name='is_home' value='1'{$is_home_checked} style='width:auto;margin:0;'>";
            $html .= "Set as home page</label>";
        }
        $html .= "</div>";

        $html .= "<button type='submit' class='ja-btn ja-btn-primary'>Save page</button>";
        $html .= "</form>";

        // Quill rich text editor
        $html .= "
<link href='https://cdnjs.cloudflare.com/ajax/libs/quill/1.3.7/quill.snow.min.css' rel='stylesheet'>
<script src='https://cdnjs.cloudflare.com/ajax/libs/quill/1.3.7/quill.min.js'></script>
<script>
var quill = new Quill('#ja-editor', {
    theme: 'snow',
    modules: {
        toolbar: [
            [{ header: [1, 2, 3, false] }],
            ['bold', 'italic', 'underline'],
            ['link', 'blockquote'],
            [{ list: 'ordered' }, { list: 'bullet' }],
            ['clean']
        ]
    }
});

// Load existing content
var existing = document.getElementById('ja-content-input').value;
if (existing) quill.root.innerHTML = existing;

// Auto-generate slug from title on new pages
var titleInput = document.getElementById('ja-page-title');
var slugInput  = document.getElementById('ja-page-slug');
var slugEdited = " . ($is_new ? 'false' : 'true') . ";

if (titleInput && slugInput && !slugInput.readOnly) {
    titleInput.addEventListener('input', function() {
        if (!slugEdited) {
            slugInput.value = titleInput.value
                .toLowerCase()
                .replace(/[^a-z0-9]+/g, '-')
                .replace(/^-+|-+$/g, '');
        }
    });
    slugInput.addEventListener('input', function() { slugEdited = true; });
}

// Sync Quill to hidden input on submit
document.querySelector('form').addEventListener('submit', function() {
    document.getElementById('ja-content-input').value = quill.root.innerHTML;
});
</script>
<style>
.ql-toolbar { border-radius: 7px 7px 0 0 !important; border-color: #ddd !important; background: #fff; }
.ql-container { border-radius: 0 0 7px 7px !important; border-color: #ddd !important; font-size: 15px !important; min-height: 280px; }
.ql-editor { min-height: 280px; }
</style>";

        return $html;
    }

    // ------------------------------------------------------------------
    // Save handler
    // ------------------------------------------------------------------
    public static function handleSave($db, $post) {
        $action  = $post['ja_action'] ?? '';
        if ($action !== 'save_page') return false;

        $id      = isset($post['page_id']) ? (int)$post['page_id'] : null;
        $title   = trim($post['title']   ?? '');
        $slug    = trim($post['slug']    ?? '');
        $content = $post['content']      ?? '';
        $is_home = !empty($post['is_home']) ? 1 : 0;
        $in_menu = !empty($post['in_menu']) ? 1 : 0;

        if (!$title || !$slug) return false;

        // Sanitize slug
        $slug = preg_replace('/[^a-z0-9\-]/', '', strtolower($slug));

        // If setting as home, unset others
        if ($is_home) {
            $db->exec("UPDATE ja_pages SET is_home = 0");
        }

        if ($id) {
            // Check if this page is already home — keep slug locked
            $stmt = $db->prepare("SELECT is_home, slug FROM ja_pages WHERE id = ?");
            $stmt->execute([$id]);
            $existing = $stmt->fetch();
            if ($existing && $existing['is_home']) {
                $slug    = $existing['slug'];
                $is_home = 1;
            }

            $stmt = $db->prepare(
                "UPDATE ja_pages SET title = ?, slug = ?, content = ?, is_home = ?, in_menu = ? WHERE id = ?"
            );
            $stmt->execute([$title, $slug, $content, $is_home, $in_menu, $id]);
        } else {
            $stmt = $db->prepare(
                "INSERT INTO ja_pages (title, slug, content, is_home, in_menu, status) VALUES (?, ?, ?, ?, ?, 'published')"
            );
            $stmt->execute([$title, $slug, $content, $is_home, $in_menu]);
            $id = (int)$db->lastInsertId();
        }

        // Sync primary menu
        self::syncMenu($db, $id, $title, $slug, $in_menu);

        // Fire page_save hook — plugins can react to page saves
        \JA\Core\Hooks::fire('page_save', [
            'id'      => $id,
            'title'   => $title,
            'slug'    => $slug,
            'is_home' => $is_home,
            'in_menu' => $in_menu,
        ]);

        // Redirect to list after save
        header('Location: ?view=pages');
        exit;
    }

    // ------------------------------------------------------------------
    // Delete handler
    // ------------------------------------------------------------------
    public static function handleDelete($db, $id) {
        $id   = (int)$id;
        $stmt = $db->prepare("SELECT is_home, slug FROM ja_pages WHERE id = ?");
        $stmt->execute([$id]);
        $page = $stmt->fetch();
        if (!$page || $page['is_home']) return false; // Never delete home

        // Remove from menu
        self::syncMenu($db, $id, '', $page['slug'], false);

        $stmt = $db->prepare("DELETE FROM ja_pages WHERE id = ?");
        $stmt->execute([$id]);
        return true;
    }

    // ------------------------------------------------------------------
    // Menu sync — keeps primary menu in step with in_menu flag
    // ------------------------------------------------------------------
    private static function syncMenu($db, $page_id, $title, $slug, $in_menu) {
        $menus   = Hooks::get_all_menus();
        // Find the primary menu (first enabled one, or first one)
        $primary_key = null;
        foreach ($menus as $key => $menu) {
            if (!$primary_key) $primary_key = $key;
            if (!empty($menu['enabled'])) { $primary_key = $key; break; }
        }
        if (!$primary_key) return;

        $item_key = 'page_' . $page_id;
        $items    = $menus[$primary_key]['items'] ?? [];

        // Remove existing entry for this page (by item_key marker)
        $items = array_values(array_filter($items, function($item) use ($item_key) {
            return ($item['_key'] ?? '') !== $item_key;
        }));

        // Add back if in_menu
        if ($in_menu && $title) {
            $items[] = ['label' => $title, 'url' => '/' . $slug, '_key' => $item_key];
        }

        $menus[$primary_key]['items'] = $items;
        Hooks::save_menus($menus);
    }
}
