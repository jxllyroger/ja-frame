<?php
namespace JA\Plugins;
use JA\Core\Hooks;
use JA\Core\AdminMenu;
use JA\Core\Content;
use JA\Core\SiteMenus;
use JA\Core\Assets;
use JA\Core\Options;
use JA\Core\Media as CoreMedia;

class Pages {
    public static function init() {
        AdminMenu::add('Pages', 'pages', '📝');
    }

    public static function bootFrontend($db) {
        $uri  = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
        $slug = trim(str_replace(
            rtrim(str_replace(['/public', '/ja-admin'], '', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/'),
            '',
            $uri
        ), '/');

        if ($slug === '' || $slug === 'index.php') {
            $stmt = $db->prepare("SELECT * FROM ja_pages WHERE is_home = 1 AND status = 'published' LIMIT 1");
            $stmt->execute();
            $page = $stmt->fetch();
            if ($page) Content::set($page);
            return;
        }

        $home_stmt = $db->prepare("SELECT slug FROM ja_pages WHERE is_home = 1 LIMIT 1");
        $home_stmt->execute();
        $home = $home_stmt->fetch();
        if ($home && $slug === $home['slug']) {
            header('Location: ' . JA_BASE_URL . '/', true, 301);
            exit;
        }

        $preview = self::isAdminPreview();
        $stmt = $db->prepare($preview
            ? "SELECT * FROM ja_pages WHERE slug = ? LIMIT 1"
            : "SELECT * FROM ja_pages WHERE slug = ? AND status = 'published' LIMIT 1");
        $stmt->execute([$slug]);
        $page = $stmt->fetch();

        if ($page && $preview && ($page['status'] ?? 'published') === 'draft') {
            header('X-Robots-Tag: noindex');
            header('Cache-Control: no-store');
        }

        if ($page) {
            Content::set($page);
        } else {
            http_response_code(404);
            Content::set(['title' => 'Page not found', 'content' => '<p>The page you are looking for does not exist.</p>', 'is_html' => true]);
        }
    }

    /** ?preview=1 shows drafts, but only to a logged-in admin. */
    private static function isAdminPreview(): bool {
        if (!isset($_GET['preview'])) return false;
        \JA\Core\Session::start();
        return \JA\Core\Session::check();
    }

    private static ?bool $has_hide_title = null;

    /**
     * Existing installs predate the hide_title column, so add it the first time the admin needs it.
     * Returns false if the column can't be created (e.g. no ALTER permission); the rest of the
     * plugin keeps working without the option.
     */
    private static function ensureSchema($db): bool {
        if (self::$has_hide_title !== null) return self::$has_hide_title;

        try {
            $has = $db->query("SHOW COLUMNS FROM ja_pages LIKE 'hide_title'")->fetch();
            if (!$has) {
                $db->exec("ALTER TABLE ja_pages ADD COLUMN hide_title TINYINT(1) NOT NULL DEFAULT 0 AFTER in_menu");
            }
            self::$has_hide_title = true;
        } catch (\Throwable $e) {
            error_log('JA Pages: could not add hide_title column: ' . $e->getMessage());
            self::$has_hide_title = false;
        }
        return self::$has_hide_title;
    }

    public static function renderAdmin($db, $csrf = '') {
        $action  = $_GET['action'] ?? 'list';
        $edit_id = isset($_GET['edit']) ? (int)$_GET['edit'] : null;

        if ($edit_id || $action === 'new') {
            return self::renderEditor($db, $csrf, $edit_id);
        }
        return self::renderList($db, $csrf);
    }

    private static function renderList($db, $csrf) {
        $pages = $db->query("SELECT * FROM ja_pages ORDER BY is_home DESC, title ASC")->fetchAll();

        $html  = "<div style='display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;'>";
        $html .= "<h1 class='ja-page-header' style='margin:0;'>Pages</h1>";
        $html .= "<a href='?view=pages&action=new' class='ja-btn ja-btn-primary'>+ New page</a>";
        $html .= "</div>";

        $html .= "<div class='ja-card'>";
        $html .= "<table class='ja-table'>";
        $html .= "<thead><tr><th>Title</th><th>Slug</th><th>Menu</th><th></th></tr></thead><tbody>";

        foreach ($pages as $page) {
            $id       = (int)$page['id'];
            $home_tag = $page['is_home'] ? " <span style='font-size:11px;background:#e8f5e9;color:#2e7d32;padding:2px 7px;border-radius:4px;'>home</span>" : '';
            $menu_tag = $page['in_menu'] ? "<span style='font-size:11px;background:#e3f2fd;color:#1565c0;padding:2px 7px;border-radius:4px;'>in menu</span>" : '<span style="color:#ccc;font-size:13px;">—</span>';

            $html .= "<tr>";
            $draft_tag = (($page['status'] ?? 'published') === 'draft')
                ? " <span style='font-size:11px;background:#fff3e0;color:#e65100;padding:2px 7px;border-radius:4px;'>draft</span>" : '';
            $html .= "<td><strong>" . htmlspecialchars($page['title']) . "</strong>{$home_tag}{$draft_tag}</td>";
            $html .= "<td><code style='font-size:12px;color:#666;'>/" . htmlspecialchars($page['slug']) . "</code></td>";
            $html .= "<td>{$menu_tag}</td>";
            $html .= "<td class='ja-table-actions'>";
            $html .= "<a href='?view=pages&edit={$id}' class='action-enable'>Edit</a>";
            if ($draft_tag !== '') {
                $html .= "<a href='" . JA_BASE_URL . "/" . rawurlencode($page['slug']) . "?preview=1' target='_blank' rel='noopener' class='action-enable'>Preview</a>";
            }
            if (!$page['is_home']) {
                $html .= \JA\Core\AdminUI::postButton('Delete', 'page_delete', ['id' => $id], $csrf, 'action-delete', 'Delete this page?');
            }
            $html .= "</td></tr>";
        }

        $html .= "</tbody></table></div>";
        return $html;
    }

    private static function renderEditor($db, $csrf, $id = null) {
        $page = ['title' => '', 'slug' => '', 'content' => '', 'is_home' => 0, 'in_menu' => 0, 'hide_title' => 0, 'status' => 'published'];

        if ($id) {
            $stmt = $db->prepare("SELECT * FROM ja_pages WHERE id = ?");
            $stmt->execute([$id]);
            $row = $stmt->fetch();
            if ($row) $page = $row;
        }

        $is_new  = !$id;
        $heading = $is_new ? 'New page' : 'Edit page';

        $html  = "<div style='display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;'>";
        $html .= "<h1 class='ja-page-header' style='margin:0;'>{$heading}</h1>";
        $html .= "<a href='?view=pages' class='ja-btn ja-btn-secondary'>← Back</a>";
        $html .= "</div>";

        $html .= "<form method='POST' id='ja-page-form' data-new='" . ($is_new ? '1' : '0') . "'>";
        $html .= "<input type='hidden' name='csrf' value='" . htmlspecialchars($csrf) . "'>";
        $html .= "<input type='hidden' name='ja_action' value='save_page'>";
        if ($id) $html .= "<input type='hidden' name='page_id' value='{$id}'>";

        $html .= "<div class='ja-card'>";
        $html .= "<label class='ja-label'>Title</label>";
        $html .= "<input type='text' name='title' id='ja-page-title' class='ja-input' value='" . htmlspecialchars($page['title']) . "' required>";
        $html .= "<label class='ja-label'>Slug</label>";
        if ($page['is_home']) {
            $html .= "<input type='hidden' name='slug' value='" . htmlspecialchars($page['slug']) . "'>";
            $html .= "<p style='font-size:13px;color:#888;background:#f5f5f5;padding:10px 12px;border-radius:7px;margin-bottom:16px;'>The home page is always served at <code>/</code> — no slug needed.</p>";
        } else {
            $html .= "<div style='display:flex;align-items:center;gap:8px;margin-bottom:16px;'>";
            $html .= "<span style='color:#888;font-size:14px;'>/</span>";
            $html .= "<input type='text' name='slug' id='ja-page-slug' class='ja-input' style='margin:0;' value='" . htmlspecialchars($page['slug']) . "' required>";
            $html .= "</div>";
        }
        $html .= "</div>";

        $html .= "<div class='ja-card'>";
        $html .= "<label class='ja-label'>Content</label>";
        $html .= "<div id='ja-editor' style='min-height:300px;font-size:15px;border:1px solid #ddd;border-radius:7px;background:#fafafa;'></div>";
        $html .= "<input type='hidden' name='content' id='ja-content-input' value='" . htmlspecialchars($page['content']) . "'>";
        $html .= "</div>";

        $html .= "<div class='ja-card'>";
        $html .= "<h3>Options</h3>";
        $in_menu_checked = $page['in_menu'] ? ' checked' : '';
        $html .= "<label style='display:flex;align-items:center;gap:10px;font-size:14px;cursor:pointer;margin-bottom:12px;'>";
        $html .= "<input type='checkbox' name='in_menu' value='1'{$in_menu_checked} style='width:auto;margin:0;'>";
        $html .= "Add to primary menu automatically</label>";

        $status = (($page['status'] ?? 'published') === 'draft') ? 'draft' : 'published';
        if ($page['is_home']) {
            $html .= "<p style='font-size:13px;color:#888;margin:8px 0 12px;'>Status: Published. The home page is always published.</p>";
        } else {
            $html .= "<label class='ja-label'>Status</label>";
            $html .= "<select name='status' class='ja-input' style='max-width:220px;margin-bottom:6px;'>";
            $html .= "<option value='published'" . ($status === 'published' ? ' selected' : '') . ">Published</option>";
            $html .= "<option value='draft'" . ($status === 'draft' ? ' selected' : '') . ">Draft</option>";
            $html .= "</select>";
            $html .= "<p style='font-size:12px;color:#888;margin:0 0 14px;'>Drafts are hidden from the site and the menu. You can preview them from the Pages list while logged in.</p>";
        }

        if (self::ensureSchema($db)) {
            $hide_checked = !empty($page['hide_title']) ? ' checked' : '';
            $html .= "<label style='display:flex;align-items:center;gap:10px;font-size:14px;cursor:pointer;margin-bottom:4px;'>";
            $html .= "<input type='checkbox' name='hide_title' value='1'{$hide_checked} style='width:auto;margin:0;'>";
            $html .= "Hide the page title on the page</label>";
            $html .= "<p style='font-size:12px;color:#888;margin:0 0 12px 26px;'>The title still shows in the browser tab and menus. Useful for landing pages that have their own heading.</p>";
        }

        if ($page['is_home']) {
            $html .= "<p style='font-size:13px;color:#888;margin:0;'>This is the home page — its slug cannot be changed.</p>";
        } else {
            $is_home_checked = $page['is_home'] ? ' checked' : '';
            $html .= "<label style='display:flex;align-items:center;gap:10px;font-size:14px;cursor:pointer;'>";
            $html .= "<input type='checkbox' name='is_home' value='1'{$is_home_checked} style='width:auto;margin:0;'>";
            $html .= "Set as home page</label>";
        }
        $html .= "</div>";

        $html .= "<button type='submit' class='ja-btn ja-btn-primary'>Save page</button>";
        $html .= "</form>";

        $html .= "
<div id='ja-media-modal' style='display:none;position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:9998;align-items:center;justify-content:center;padding:20px;'>
  <div style='background:#fff;border-radius:10px;max-width:900px;width:100%;max-height:85vh;display:flex;flex-direction:column;overflow:hidden;'>
    <div style='display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid #e5e5e3;flex-wrap:wrap;gap:12px;'>
      <strong style='font-size:15px;'>Insert image</strong>
      <div id='ja-media-sizes' style='display:flex;gap:6px;'>
        <button type='button' class='ja-size-btn ja-btn ja-btn-secondary ja-btn-sm' data-size='' onclick='jaSetSize(this)'>Natural</button>
        <button type='button' class='ja-size-btn ja-btn ja-btn-secondary ja-btn-sm' data-size='thumb' onclick='jaSetSize(this)'>Thumb</button>
        <button type='button' class='ja-size-btn ja-btn ja-btn-secondary ja-btn-sm' data-size='medium' onclick='jaSetSize(this)'>Medium</button>
        <button type='button' class='ja-size-btn ja-btn ja-btn-secondary ja-btn-sm' data-size='full' onclick='jaSetSize(this)'>Full</button>
      </div>
      <button type='button' onclick='jaCloseMediaPicker()' style='background:none;border:none;font-size:20px;cursor:pointer;color:#888;line-height:1;' aria-label='Close'>×</button>
    </div>
    <div id='ja-media-modal-body' style='padding:20px;overflow-y:auto;'></div>
  </div>
</div>
";

        // Editor assets (queued, printed by the admin footer/head hooks)
        Assets::style('quill-snow', 'https://cdnjs.cloudflare.com/ajax/libs/quill/1.3.7/quill.snow.min.css', 'admin');
        Assets::script('quill', 'https://cdnjs.cloudflare.com/ajax/libs/quill/1.3.7/quill.min.js', true, 'admin');
        Assets::style('ja-pages-editor', Assets::pluginUrl('ja-pages', 'assets/editor.css'), 'admin');
        Assets::script('ja-pages-editor', Assets::pluginUrl('ja-pages', 'assets/editor.js'), true, 'admin');

        return $html;
    }

    public static function handleSave($db, $post) {
        $action  = $post['ja_action'] ?? '';
        if ($action !== 'save_page') return false;

        $id      = isset($post['page_id']) ? (int)$post['page_id'] : null;
        $title   = trim($post['title']   ?? '');
        $slug    = trim($post['slug']    ?? '');
        $content = $post['content']      ?? '';
        $is_home = !empty($post['is_home']) ? 1 : 0;
        $in_menu = !empty($post['in_menu']) ? 1 : 0;
        $hide_title = !empty($post['hide_title']) ? 1 : 0;
        $has_hide   = self::ensureSchema($db);
        $status     = (($post['status'] ?? 'published') === 'draft') ? 'draft' : 'published';

        if (!$title || !$slug) return false;

        $slug = preg_replace('/[^a-z0-9\-]/', '', strtolower($slug));

        if ($is_home) {
            $db->exec("UPDATE ja_pages SET is_home = 0");
        }

        if ($id) {
            $stmt = $db->prepare("SELECT is_home, slug FROM ja_pages WHERE id = ?");
            $stmt->execute([$id]);
            $existing = $stmt->fetch();
            if ($existing && $existing['is_home']) {
                $slug    = $existing['slug'];
                $is_home = 1;
            }
        }

        // A draft home page would leave the site blank, so the home page is always published
        if ($is_home) $status = 'published';

        $fields = ['title' => $title, 'slug' => $slug, 'content' => $content, 'is_home' => $is_home, 'in_menu' => $in_menu, 'status' => $status];
        if ($has_hide) $fields['hide_title'] = $hide_title;

        if ($id) {
            $set  = implode(', ', array_map(fn($col) => "$col = ?", array_keys($fields)));
            $stmt = $db->prepare("UPDATE ja_pages SET $set WHERE id = ?");
            $stmt->execute([...array_values($fields), $id]);
        } else {
            $cols  = implode(', ', array_keys($fields));
            $marks = implode(', ', array_fill(0, count($fields), '?'));
            $stmt  = $db->prepare("INSERT INTO ja_pages ($cols) VALUES ($marks)");
            $stmt->execute(array_values($fields));
            $id = (int)$db->lastInsertId();
        }

        self::syncMenu($db, $id, $title, $slug, $in_menu && $status === 'published');

        \JA\Core\Hooks::fire('page_save', [
            'id'      => $id,
            'title'   => $title,
            'slug'    => $slug,
            'is_home' => $is_home,
            'in_menu' => $in_menu,
            'status'  => $status,
        ]);

        header('Location: ?view=pages');
        exit;
    }

    public static function handleDelete($db, $id) {
        $id   = (int)$id;
        $stmt = $db->prepare("SELECT is_home, slug FROM ja_pages WHERE id = ?");
        $stmt->execute([$id]);
        $page = $stmt->fetch();
        if (!$page || $page['is_home']) return false;

        self::syncMenu($db, $id, '', $page['slug'], false);

        $stmt = $db->prepare("DELETE FROM ja_pages WHERE id = ?");
        $stmt->execute([$id]);
        return true;
    }

    private static function syncMenu($db, $page_id, $title, $slug, $in_menu) {
        $menus   = SiteMenus::all();
        $primary_key = null;
        foreach ($menus as $key => $menu) {
            if (!$primary_key) $primary_key = $key;
            if (!empty($menu['enabled'])) { $primary_key = $key; break; }
        }
        if (!$primary_key) return;

        $item_key = 'page_' . $page_id;
        $items    = $menus[$primary_key]['items'] ?? [];

        $items = array_values(array_filter($items, function($item) use ($item_key) {
            return ($item['_key'] ?? '') !== $item_key;
        }));

        if ($in_menu && $title) {
            $items[] = ['label' => $title, 'url' => '/' . $slug, '_key' => $item_key];
        }

        $menus[$primary_key]['items'] = $items;
        SiteMenus::save($menus);
    }
}
