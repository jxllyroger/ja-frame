/* JA Pages — page editor (Quill, media picker, slug helper, custom HTML toggle). Loaded via Assets. */
var quill = new Quill('#ja-editor', {
    theme: 'snow',
    modules: {
        toolbar: {
            container: [
                [{ header: [1, 2, 3, false] }],
                ['bold', 'italic', 'underline'],
                ['link', 'blockquote'],
                [{ list: 'ordered' }, { list: 'bullet' }],
                ['clean'],
                ['ja-image'],
                ['ja-shortcode'],
                ['ja-html'] // Custom HTML toggle button
            ],
            handlers: {
                'ja-image':     jaOpenMediaPicker,
                'ja-shortcode': jaOpenShortcodePicker,
                'ja-html':      jaToggleHtmlMode // Hooks up visibility flip toggle
            }
        }
    }
});

// Setup the custom unicode icons on the toolbar panel grid
var imageIcon = quill.getModule('toolbar').container.querySelector('.ql-ja-image');
if (imageIcon) imageIcon.innerHTML = '🖼';
var scIcon    = quill.getModule('toolbar').container.querySelector('.ql-ja-shortcode');
if (scIcon) scIcon.innerHTML = '⚙';
var htmlIcon  = quill.getModule('toolbar').container.querySelector('.ql-ja-html');
if (htmlIcon) { htmlIcon.innerHTML = '‹›'; htmlIcon.title = 'Edit HTML'; }

var existing = document.getElementById('ja-content-input').value;

// Quill silently drops anything it has no format for (<div>, <style>, classes, iframes, …) and the
// next save would write that trimmed version over the original. So if the saved page contains
// markup Quill can't represent, open it in HTML mode and keep the original text untouched.
var startInHtml = jaNeedsHtmlMode(existing);
if (existing && !startInHtml) quill.root.innerHTML = existing;

// Dynamically inject a native text wrapper directly below the editor frame 
// to ensure the layout engine never locks it out
var editorContainer = document.getElementById('ja-editor');
var nativeTextArea = document.createElement('textarea');
nativeTextArea.id = 'ja-native-html-box';
nativeTextArea.style.display = 'none'; // Hidden by default
nativeTextArea.style.width = '100%';
nativeTextArea.style.height = editorContainer.style.height || '300px';
nativeTextArea.style.boxSizing = 'border-box';
nativeTextArea.style.padding = '14px';
nativeTextArea.style.fontFamily = 'monospace';
nativeTextArea.style.fontSize = '14px';
nativeTextArea.style.background = '#1a1a1a';
nativeTextArea.style.color = '#f8f8f2';
nativeTextArea.style.border = '1px solid #ddd';
nativeTextArea.style.borderRadius = '7px';
nativeTextArea.style.resize = 'vertical';
editorContainer.parentNode.insertBefore(nativeTextArea, editorContainer.nextSibling);

var titleInput = document.getElementById('ja-page-title');
var slugInput  = document.getElementById('ja-page-slug');
var pageForm   = document.getElementById('ja-page-form');
var slugEdited = pageForm.dataset.new !== '1';

if (titleInput && slugInput && !slugInput.readOnly) {
    titleInput.addEventListener('input', function() {
        if (!slugEdited) {
            slugInput.value = titleInput.value
                .toLowerCase()
                .replace(/[^a-z0-9]+/g, '-')
                .replace(/^-+|-+$/g, '');
        }
    });
    slugInput.addEventListener('input', function() { slugEdited = true; });
}

// True if the HTML contains anything the visual editor can't round-trip.
// Parsed with DOMParser, so nothing in it is executed or loaded.
function jaNeedsHtmlMode(html) {
    if (!html || !html.trim()) return false;

    var doc = new DOMParser().parseFromString('<body>' + html + '</body>', 'text/html');
    var allowedTags  = { P:1, BR:1, H1:1, H2:1, H3:1, STRONG:1, B:1, EM:1, I:1, U:1, A:1, BLOCKQUOTE:1, OL:1, UL:1, LI:1, IMG:1 };
    var allowedAttrs = { A: ['href', 'target', 'rel'], IMG: ['src', 'alt', 'class'] };
    var imgClasses   = ['thumb', 'medium', 'full'];

    var els = doc.body.querySelectorAll('*');
    for (var i = 0; i < els.length; i++) {
        var el = els[i];
        if (!allowedTags[el.tagName]) return true;

        for (var j = 0; j < el.attributes.length; j++) {
            var attr = el.attributes[j].name.toLowerCase();
            if (attr === 'class') {
                var classes = el.className.split(/\s+/);
                var okClass = el.tagName === 'IMG'
                    ? classes.every(function(c) { return !c || imgClasses.indexOf(c) !== -1; })
                    : classes.every(function(c) { return !c || c.indexOf('ql-') === 0; });
                if (!okClass) return true;
                continue;
            }
            if ((allowedAttrs[el.tagName] || []).indexOf(attr) === -1) return true;
        }
    }

    // HTML comments would be dropped too
    var walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_COMMENT);
    return walker.nextNode() !== null;
}

// Logic handler to flip layouts back and forth between rich text frame and raw HTML markup box
var isHtmlViewActive = false;
function jaToggleHtmlMode() {
    var htmlButton = quill.getModule('toolbar').container.querySelector('.ql-ja-html');
    var txtArea = document.getElementById('ja-native-html-box');
    
    if (!isHtmlViewActive) {
        // 1. Collect live layout data from editor
        var currentMarkup = quill.root.innerHTML;
        
        // 2. Synchronize string structure directly to our native text box
        txtArea.value = currentMarkup;
        
        // 3. Completely hide Quill's internal layout container pane to prevent hijacking
        editorContainer.style.display = 'none';
        
        // 4. Reveal the clean text block area window 
        txtArea.style.display = 'block';
        txtArea.style.minHeight = '300px';
        
        isHtmlViewActive = true;
        if (htmlButton) htmlButton.style.background = '#e3f2fd';
        txtArea.focus();
    } else {
        // 1. Pull the layout modifications you typed directly from the raw code area window
        var updatedMarkup = txtArea.value;

        // The visual editor only understands basic formatting; anything else is dropped when it loads.
        // Warn first, and let the person stay in HTML mode (saving from HTML mode keeps everything).
        var risky = /<(style|script|iframe|form|input|button|table|svg|video|audio|section|article|div|span)\b|\s(style|class|id|data-[\w-]+)\s*=/i;
        if (risky.test(updatedMarkup) &&
            !confirm('Switching back to the visual editor may remove HTML it does not support (such as <div>, <style>, <iframe>, or custom attributes).\n\nTip: you can save while in HTML mode to keep everything exactly as typed.\n\nSwitch anyway?')) {
            return;
        }
        
        // 2. Load it right back into Quill's workspace frame safely
        quill.root.innerHTML = updatedMarkup;
        
        // 3. Flip visibility states back over
        txtArea.style.display = 'none';
        editorContainer.style.display = 'block';
        
        isHtmlViewActive = false;
        if (htmlButton) htmlButton.style.background = 'none';
        if (htmlNote) htmlNote.style.display = 'none';
    }
}

// Open in HTML mode, with the ORIGINAL saved text, when the page has markup Quill can't hold
var htmlNote = null;
if (startInHtml) {
    nativeTextArea.value = existing;
    editorContainer.style.display = 'none';
    nativeTextArea.style.display = 'block';
    nativeTextArea.style.minHeight = '300px';
    isHtmlViewActive = true;
    if (htmlIcon) htmlIcon.style.background = '#e3f2fd';

    htmlNote = document.createElement('div');
    htmlNote.style.cssText = 'background:#fff8e1;border:1px solid #ffe082;color:#7a5b00;padding:8px 12px;font-size:13px;';
    htmlNote.textContent = 'This page contains custom HTML, so it opened in HTML mode to keep it exactly as written. Switching to the visual editor can remove unsupported markup.';
    nativeTextArea.parentNode.insertBefore(htmlNote, nativeTextArea);
}

// Intercept form submissions to ensure database reads current input frame accurately
document.getElementById('ja-page-form').addEventListener('submit', function() {
    if (isHtmlViewActive) {
        var txtArea = document.getElementById('ja-native-html-box');
        document.getElementById('ja-content-input').value = txtArea ? txtArea.value : '';
    } else {
        document.getElementById('ja-content-input').value = quill.root.innerHTML;
    }
});

var jaMediaCache = null;
var jaCurrentSize = '';

function jaSetSize(el) {
    jaCurrentSize = el.dataset.size || '';
    document.querySelectorAll('.ja-size-btn').forEach(function(b) {
        b.classList.remove('ja-btn-primary');
        b.classList.add('ja-btn-secondary');
    });
    el.classList.remove('ja-btn-secondary');
    el.classList.add('ja-btn-primary');
}

function jaOpenMediaPicker() {
    if (isHtmlViewActive) { alert('Switch back to the visual editor to insert an image.'); return; }
    document.getElementById('ja-media-modal').style.display = 'flex';
    var body = document.getElementById('ja-media-modal-body');
    if (jaMediaCache) { jaRenderMediaGrid(jaMediaCache); return; }
    body.innerHTML = '<p style="color:#888;font-size:14px;">Loading…</p>';
    fetch('?view=media&json=1', { credentials: 'same-origin' })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            jaMediaCache = data;
            jaRenderMediaGrid(data);
        })
        .catch(function() {
            body.innerHTML = '<p style="color:#c62828;font-size:14px;">Could not load media library.</p>';
        });
}

function jaRenderMediaGrid(files) {
    var body = document.getElementById('ja-media-modal-body');
    if (!files.length) {
        body.innerHTML = '<p style="color:#888;font-size:14px;">No images yet. <a href="?view=media">Upload some</a> first.</p>';
        return;
    }
    var html = '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:12px;">';
    files.forEach(function(m) {
        var url  = m.url;
        var name = m.original_name.replace(/"/g, '&quot;');
        html += '<div style="cursor:pointer;border-radius:8px;overflow:hidden;background:#f5f5f5;border:1px solid #e5e5e3;position:relative;aspect-ratio:1/1;" onclick="jaInsertImage(\'' + url + '\', \'' + name.replace(/'/g, "\\'") + '\')">';
        html += '<img src="' + url + '" alt="' + name + '" loading="lazy" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;">';
        html += '</div>';
    });
    html += '</div>';
    body.innerHTML = html;
}

function jaInsertImage(url, alt) {
    var range = quill.getSelection(true);
    var index = range ? range.index : quill.getLength();
    quill.insertEmbed(index, 'image', url, 'user');
    var imgs = quill.root.querySelectorAll('img[src="' + url + '"]');
    if (imgs.length) {
        var node = imgs[imgs.length - 1];
        node.setAttribute('alt', alt);
        if (jaCurrentSize) node.classList.add(jaCurrentSize);
    }
    quill.setSelection(index + 1, 0);
    jaCloseMediaPicker();
}

function jaCloseMediaPicker() {
    document.getElementById('ja-media-modal').style.display = 'none';
}

function jaOpenShortcodePicker() {
    if (isHtmlViewActive) { alert('Switch back to the visual editor to insert a shortcode, or type it directly into the HTML.'); return; }
    var tag = prompt('Shortcode name (e.g. roster):');
    if (!tag) return;
    tag = tag.replace(/[^a-z0-9_]/gi, '');
    if (!tag) return;
    var range = quill.getSelection(true);
    var index = range ? range.index : quill.getLength();
    quill.insertText(index, '[' + tag + ']', 'user');
    quill.setSelection(index + tag.length + 2, 0);
}
