<?php
namespace JA\Plugins;
use JA\Core\Media as CoreMedia;

class Media {
    public static function init() {}

    public static function renderAdmin($db, $csrf = '') {
        $files = CoreMedia::getAll($db);
        $base  = JA_BASE_URL;

        $html  = "<h1 class='ja-page-header'>Media</h1>";

        // Upload card
        $html .= "<div class='ja-card'>";
        $html .= "<h3>Upload file</h3>";
        $html .= "<form method='POST' enctype='multipart/form-data'>";
        $html .= "<input type='hidden' name='csrf' value='" . htmlspecialchars($csrf) . "'>";
        $html .= "<div class='ja-upload-area'>";
        $html .= "<input type='file' name='ja_upload' id='ja_upload_input' class='ja-file-input' required onchange=\"document.getElementById('ja_chosen').textContent = this.files[0]?.name || 'No file chosen'\">";
        $html .= "<label for='ja_upload_input' class='ja-file-label'>Choose file</label>";
        $html .= "<span id='ja_chosen' class='ja-file-chosen'>No file chosen</span>";
        $html .= "<button type='submit' class='ja-btn ja-btn-primary'>Upload</button>";
        $html .= "</div>";
        $html .= "<p style='font-size:12px;color:#888;margin:8px 0 0;'>Allowed: jpg, jpeg, png, gif, ico, svg</p>";
        $html .= "</form></div>";

        // Library card
        $count = count($files);
        $html .= "<div class='ja-card'>";
        $html .= "<h3>Library" . ($count ? " <span style='font-weight:400;color:#888;font-size:13px;'>({$count} files)</span>" : "") . "</h3>";

        if (!empty($files)) {
            $html .= "<div class='ja-media-grid'>";
            foreach ($files as $m) {
                $url  = htmlspecialchars($base . '/uploads/' . $m['filename']);
                $name = htmlspecialchars($m['original_name']);
                $size = $m['file_size'] ? round($m['file_size'] / 1024, 1) . ' KB' : '';
                $meta = $name . ($size ? ' · ' . $size : '');
                $id   = (int)$m['id'];
                $html .= "<div class='ja-media-item'>";
                $html .= "<img src='{$url}' alt='{$name}' loading='lazy' onclick=\"jaLightboxOpen('{$url}', " . json_encode($meta) . ")\">";
                $html .= "<div class='ja-media-caption'>{$name}</div>";
                $html .= \JA\Core\AdminUI::postButton('✕', 'media_delete', ['id' => $id], $csrf, 'ja-media-delete', 'Delete ' . $m['original_name'] . '?', 'Delete');
                $html .= "</div>";
            }
            $html .= "</div>";
        } else {
            $html .= "<p style='color:#aaa;font-size:14px;margin:4px 0 0;'>No files uploaded yet.</p>";
        }

        $html .= "</div>";
        return $html;
    }
}
