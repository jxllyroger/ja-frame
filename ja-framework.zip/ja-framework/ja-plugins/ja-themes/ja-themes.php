<?php
namespace JA\Plugins;

class Themes {
    public static function init() {}

    public static function renderAdmin($db, $csrf = '') {
        $themes       = array_filter(glob(JA_ROOT . '/ja-themes/*'), 'is_dir');
        $active_theme = \JA\Core\Options::get('active_theme', 'ja-clean');

        $html  = "<h1 class='ja-page-header'>Themes</h1>";

        // Install card
        $html .= "<div class='ja-card'>";
        $html .= "<h3>Install theme (.zip)</h3>";
        $html .= "<form method='POST' enctype='multipart/form-data'>";
        $html .= "<input type='hidden' name='csrf' value='" . htmlspecialchars($csrf) . "'>";
        $html .= "<div class='ja-upload-area'>";
        $html .= "<input type='file' name='theme_zip' id='theme_zip_input' class='ja-file-input' accept='.zip' required onchange=\"document.getElementById('theme_zip_chosen').textContent = this.files[0]?.name || 'No file chosen'\">";
        $html .= "<label for='theme_zip_input' class='ja-file-label'>Choose file</label>";
        $html .= "<span id='theme_zip_chosen' class='ja-file-chosen'>No file chosen</span>";
        $html .= "<button type='submit' class='ja-btn ja-btn-primary'>Install</button>";
        $html .= "</div></form></div>";

        // Theme list
        $html .= "<div class='ja-card'>";
        $html .= "<table class='ja-table'>";
        $html .= "<thead><tr><th>Theme</th><th></th></tr></thead><tbody>";

        foreach ($themes as $t_dir) {
            $id     = basename($t_dir);
            $active = ($id === $active_theme);
            $info   = self::manifest($id);
            $h      = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
            $html  .= "<tr><td><strong>" . $h($info['name']) . "</strong>";
            if ($info['version'] !== '') $html .= " <span style='font-size:12px;color:#888;margin-left:6px;'>v" . $h($info['version']) . "</span>";
            $html  .= $active ? " <span style='font-size:12px;color:#2e7d32;margin-left:6px;'>active</span>" : "";
            $sub = [];
            if ($info['name'] !== $id)       $sub[] = $h($id);
            if ($info['author'] !== '')      $sub[] = 'by ' . $h($info['author']);
            if ($info['description'] !== '') $sub[] = $h($info['description']);
            if ($sub) $html .= "<div style='font-size:12px;color:#888;margin-top:2px;'>" . implode(' · ', $sub) . "</div>";
            $html  .= "</td><td class='ja-table-actions'>";
            if ($active) {
                $html .= "<span class='action-locked'>Active</span>";
            } else {
                $html .= \JA\Core\AdminUI::postButton('Activate', 'theme_activate', ['id' => $id], $csrf, 'action-enable');
                $html .= \JA\Core\AdminUI::postButton('Delete', 'theme_delete', ['id' => $id], $csrf, 'action-delete', "Delete theme {$id}? This cannot be undone.");
            }
            $html .= "</td></tr>";
        }

        $html .= "</tbody></table></div>";
        return $html;
    }

    /**
     * Reads the optional theme.json. Falls back to the folder name when it's missing or invalid.
     * @return array{name:string, version:string, description:string, author:string}
     */
    public static function manifest(string $theme_id): array {
        $info = ['name' => $theme_id, 'version' => '', 'description' => '', 'author' => ''];
        $file = JA_ROOT . '/ja-themes/' . basename($theme_id) . '/theme.json';
        if (is_file($file)) {
            $data = json_decode((string) file_get_contents($file), true);
            if (is_array($data)) {
                foreach ($info as $key => $_) {
                    if (isset($data[$key]) && is_string($data[$key]) && $data[$key] !== '') {
                        $info[$key] = $data[$key];
                    }
                }
            }
        }
        return $info;
    }

    /**
     * @return array{ok:bool, message:string}
     */
    public static function handleInstall($zip_file) {
        $result = \JA\Core\Package::install(
            $zip_file,
            JA_ROOT . '/ja-themes',
            fn($id) => 'index.php',
            ['ja-clean', 'ja-default'],
            ['style.css']
        );

        if (!$result['ok']) {
            return ['ok' => false, 'message' => '❌ Theme install failed: ' . htmlspecialchars($result['message'], ENT_QUOTES, 'UTF-8')];
        }
        return ['ok' => true, 'message' => '✅ Theme installed!'];
    }

    public static function handleDelete($db, $theme_id) {
        $theme_id     = basename((string) $theme_id);
        $active_theme = \JA\Core\Options::get('active_theme', 'ja-clean');
        if ($theme_id === $active_theme || $theme_id === 'ja-clean') return false;

        $target = JA_ROOT . '/ja-themes/' . $theme_id;
        if (!is_dir($target)) return false;

        // Package::removeDir refuses anything that isn't inside ja-themes/
        return \JA\Core\Package::removeDir($target, JA_ROOT . '/ja-themes');
    }

    public static function handleActivate($db, $theme) {
        $theme = basename((string) $theme);
        if (!preg_match('/^[a-z0-9]+(-[a-z0-9]+)*$/', $theme)) return false;
        if (!is_file(JA_ROOT . '/ja-themes/' . $theme . '/index.php')) return false;

        // Options::set inserts the row if it's missing (a bare UPDATE silently does nothing)
        \JA\Core\Options::set('active_theme', $theme);
        return true;
    }
}
