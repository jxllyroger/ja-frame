<?php
namespace JA\Plugins;

class Themes {
    public static function init() {}

    public static function renderAdmin($db, $csrf = '') {
        $themes       = array_filter(glob(JA_ROOT . '/ja-themes/*'), 'is_dir');
        $active_theme = \JA\Core\Options::get('active_theme', 'ja-clean');
        $t            = urlencode($csrf);

        $html  = "<h1 class='ja-page-header'>Themes</h1>";

        // Install card
        $html .= "<div class='ja-card'>";
        $html .= "<h3>Install theme (.zip)</h3>";
        $html .= "<form method='POST' enctype='multipart/form-data'>";
        $html .= "<input type='hidden' name='csrf' value='" . htmlspecialchars($csrf) . "'>";
        $html .= "<div class='ja-upload-area'>";
        $html .= "<input type='file' name='theme_zip' id='theme_zip_input' class='ja-file-input' accept='.zip' required onchange=\"document.getElementById('theme_zip_chosen').textContent = this.files[0]?.name || 'No file chosen'\">";
        $html .= "<label for='theme_zip_input' class='ja-file-label'>Choose file</label>";
        $html .= "<span id='theme_zip_chosen' class='ja-file-chosen'>No file chosen</span>";
        $html .= "<button type='submit' class='ja-btn ja-btn-primary'>Install</button>";
        $html .= "</div></form></div>";

        // Theme list
        $html .= "<div class='ja-card'>";
        $html .= "<table class='ja-table'>";
        $html .= "<thead><tr><th>Theme</th><th></th></tr></thead><tbody>";

        foreach ($themes as $t_dir) {
            $id     = basename($t_dir);
            $active = ($id === $active_theme);
            $html  .= "<tr><td><strong>" . htmlspecialchars($id) . "</strong>";
            $html  .= $active ? " <span style='font-size:12px;color:#888;margin-left:6px;'>active</span>" : "";
            $html  .= "</td><td class='ja-table-actions'>";
            if ($active) {
                $html .= "<span class='action-locked'>Active</span>";
            } else {
                $html .= "<a href='?view=themes&activate=" . urlencode($id) . "&_token={$t}' class='action-enable'>Activate</a>";
                $html .= "<a href='?view=themes&delete=" . urlencode($id) . "&_token={$t}' class='action-delete' onclick='return confirm(\"Delete theme " . htmlspecialchars($id, ENT_QUOTES) . "? This cannot be undone.\")'>Delete</a>";
            }
            $html .= "</td></tr>";
        }

        $html .= "</tbody></table></div>";
        return $html;
    }

    public static function handleInstall($zip_file) {
        if ($zip_file['error'] !== UPLOAD_ERR_OK) return false;
        if (strtolower(pathinfo($zip_file['name'], PATHINFO_EXTENSION)) !== 'zip') return false;

        $zip = new \ZipArchive();
        if ($zip->open($zip_file['tmp_name']) !== true) return false;

        // Validate every entry before extracting — block path traversal
        $target_base = realpath(JA_ROOT . '/ja-themes');
        $theme_name  = null;

        for ($i = 0; $i < $zip->numFiles; $i++) {
            $entry      = $zip->getNameIndex($i);
            $parts      = explode('/', trim($entry, '/'));
            $clean_name = $parts[0];

            // Grab theme folder name from first entry
            if ($theme_name === null && !empty($clean_name)) {
                $theme_name = $clean_name;
            }

            // Block any entry that would escape the target directory
            $resolved = realpath($target_base . '/' . ltrim($entry, '/'));
            if ($resolved === false) {
                // realpath returns false for non-existent paths during extraction preview,
                // so check the string directly instead
                $normalized = $target_base . '/' . ltrim($entry, '/');
                if (strpos($normalized, $target_base) !== 0) {
                    $zip->close();
                    return false;
                }
            } elseif (strpos($resolved, $target_base) !== 0) {
                $zip->close();
                return false;
            }

            // Block any entry with .. in the path
            if (strpos($entry, '..') !== false) {
                $zip->close();
                return false;
            }
        }

        if (!$theme_name) { $zip->close(); return false; }

        $zip->extractTo(JA_ROOT . '/ja-themes/');
        $zip->close();
        return is_dir(JA_ROOT . '/ja-themes/' . basename($theme_name));
    }

    public static function handleDelete($db, $theme_id) {
        $active_theme = \JA\Core\Options::get('active_theme', 'ja-clean');
        if ($theme_id === $active_theme || $theme_id === 'ja-clean') return false;

        $target = JA_ROOT . '/ja-themes/' . basename($theme_id);
        if (!is_dir($target)) return false;

        // Confirm target is actually inside ja-themes/ (block traversal on delete too)
        $real_base   = realpath(JA_ROOT . '/ja-themes');
        $real_target = realpath($target);
        if (!$real_target || strpos($real_target, $real_base) !== 0 || $real_target === $real_base) {
            return false;
        }

        self::deleteDir($target);
        return !is_dir($target);
    }

    private static function deleteDir($dir) {
        foreach (scandir($dir) as $item) {
            if ($item === '.' || $item === '..') continue;
            $path = $dir . '/' . $item;
            is_dir($path) ? self::deleteDir($path) : unlink($path);
        }
        rmdir($dir);
    }

    public static function handleActivate($db, $theme) {
        $stmt = $db->prepare("UPDATE ja_options SET option_value = ? WHERE option_name = 'active_theme'");
        return $stmt->execute([$theme]);
    }
}
