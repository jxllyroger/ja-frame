<?php
namespace JA\Plugins;

class Themes {
    public static function init() {}

    public static function renderAdmin($db, $csrf = '') {
        $customize = $_GET['customize'] ?? '';
        if (is_string($customize) && preg_match('/^[a-z0-9]+(-[a-z0-9]+)*$/', $customize) && is_dir(JA_ROOT . '/ja-themes/' . $customize)) {
            return self::renderCustomize($csrf, $customize);
        }

        $themes       = array_filter(glob(JA_ROOT . '/ja-themes/*'), 'is_dir');
        $active_theme = \JA\Core\Options::get('active_theme', 'default');

        $html  = "<h1 class='ja-page-header'>Themes</h1>";

        // Install card
        $html .= "<div class='ja-card'>";
        $html .= "<h3>Install theme (.zip)</h3>";
        $html .= "<form method='POST' enctype='multipart/form-data'>";
        $html .= "<input type='hidden' name='csrf' value='" . htmlspecialchars($csrf) . "'>";
        $html .= "<div class='ja-upload-area'>";
        $html .= "<input type='file' name='theme_zip' id='theme_zip_input' class='ja-file-input' accept='.zip' required onchange=\"document.getElementById('theme_zip_chosen').textContent = this.files[0]?.name || 'No file chosen'\">";
        $html .= "<label for='theme_zip_input' class='ja-file-label'>Choose file</label>";
        $html .= "<span id='theme_zip_chosen' class='ja-file-chosen'>No file chosen</span>";
        $html .= "<button type='submit' class='ja-btn ja-btn-primary'>Install</button>";
        $html .= "</div></form></div>";

        // Theme list
        $html .= "<div class='ja-card'>";
        $html .= "<table class='ja-table'>";
        $html .= "<thead><tr><th>Theme</th><th></th></tr></thead><tbody>";

        foreach ($themes as $t_dir) {
            $id     = basename($t_dir);
            $active = ($id === $active_theme);
            $info   = self::manifest($id);
            $h      = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
            $html  .= "<tr><td><strong>" . $h($info['name']) . "</strong>";
            if ($info['version'] !== '') $html .= " <span style='font-size:12px;color:#888;margin-left:6px;'>v" . $h($info['version']) . "</span>";
            $html  .= $active ? " <span style='font-size:12px;color:#2e7d32;margin-left:6px;'>active</span>" : "";
            $sub = [];
            if ($info['name'] !== $id)       $sub[] = $h($id);
            if ($info['author'] !== '')      $sub[] = 'by ' . $h($info['author']);
            if ($info['description'] !== '') $sub[] = $h($info['description']);
            if ($sub) $html .= "<div style='font-size:12px;color:#888;margin-top:2px;'>" . implode(' · ', $sub) . "</div>";
            if (\JA\Core\Theme::schema($id)) {
                $html .= "<div style='margin-top:8px;'><a href='?view=themes&customize=" . urlencode($id) . "' class='action-enable' style='display:inline-block;'>Customize</a></div>";
            }
            $html  .= "</td><td class='ja-table-actions'>";
            if ($active) {
                $html .= "<span class='action-locked'>Active</span>";
            } else {
                $html .= \JA\Core\AdminUI::postButton('Activate', 'theme_activate', ['id' => $id], $csrf, 'action-enable');
                $html .= \JA\Core\AdminUI::postButton('Delete', 'theme_delete', ['id' => $id], $csrf, 'action-delete', "Delete theme {$id}? This cannot be undone.");
            }
            $html .= "</td></tr>";
        }

        $html .= "</tbody></table></div>";
        return $html;
    }

    private static function renderCustomize(string $csrf, string $theme_id): string {
        $h      = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
        $info   = self::manifest($theme_id);
        $schema = \JA\Core\Theme::schema($theme_id);

        $html  = "<p style='margin:0 0 8px;'><a href='?view=themes' style='font-size:13px;color:#666;'>&larr; Back to themes</a></p>";
        $html .= "<h1 class='ja-page-header'>Customize " . $h($info['name']) . "</h1>";

        if (!$schema) {
            return $html . "<div class='ja-card'><p style='color:#888;margin:0;'>This theme has no options.</p></div>";
        }

        $html .= "<form method='POST' class='ja-card'>";
        $html .= "<input type='hidden' name='csrf' value='" . $h($csrf) . "'>";
        $html .= "<input type='hidden' name='ja_action' value='save_theme_options'>";
        $html .= "<input type='hidden' name='theme_id' value='" . $h($theme_id) . "'>";

        foreach ($schema as $key => $def) {
            $name  = 'opt_' . $key;
            $value = \JA\Core\Theme::option($key, '', $theme_id);
            $label = $h($def['label']);

            if ($def['type'] === 'checkbox') {
                $html .= "<input type='hidden' name='{$name}' value='0'>";
                $html .= "<label style='display:flex;align-items:center;gap:10px;font-size:14px;cursor:pointer;'>";
                $html .= "<input type='checkbox' name='{$name}' value='1'" . ($value === '1' ? ' checked' : '') . " style='width:auto;margin:0;'> {$label}</label>";
            } else {
                $html .= "<label class='ja-label'>{$label}</label>";
                if ($def['type'] === 'textarea') {
                    $html .= "<textarea name='{$name}' class='ja-textarea'>" . $h($value) . "</textarea>";
                } elseif ($def['type'] === 'select') {
                    $html .= "<select name='{$name}' class='ja-input' style='max-width:260px;'>";
                    foreach ($def['choices'] as $choice => $choice_label) {
                        $html .= "<option value='" . $h($choice) . "'" . ((string) $choice === $value ? ' selected' : '') . ">" . $h($choice_label) . "</option>";
                    }
                    $html .= "</select>";
                } elseif ($def['type'] === 'color') {
                    $html .= "<input type='color' name='{$name}' value='" . $h($value) . "' style='width:64px;height:38px;padding:2px;'>";
                } elseif ($def['type'] === 'number') {
                    $min = $def['min'] !== null ? " min='" . $h($def['min']) . "'" : '';
                    $max = $def['max'] !== null ? " max='" . $h($def['max']) . "'" : '';
                    $html .= "<input type='number' step='any' name='{$name}' value='" . $h($value) . "'{$min}{$max} class='ja-input' style='max-width:160px;'>";
                    if ($def['unit'] !== '') $html .= " <span style='color:#888;font-size:13px;'>" . $h($def['unit']) . "</span>";
                } else {
                    $html .= "<input type='text' name='{$name}' value='" . $h($value) . "' class='ja-input'>";
                }
            }
            $help = $def['help'] !== '' ? $h($def['help']) : '';
            $html .= "<p style='font-size:12px;color:#888;margin:4px 0 16px;'>{$help}</p>";
        }

        $html .= "<button type='submit' class='ja-btn ja-btn-primary'>Save options</button></form>";
        return $html;
    }

    /** POST handler for the Customize form. Returns the message to show. */
    public static function handleSave($db, $post) {
        if (($post['ja_action'] ?? '') !== 'save_theme_options') return false;

        $theme_id = is_string($post['theme_id'] ?? null) ? basename($post['theme_id']) : '';
        if (!preg_match('/^[a-z0-9]+(-[a-z0-9]+)*$/', $theme_id) || !is_dir(JA_ROOT . '/ja-themes/' . $theme_id)) return false;

        \JA\Core\Theme::saveOptions($theme_id, $post);
        return '✅ Theme options saved!';
    }

    /**
     * Reads the optional theme.json. Falls back to the folder name when it's missing or invalid.
     * @return array{name:string, version:string, description:string, author:string}
     */
    public static function manifest(string $theme_id): array {
        $info = ['name' => $theme_id, 'version' => '', 'description' => '', 'author' => ''];
        $file = JA_ROOT . '/ja-themes/' . basename($theme_id) . '/theme.json';
        if (is_file($file)) {
            $data = json_decode((string) file_get_contents($file), true);
            if (is_array($data)) {
                foreach ($info as $key => $_) {
                    if (isset($data[$key]) && is_string($data[$key]) && $data[$key] !== '') {
                        $info[$key] = $data[$key];
                    }
                }
            }
        }
        return $info;
    }

    /**
     * @return array{ok:bool, message:string}
     */
    public static function handleInstall($zip_file) {
        $result = \JA\Core\Package::install(
            $zip_file,
            JA_ROOT . '/ja-themes',
            fn($id) => 'index.php',
            ['default'],
            ['style.css']
        );

        if (!$result['ok']) {
            return ['ok' => false, 'message' => '❌ Theme install failed: ' . htmlspecialchars($result['message'], ENT_QUOTES, 'UTF-8')];
        }
        return ['ok' => true, 'message' => '✅ Theme installed!'];
    }

    public static function handleDelete($db, $theme_id) {
        $theme_id     = basename((string) $theme_id);
        $active_theme = \JA\Core\Options::get('active_theme', 'default');
        if ($theme_id === $active_theme || $theme_id === 'default') return false;

        $target = JA_ROOT . '/ja-themes/' . $theme_id;
        if (!is_dir($target)) return false;

        // Package::removeDir refuses anything that isn't inside ja-themes/
        return \JA\Core\Package::removeDir($target, JA_ROOT . '/ja-themes');
    }

    public static function handleActivate($db, $theme) {
        $theme = basename((string) $theme);
        if (!preg_match('/^[a-z0-9]+(-[a-z0-9]+)*$/', $theme)) return false;
        if (!is_file(JA_ROOT . '/ja-themes/' . $theme . '/index.php')) return false;

        // Options::set inserts the row if it's missing (a bare UPDATE silently does nothing)
        \JA\Core\Options::set('active_theme', $theme);
        return true;
    }
}
