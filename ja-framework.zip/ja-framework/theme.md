# JA Framework — Theme Development Guide

JA themes dictate the public-facing visual wrapper of the CMS. The layout architecture separates structural presentation completely from the database content, loading styles and template components on a per-request execution loop.

---

## 1. Directory Structure

Themes must live inside the `ja-themes/` root folder. Every theme needs a unique folder ID (lowercase letters, numbers and hyphens). Zip installs are rejected unless the folder contains `index.php` and `style.css`:

```text
ja-themes/<theme-id>/
  theme.json    Recommended — Name, version, description, author (shown in Themes; falls back to the folder name)
  index.php     Required — Master template frame and markup entry point
  style.css     Required — Global layout presentation rulesheet
```

### Manifest File (`theme.json`)
The Themes screen reads this file to show the theme's name, version, author and description. Every field is optional:

```json
{
    "name": "Custom Theme Name",
    "version": "1.0.0",
    "description": "A refined, corporate editorial layout built for high-contrast presentation.",
    "author": "Your Name"
}
```

---

## 2. The Core Template (`index.php`)

The `index.php` template acts as the physical skeleton. It executes inside the global runtime loop, meaning it has immediate access to core CMS options registers and layout array vectors.

### Global Variable Payload
Before rendering markup, extract current system states cleanly from the core namespace engines:

```php
<?php
use JA\Core\Options;
use JA\Core\Hooks;
use JA\Core\SiteMenus;
use JA\Core\Shortcodes;
use JA\Core\Router;

// Retrieve operational configuration parameters from options registries
$site_name = Options::get('site_name', 'My Site');
$site_lang = Options::get('site_lang', 'en');
$slogan    = Options::get('site_slogan', '');
$logo      = Options::get('site_logo', '');
$favicon   = Options::get('site_favicon', '');

// Fetch structural menu navigation arrays
$primary_nav = SiteMenus::get('primary');
$footer_nav  = SiteMenus::get('footer');

// Run the page_title / page_content filters (plugins can modify them). This does NOT escape
// anything — still use htmlspecialchars() on titles and other plain text, as the markup below does.
$page_title   = Hooks::apply('page_title',   $ja_page['title']   ?? '');
$page_content = Hooks::apply('page_content', $ja_page['content'] ?? '');

// Pages can opt out of showing their title (Pages → Options → "Hide the page title").
// Only hide the visible heading — keep $page_title in the <title> tag.
$show_title = empty($ja_page['hide_title']);

// Evaluate active request path (e.g., check if current viewing track is home root)
$is_home = (Router::path() === '/');
?>
```

### Essential Structural Hooks
A professional theme must never hardcode static application tracks or leak styles into the content loop. It must fire specific lifecycle hooks to allow background plugins to stream tracking codes, analytics script tags, or asset injections cleanly:

*   `Hooks::fire('head');` — Must be placed immediately before the closing `</head>` tag.
*   `Hooks::fire('body_start');` — Must be placed immediately after the opening `<body>` tag.
*   `Hooks::fire('content_before', $ja_page);` — Fires right before the page heading renders.
*   `Hooks::fire('content_after', $ja_page);` — Fires right after the rendered shortcode content.
*   `Hooks::fire('body_end');` — Must be placed immediately before the closing `</body>` tag.

The `head` and `body_end` hooks are also how plugin CSS/JS queued with `Assets::style()` / `Assets::script()` reaches the page, so a theme that skips them will silently lose plugin assets.

### Parsing Content Packages
The raw page database content string must be processed through the shortcode engine right inside your theme's main text block wrapper. Failing to do this will cause shortcode codes to show up as raw bracket text:

```php
<div class="ja-content">
    <?= Shortcodes::render($page_content) ?>
</div>
```

---

## 3. Dynamic Asset Routing

To prevent broken background links and unstylized layouts when moving code between development local hosts and live domains, never hardcode local folder paths inside your `<link>` blocks. Use the global framework base URL alongside an automated directory lookup hook:

```php
<!-- Dynamic theme directory alignment fix -->
<link rel="stylesheet" href="<?= JA_BASE_URL ?>/ja-themes/<?= basename(__DIR__) ?>/style.css">
```

---

## 4. Professional Presentation Rules (`style.css`)

To prevent default web browser style overrides (like unstylized bright blue link blocks or default underlines) from hijacking the corporate look of your site headings and navigation links, your stylesheet must apply a global reset strategy.

### Crucial Global Overrides
Always reset default hyperlink anchor vectors inside your `style.css` so they naturally inherit your application’s look:

```css
/* --- Global Link Structure Reset --- */
a {
    color: inherit;         /* Forces anchors to inherit their parent container text color */
    text-decoration: none;  /* Eliminates default browser underlines universally */
    transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out;
}

/* --- Keep Content Paragraph Formats Readable --- */
.ja-content {
    font-size: 16px;
    line-height: 1.7;
}

.ja-content p {
    margin-bottom: 1.5em; /* Controls structural spacing without code breaking */
}

/* --- Ensure Media Scaling Safety --- */
.ja-content img, 
.ja-content iframe {
    max-width: 100%;
    height: auto;
    display: block;
}
```

---

## 5. Summary Checklist for Theme Developers
1. **Never use `Router` or other core tools without namespaces.** Always declare `use JA\Core\Router;` at the top of `index.php` to prevent fatal class lookup crashes.
2. **Never hardcode primary menu entries.** Always loop through the dynamic `$primary_nav` array using `foreach`.
3. **Respect `$show_title`.** Wrap the visible page heading in `if ($show_title)` so pages can hide it. Leave the `<title>` tag alone.
4. **Never allow links to fall back to browser defaults.** Ensure `color: inherit;` is locked down globally in your stylesheet.
