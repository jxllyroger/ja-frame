# JA Framework — Theme Development Guide

> Part of the JA Framework documentation. Start with `README.md` for the CMS itself.

A theme controls how the public site looks. It receives the current page and the site's settings, and
returns HTML. Everything else (pages, menus, plugins, settings) lives outside the theme.

The framework ships one theme, `default`, which is also the fallback: if the active theme is missing, the
site uses `default`; if that is missing too, it shows a plain "No theme found" message. Use `default` as a
starting point — it is small and follows every rule below.

---

## 1. Folder layout

Themes live in `ja-themes/<theme-id>/`. The id uses lowercase letters, numbers and hyphens.

```text
ja-themes/my-theme/
  index.php     required — the template
  style.css     required — the stylesheet
  theme.json    recommended — name, version, description, author, options
```

Zip installs (Themes screen) are rejected unless the zip holds exactly one folder containing `index.php`
and `style.css`. They are also rejected if the folder already exists or is the protected `default` theme.
The active theme and `default` cannot be deleted.

### `theme.json`

Every field is optional. Without the file the Themes screen shows the folder name.

```json
{
    "name": "My Theme",
    "version": "1.0.0",
    "description": "A short description.",
    "author": "Your Name",
    "options": { }
}
```

`options` is covered in section 6.

---

## 2. The template (`index.php`)

The template runs inside the front controller, so it can use the core classes directly. Declare the ones
you use with `use`. The page to render is in `$ja_page`.

```php
<?php
use JA\Core\Options;
use JA\Core\Hooks;
use JA\Core\SiteMenus;
use JA\Core\Shortcodes;

$site_name = Options::get('site_name', 'My Site');
$site_lang = Options::get('site_lang', 'en');
$slogan    = Options::get('site_slogan', '');
$logo      = Options::get('site_logo', '');      // a file name in /uploads
$favicon   = Options::get('site_favicon', '');   // a file name in /uploads

$primary_nav = SiteMenus::get('primary');        // array of ['label' => …, 'url' => …], or null
$footer_nav  = SiteMenus::get('footer');

// Plugins can change the title and content through these filters.
// They do NOT escape anything — use htmlspecialchars() on plain text yourself.
$page_title   = Hooks::apply('page_title',   $ja_page['title']   ?? '');
$page_content = Hooks::apply('page_content', $ja_page['content'] ?? '');

// A page can opt out of showing its title (Pages → Options → "Hide the page title")
$show_title = empty($ja_page['hide_title']);
?>
```

### `$ja_page`

An array describing the page being shown. For a normal page it is the database row (`title`, `slug`,
`content`, `is_home`, `hide_title`, …). A plugin route can supply its own (`title`, `content`, …).
Always read keys with `??` so a missing one never causes a notice.

### Menus

`SiteMenus::get('primary')` and `SiteMenus::get('footer')` return the items assigned to those locations in
the Menus screen, or `null` when nothing is assigned, the menu is disabled or empty. Loop over the result;
never hardcode menu links.

```php
<?php if ($primary_nav): ?>
    <nav>
        <?php foreach ($primary_nav as $item): ?>
            <a href="<?= htmlspecialchars($item['url']) ?>"><?= htmlspecialchars($item['label']) ?></a>
        <?php endforeach; ?>
    </nav>
<?php endif; ?>
```

### Page title and content

```php
<?php Hooks::fire('content_before', $ja_page); ?>
<?php if ($show_title): ?>
    <h2><?= htmlspecialchars($page_title) ?></h2>
<?php endif; ?>
<div class="ja-content"><?= Shortcodes::render($page_content) ?></div>
<?php Hooks::fire('content_after', $ja_page); ?>
```

- Only hide the **visible heading** when `$show_title` is false. Keep `$page_title` in the `<title>` tag.
- Run content through `Shortcodes::render()`, or `[shortcodes]` will show up as plain text.
- Wrap the content in an element with the class **`ja-content`** (see section 5).

### Required hooks

A theme must fire these so plugins can add code to the page. Place them exactly here:

| Call | Where |
|---|---|
| `Hooks::fire('head');` | just before `</head>` |
| `Hooks::fire('body_start');` | just after `<body>` |
| `Hooks::fire('content_before', $ja_page);` | just before the page heading |
| `Hooks::fire('content_after', $ja_page);` | just after the page content |
| `Hooks::fire('body_end');` | just before `</body>` |

`head` and `body_end` also deliver plugin CSS/JS (queued with `Assets`), the shared content stylesheet and
the theme's option variables. A theme that skips them silently loses all of that.

---

## 3. Stylesheet link

Never hardcode the theme folder. Link by the folder's own name so the theme keeps working if it is renamed:

```php
<link rel="stylesheet" href="<?= JA_BASE_URL ?>/ja-themes/<?= basename(__DIR__) ?>/style.css">
```

Add `<meta name="viewport" content="width=device-width, initial-scale=1.0">` in the `<head>`.

---

## 4. Writing the CSS

- Reset links so they follow your design instead of the browser's blue underline:

  ```css
  a { color: inherit; text-decoration: none; }
  ```
- Style the content area (`.ja-content`): paragraph spacing, headings, links, blockquotes, lists, tables, code.
  Pages can contain any of these. On a dark theme, check links and tables are readable.
- **Be responsive.** Use `max-width` instead of fixed widths, let flex and grid children shrink
  (`min-width: 0`), and add `@media` rules for phones. Test at roughly 360, 768, 1100 and 1600 px wide.
  Many visitors are on phones, and page content such as landing pages adapts to the width on its own,
  so a theme that does not will squeeze or break it.

---

## 5. Shared content baseline

The framework loads `ja-themes/content-base.css` for every theme. It stops page content from breaking the
layout: images and video stay inside their container, long unbroken words and URLs wrap, and wide tables
and code blocks scroll sideways instead of widening the page.

It applies to anything inside an element with the class `ja-content`, and it has zero specificity, so any
rule in your own `style.css` overrides it. You do not need to repeat those rules.

---

## 6. Theme options (Themes → Customize)

Add an `options` block to `theme.json` and admins get a **Customize** form for the theme.

```json
"options": {
    "content_width": { "label": "Content width", "type": "number", "default": "900", "unit": "px", "min": 600, "max": 1600 },
    "accent":        { "label": "Accent colour", "type": "color",    "default": "#2563eb" },
    "show_banner":   { "label": "Show banner",   "type": "checkbox", "default": "1" },
    "footer_text":   { "label": "Footer text",   "type": "text",     "default": "Hello", "help": "Shown at the bottom of every page." },
    "layout":        { "label": "Layout",        "type": "select",   "default": "wide", "choices": { "wide": "Wide", "narrow": "Narrow" } }
}
```

| Type | Notes |
|---|---|
| `text`, `textarea` | free text |
| `checkbox` | stored as `1` or `0` |
| `color` | a `#rrggbb` value |
| `number` | optional `unit` (appended in CSS), `min`, `max` |
| `select` | needs `choices` as `{ "value": "Label" }` |

Option keys use lowercase letters, numbers and underscores. `label`, `default` and `help` are optional.
Every submitted value is validated against its type before it is saved.

**In a template**

```php
use JA\Core\Theme;

Theme::option('footer_text');       // the saved value, or the default from theme.json
Theme::enabled('show_banner');      // true when a checkbox is on
```

**In CSS** — `color` and `number` options become variables on `:root`, named after the key with hyphens
(`content_width` → `--content-width`). A number gets its `unit` appended. Always give a fallback:

```css
.container { max-width: var(--content-width, 900px); }
a:hover    { color: var(--accent, #2563eb); }
```

Options are stored per theme, so switching themes never mixes settings up.

---

## 7. Checklist

1. Fire all five hooks, in the places listed in section 2.
2. Escape every plain-text value with `htmlspecialchars()`.
3. Loop over `SiteMenus::get()`; never hardcode menu links.
4. Wrap page content in `.ja-content` and pass it through `Shortcodes::render()`.
5. Respect `$show_title` for the visible heading only.
6. Link the stylesheet with `basename(__DIR__)`, and include the viewport meta tag.
7. Include a `style.css`, reset link colours, and check the theme at phone width.
8. Add a `theme.json`, and options for anything an owner would reasonably want to change.
