# Options cache (optional)

> Part of the JA Framework documentation. Start with `README.md` for the CMS itself.

The framework ships **no cache** (see `README.md` for how a request normally works). By default every page view reads the options table from MySQL — one
query — and that is enough for most sites.

If you want a cache, install a driver plugin. A **Redis Cache** plugin is available separately
(`rediscache.zip`); it is not part of the framework download.

## Using Redis Cache

1. Upload `rediscache/` into `ja-plugins/` (or install the zip on the Plugins screen).
2. Enable it. It installs `ja-content/options-cache.php`; if it can't, it tells you what to fix
   (usually: make a `ja-content/` folder the web server can write to).
3. Open **Redis Cache** in the admin menu, enter the server details, choose a **database (0 to 15)**,
   and click *Save and apply*.

Disabling the plugin removes the driver file and the site goes straight back to MySQL.

## What is and isn't cached

- **Cached:** the options table, on the public site only.
- **Never cached:** the admin panel (`ja-admin/`), the login page and the command line. They read MySQL
  directly, so a settings screen can never show a stale value.
- **Invalidation:** every `Options::set()` invalidates the cache and fires the `options_update` hook.
  Editing `ja_options` by hand (phpMyAdmin) does not — use *Flush* on the plugin screen, or wait for the TTL.
- **Failure is harmless:** with no PHP `redis` extension, a stopped server or a wrong password the site
  simply runs uncached (and pauses retrying for 30 seconds so pages don't wait on timeouts).

## Writing your own driver

Implement `JA\Core\OptionsBackend` (`fetch`, `store`, `forget`) and register it from
`ja-content/options-cache.php`, which the core loads at startup before options are read:

```php
\JA\Core\Options::useBackend(new MyBackend());
```

Because it runs before any option can be read, a driver must keep its own settings in a file, not in
`ja_options`. If you change `ja_options` with raw SQL, call `Options::forgetCache()` afterwards.
A new entry script that must never use the cache should `define('JA_BYPASS_CACHE', true);` before
requiring `ja-core/autoload.php`.
