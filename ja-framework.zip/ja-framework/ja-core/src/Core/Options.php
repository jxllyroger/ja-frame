<?php
namespace JA\Core;

class Options {
    private static $cache = null;

    /**
     * Load all options from DB into cache in one query.
     * Called once by config.php — after this, all gets are memory-only.
     */
    public static function load() {
        if (self::$cache === null) {
            $db         = Database::getConnection();
            self::$cache = $db->query("SELECT option_name, option_value FROM ja_options")
                              ->fetchAll(\PDO::FETCH_KEY_PAIR);
        }
    }

    public static function get($name, $default = null) {
        if (self::$cache === null) self::load();
        return self::$cache[$name] ?? $default;
    }

    public static function set($name, $value) {
        if (self::$cache === null) self::load();
        $db   = Database::getConnection();
        $stmt = $db->prepare(
            "INSERT INTO ja_options (option_name, option_value) VALUES (?, ?)
             ON DUPLICATE KEY UPDATE option_value = ?"
        );
        $stmt->execute([$name, $value, $value]);
        self::$cache[$name] = $value;
    }
}
