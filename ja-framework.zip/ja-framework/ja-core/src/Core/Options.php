<?php
namespace JA\Core;

class Options {
    private static $cache = null;
    private static bool $bypass = false;
    private static ?OptionsBackend $backend = null;

    /**
     * Register an options cache driver (see OptionsBackend). Called by ja-content/options-cache.php.
     * With no driver registered — the default — options are simply read from MySQL.
     */
    public static function useBackend(OptionsBackend $backend): void {
        self::$backend = $backend;
    }

    public static function backend(): ?OptionsBackend {
        return self::$backend;
    }

    /** Invalidate the driver's cached copy. Use after changing ja_options with raw SQL. */
    public static function forgetCache(): void {
        if (self::$backend === null) return;
        try {
            self::$backend->forget();
        } catch (\Throwable $e) {
            error_log('JA options cache: ' . $e->getMessage());
        }
    }

    /**
     * Make this request read options straight from MySQL and never use the cache driver.
     * Called for the admin panel, login and the command line (see config.php).
     * Writes still invalidate the cache so the public site never serves old options.
     */
    public static function bypassCache(bool $on = true): void {
        self::$bypass = $on;
    }

    /**
     * Load all options into memory in one go.
     * Called once by config.php — after this, all gets are memory-only.
     * Order: cache driver (public site only, if one is installed) → MySQL.
     */
    public static function load() {
        if (self::$cache !== null) return;

        if (!self::$bypass && self::$backend !== null) {
            try {
                $cached = self::$backend->fetch();
                if (is_array($cached)) {
                    self::$cache = $cached;
                    return;
                }
            } catch (\Throwable $e) {
                error_log('JA options cache: ' . $e->getMessage());
            }
        }

        $db          = Database::getConnection();
        self::$cache = $db->query("SELECT option_name, option_value FROM ja_options")
                          ->fetchAll(\PDO::FETCH_KEY_PAIR);

        if (!self::$bypass && self::$backend !== null) {
            try {
                self::$backend->store(self::$cache);
            } catch (\Throwable $e) {
                error_log('JA options cache: ' . $e->getMessage());
            }
        }
    }

    public static function get($name, $default = null) {
        if (self::$cache === null) self::load();
        return self::$cache[$name] ?? $default;
    }

    public static function set($name, $value) {
        if (self::$cache === null) self::load();
        $db   = Database::getConnection();
        $stmt = $db->prepare(
            "INSERT INTO ja_options (option_name, option_value) VALUES (?, ?)
             ON DUPLICATE KEY UPDATE option_value = ?"
        );
        $stmt->execute([$name, $value, $value]);
        self::$cache[$name] = $value;

        // Always — even from the admin — so a driver's cached copy is never stale
        self::forgetCache();
        Hooks::fire('options_update', $name, $value);
    }
}
