<?php
namespace JA\Core;

class Auth {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    /**
     * Check if an email is on the admin allowlist in ja_options.
     * The option 'admin_emails' is a JSON array of allowed addresses.
     */
    private function isAllowed($email) {
        $raw      = Options::get('admin_emails', '');
        $allowed  = json_decode($raw, true);

        // If no allowlist is configured yet, fall back to site owner email
        if (empty($allowed) || !is_array($allowed)) {
            $owner = Options::get('admin_email', '');
            return $owner && strtolower($email) === strtolower($owner);
        }

        return in_array(strtolower($email), array_map('strtolower', $allowed));
    }

    public function generateLink($email) {
        if (!$this->isAllowed($email)) return null;

        // Only a hash is stored, so a copy of the database can't be used to sign in.
        // Expiry is computed by MySQL itself, so it can't disagree with the clock that checks it
        // (PHP's timezone setting and MySQL's can differ).
        $token = bin2hex(random_bytes(32));
        $ttl   = defined('JA_LINK_TTL') ? (int) JA_LINK_TTL : 900;
        $stmt  = $this->db->prepare('INSERT INTO ja_auth_tokens (email, token, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL ? SECOND))');
        $stmt->execute([$email, hash('sha256', $token), $ttl]);
        return JA_BASE_URL . '/ja-login.php?token=' . $token;
    }

    public function validateToken($token) {
        if (!is_string($token) || !preg_match('/^[a-f0-9]{64}$/D', $token)) return false;
        $token = hash('sha256', $token);

        // InnoDB row lock prevents race condition on concurrent requests
        $this->db->beginTransaction();
        $stmt = $this->db->prepare(
            "SELECT * FROM ja_auth_tokens WHERE token = ? AND expires_at > NOW() AND used = 0 FOR UPDATE"
        );
        $stmt->execute([$token]);
        $result = $stmt->fetch();

        if ($result) {
            $update = $this->db->prepare("UPDATE ja_auth_tokens SET used = 1, used_at = NOW() WHERE id = ?");
            $update->execute([$result['id']]);
            $this->db->commit();
        } else {
            $this->db->rollBack();
        }

        return $result;
    }
}
