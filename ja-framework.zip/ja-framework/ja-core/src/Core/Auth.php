<?php
namespace JA\Core;

class Auth {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    /**
     * Check if an email is on the admin allowlist in ja_options.
     * The option 'admin_emails' is a JSON array of allowed addresses.
     */
    private function isAllowed($email) {
        $raw      = Options::get('admin_emails', '');
        $allowed  = json_decode($raw, true);

        // If no allowlist is configured yet, fall back to site owner email
        if (empty($allowed) || !is_array($allowed)) {
            $owner = Options::get('admin_email', '');
            return $owner && strtolower($email) === strtolower($owner);
        }

        return in_array(strtolower($email), array_map('strtolower', $allowed));
    }

    public function generateLink($email) {
        if (!$this->isAllowed($email)) return null;

        $token   = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', strtotime('+15 minutes'));
        $stmt    = $this->db->prepare('INSERT INTO ja_auth_tokens (email, token, expires_at) VALUES (?, ?, ?)');
        $stmt->execute([$email, $token, $expires]);
        return JA_BASE_URL . '/ja-login.php?token=' . $token;
    }

    public function validateToken($token) {
        // InnoDB row lock prevents race condition on concurrent requests
        $this->db->beginTransaction();
        $stmt = $this->db->prepare(
            "SELECT * FROM ja_auth_tokens WHERE token = ? AND expires_at > NOW() AND used = 0 FOR UPDATE"
        );
        $stmt->execute([$token]);
        $result = $stmt->fetch();

        if ($result) {
            $update = $this->db->prepare("UPDATE ja_auth_tokens SET used = 1, used_at = NOW() WHERE id = ?");
            $update->execute([$result['id']]);
            $this->db->commit();
        } else {
            $this->db->rollBack();
        }

        return $result;
    }
}
