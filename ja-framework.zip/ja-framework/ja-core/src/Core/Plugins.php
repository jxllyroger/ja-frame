<?php
namespace JA\Core;

class Plugins {
    private static $required = ['ja-media', 'ja-settings', 'ja-themes', 'ja-plugins', 'ja-menus'];

    public static function loadActive() {
        $core_map = [
            'Media'    => 'ja-media',
            'Settings' => 'ja-settings',
            'Themes'   => 'ja-themes',
            'Plugins'  => 'ja-plugins',
            'Menus'    => 'ja-menus',
        ];

        foreach ($core_map as $class => $folder) {
            $file = JA_ROOT . "/ja-plugins/$folder/$folder.php";
            if (file_exists($file)) {
                require_once $file;
                $full_class = "JA\\Plugins\\$class";
                if (method_exists($full_class, 'init')) { $full_class::init(); }
            }
        }

        self::loadUserPlugins();
    }

    public static function loadFrontend() {
        self::loadUserPlugins();
    }

    private static function loadUserPlugins() {
        $active_setting = Options::get('active_plugins', '[]');
        $enabled_list   = json_decode($active_setting, true);
        if (!is_array($enabled_list)) $enabled_list = [];

        foreach ($enabled_list as $id) {
            if (in_array($id, self::$required)) continue;

            $file = JA_ROOT . "/ja-plugins/$id/$id.php";
            if (file_exists($file)) {
                require_once $file;
                $clean_name = str_replace('ja-', '', $id);
                $class_name = "JA\\Plugins\\" . ucfirst($clean_name);
                if (class_exists($class_name) && method_exists($class_name, 'init')) {
                    $class_name::init();
                }
            }
        }
    }

    public static function isRequired($plugin_id) {
        return in_array($plugin_id, self::$required);
    }

    public static function toggle($plugin_id) {
        if (self::isRequired($plugin_id)) return;
        $active = json_decode(Options::get('active_plugins', '[]'), true) ?: [];

        if (in_array($plugin_id, $active)) {
            $active = array_diff($active, [$plugin_id]);
        } else {
            $active[] = $plugin_id;
        }
        Options::set('active_plugins', json_encode(array_values($active)));
    }
}
