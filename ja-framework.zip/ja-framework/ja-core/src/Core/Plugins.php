<?php
namespace JA\Core;

/**
 * JA Framework — Plugin loader and lifecycle.
 *
 * Plugin layout:   ja-plugins/<id>/<id>.php   (+ optional plugin.json)
 * Plugin class:    JA\Plugins\<StudlyName>    (ja-my-plugin → MyPlugin, ja-pages → Pages)
 *
 * Optional static methods on the class:
 *   init()                    runs on every request while the plugin is enabled
 *   onActivate($db)           runs when enabled; throw to abort enabling
 *   onDeactivate($db)         runs when disabled
 *   onUninstall($db)          runs just before the plugin folder is deleted
 *   renderAdmin($db, $csrf)   admin screen for ?view=<slug>
 *   handleSave($db, $post)    handles POSTs from that screen
 *   bootFrontend($db)         can be chosen as the homepage plugin in Settings
 */
class Plugins {
    /** The single source of truth for core plugins. They cannot be disabled or replaced. */
    private static array $required = ['ja-media', 'ja-settings', 'ja-themes', 'ja-plugins', 'ja-menus'];

    // ---------------------------------------------------------------
    // Identity helpers
    // ---------------------------------------------------------------

    public static function required(): array {
        return self::$required;
    }

    public static function isRequired($plugin_id): bool {
        return in_array($plugin_id, self::$required, true);
    }

    /** Lowercase letters, numbers and hyphens only — also blocks path tricks like "../x". */
    public static function isValidId($plugin_id): bool {
        return is_string($plugin_id) && preg_match('/^[a-z0-9]+(-[a-z0-9]+)*$/', $plugin_id) === 1;
    }

    /** ja-my-plugin → MyPlugin, ja-pages → Pages, roster → Roster */
    public static function className(string $plugin_id): string {
        $name = preg_replace('/^ja-/', '', $plugin_id);
        return str_replace(' ', '', ucwords(str_replace('-', ' ', $name)));
    }

    public static function fqcn(string $plugin_id): string {
        return 'JA\\Plugins\\' . self::className($plugin_id);
    }

    public static function mainFile(string $plugin_id): string {
        return JA_ROOT . "/ja-plugins/$plugin_id/$plugin_id.php";
    }

    // ---------------------------------------------------------------
    // Active list
    // ---------------------------------------------------------------

    public static function activeList(): array {
        $list = json_decode(Options::get('active_plugins', '[]'), true);
        if (!is_array($list)) return [];
        return array_values(array_filter($list, 'is_string'));
    }

    public static function isActive($plugin_id): bool {
        if (self::isRequired($plugin_id)) return true;
        return is_string($plugin_id) && in_array($plugin_id, self::activeList(), true);
    }

    private static function saveActive(array $list): void {
        Options::set('active_plugins', json_encode(array_values(array_unique($list))));
    }

    /**
     * Drop enabled plugins whose folder no longer exists. Returns the cleaned list.
     */
    public static function pruneMissing(): array {
        $active = self::activeList();
        $kept   = array_values(array_filter($active, fn($id) => self::isValidId($id) && is_file(self::mainFile($id))));
        if ($kept !== $active) self::saveActive($kept);
        return $kept;
    }

    // ---------------------------------------------------------------
    // Manifest (optional plugin.json)
    // ---------------------------------------------------------------

    /**
     * @return array{name:string, version:string, description:string, author:string}
     */
    public static function manifest(string $plugin_id): array {
        $info = ['name' => $plugin_id, 'version' => '', 'description' => '', 'author' => ''];
        $file = JA_ROOT . "/ja-plugins/$plugin_id/plugin.json";
        if (is_file($file)) {
            $data = json_decode((string) file_get_contents($file), true);
            if (is_array($data)) {
                foreach ($info as $key => $_) {
                    if (isset($data[$key]) && is_string($data[$key]) && $data[$key] !== '') {
                        $info[$key] = $data[$key];
                    }
                }
            }
        }
        return $info;
    }

    // ---------------------------------------------------------------
    // Loading
    // ---------------------------------------------------------------

    /** Admin: core plugins first, then every enabled user plugin. */
    public static function loadActive() {
        foreach (self::$required as $id) {
            self::boot($id);
        }
        self::loadUserPlugins();
    }

    /** Front end: enabled user plugins only. */
    public static function loadFrontend() {
        self::loadUserPlugins();
    }

    private static function loadUserPlugins(): void {
        foreach (self::activeList() as $id) {
            if (self::isRequired($id) || !self::isValidId($id)) continue;
            self::boot($id);
        }
    }

    /**
     * Load one plugin and run init(). A plugin that throws is skipped (and logged)
     * instead of taking the whole site — and the admin screen needed to disable it — down.
     */
    private static function boot(string $plugin_id): bool {
        $file = self::mainFile($plugin_id);
        if (!is_file($file)) return false;

        try {
            require_once $file;
            $class = self::fqcn($plugin_id);
            if (class_exists($class, false) && method_exists($class, 'init')) {
                $class::init();
            }
            return true;
        } catch (\Throwable $e) {
            error_log("JA plugin '{$plugin_id}' failed to load: " . $e->getMessage());
            return false;
        }
    }

    // ---------------------------------------------------------------
    // Lifecycle: enable / disable / uninstall
    // Each returns ['ok' => bool, 'message' => string] ready to show in the admin.
    // ---------------------------------------------------------------

    public static function toggle($plugin_id): array {
        if (!self::isValidId($plugin_id)) return self::result(false, 'Invalid plugin id.');
        if (self::isRequired($plugin_id))  return self::result(false, 'Core plugins cannot be disabled.');

        $active   = self::activeList();
        $enabling = !in_array($plugin_id, $active, true);
        $file     = self::mainFile($plugin_id);
        $class    = self::fqcn($plugin_id);

        if ($enabling) {
            if (!is_file($file)) {
                return self::result(false, "Files for “{$plugin_id}” were not found.");
            }
            try {
                require_once $file;
                if (!class_exists($class, false)) {
                    return self::result(false, self::h("{$plugin_id}.php must define the class {$class}."));
                }
                // Activation runs first: if it throws, the plugin is NOT marked enabled.
                if (method_exists($class, 'onActivate')) {
                    $class::onActivate(Database::getConnection());
                }
            } catch (\Throwable $e) {
                return self::result(false, 'Could not enable plugin: ' . self::h($e->getMessage()));
            }
            $active[] = $plugin_id;
            self::saveActive($active);
            return self::result(true, 'Plugin enabled.');
        }

        // Disabling
        $warning = '';
        if (is_file($file)) {
            try {
                require_once $file;
                if (class_exists($class, false) && method_exists($class, 'onDeactivate')) {
                    $class::onDeactivate(Database::getConnection());
                }
            } catch (\Throwable $e) {
                $warning = ' Its deactivate hook reported: ' . self::h($e->getMessage());
            }
        }
        self::saveActive(array_diff($active, [$plugin_id]));
        self::clearFrontendPlugin($plugin_id);

        return self::result(true, 'Plugin disabled.' . $warning);
    }

    public static function uninstall($plugin_id): array {
        if (!self::isValidId($plugin_id)) return self::result(false, 'Invalid plugin id.');
        if (self::isRequired($plugin_id))  return self::result(false, 'Core plugins cannot be uninstalled.');

        $dir = JA_ROOT . '/ja-plugins/' . $plugin_id;

        // Disable first so deactivate hooks run and the active list stays clean
        if (in_array($plugin_id, self::activeList(), true)) {
            $disabled = self::toggle($plugin_id);
            if (!$disabled['ok']) return $disabled;
        }

        if (!is_dir($dir)) {
            return self::result(true, 'Plugin was already removed.');
        }

        $warning = '';
        $file    = self::mainFile($plugin_id);
        $class   = self::fqcn($plugin_id);
        if (is_file($file)) {
            try {
                require_once $file;
                if (class_exists($class, false) && method_exists($class, 'onUninstall')) {
                    $class::onUninstall(Database::getConnection());
                }
            } catch (\Throwable $e) {
                $warning = ' Its uninstall hook reported: ' . self::h($e->getMessage());
            }
        }

        if (!Package::removeDir($dir, JA_ROOT . '/ja-plugins')) {
            return self::result(false, 'Could not delete the plugin folder — check file permissions.');
        }
        self::clearFrontendPlugin($plugin_id);

        return self::result(true, 'Plugin uninstalled.' . $warning);
    }

    // ---------------------------------------------------------------

    private static function clearFrontendPlugin(string $plugin_id): void {
        if (Options::get('frontend_plugin', '') === $plugin_id) {
            Options::set('frontend_plugin', '');
        }
    }

    private static function result(bool $ok, string $message): array {
        return ['ok' => $ok, 'message' => ($ok ? '✅ ' : '❌ ') . $message];
    }

    private static function h(string $text): string {
        return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    }
}
