<?php
namespace JA\Core;

/**
 * [tag attr="value"] shortcodes in page content.
 *
 *   Shortcodes::register('roster', fn(array $attrs) => '<ul>…</ul>');
 *
 * Themes expand them with Shortcodes::render($html). Unknown tags are left untouched.
 */
class Shortcodes {
    private static array $tags = [];

    public static function register(string $tag, callable $callback): void {
        self::$tags[$tag] = $callback;
    }

    public static function render(string $html): string {
        if (empty(self::$tags) || strpos($html, '[') === false) return $html;

        return preg_replace_callback('/\[(\w+)((?:\s+\w+="[^"]*")*)\s*\]/', function ($m) {
            $tag = $m[1];
            if (!isset(self::$tags[$tag])) return $m[0];

            $attrs = [];
            if (preg_match_all('/(\w+)="([^"]*)"/', $m[2], $all, PREG_SET_ORDER)) {
                foreach ($all as $pair) $attrs[$pair[1]] = $pair[2];
            }
            return (string) call_user_func(self::$tags[$tag], $attrs);
        }, $html);
    }
}
