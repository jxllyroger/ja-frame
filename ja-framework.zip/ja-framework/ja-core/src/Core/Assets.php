<?php
namespace JA\Core;

/**
 * JA Framework — Assets
 *
 * Lets plugins queue CSS/JS instead of echoing inline <style>/<script> blocks.
 * Output is printed by the existing head / body_end (front end) and
 * admin_head / admin_body_end (admin) hooks, so any theme that fires those
 * hooks gets plugin assets automatically.
 *
 *   Assets::style('events-css', Assets::pluginUrl('ja-events', 'events.css'));
 *   Assets::script('events-js', Assets::pluginUrl('ja-events', 'events.js'));
 *   Assets::style('events-admin', $url, 'admin');
 *
 * Re-registering a handle replaces it, so a handle is only ever printed once.
 */
class Assets {
    private static array $queue  = ['front' => ['style' => [], 'script' => []], 'admin' => ['style' => [], 'script' => []]];
    private static bool  $booted = false;

    public static function style(string $handle, string $url, string $context = 'front'): void {
        $context = self::context($context);
        self::$queue[$context]['style'][$handle] = $url;
    }

    public static function script(string $handle, string $url, bool $in_footer = true, string $context = 'front'): void {
        $context = self::context($context);
        self::$queue[$context]['script'][$handle] = ['url' => $url, 'footer' => $in_footer];
    }

    public static function pluginUrl(string $plugin_id, string $path): string {
        $path = ltrim($path, '/');
        $file = JA_ROOT . '/ja-plugins/' . $plugin_id . '/' . $path;
        // ?v=<mtime> makes browsers pick up changed files immediately
        $ver  = is_file($file) ? '?v=' . filemtime($file) : '';
        return JA_BASE_URL . '/ja-plugins/' . rawurlencode($plugin_id) . '/' . $path . $ver;
    }

    /**
     * Hook the printers in. Safe to call more than once.
     */
    public static function boot(): void {
        if (self::$booted) return;
        self::$booted = true;

        Hooks::action('head',           fn() => self::printAssets('front', false, true));
        Hooks::action('body_end',       fn() => self::printAssets('front', true,  false));
        Hooks::action('admin_head',     fn() => self::printAssets('admin', false, true));
        Hooks::action('admin_body_end', fn() => self::printAssets('admin', true,  false));
    }

    private static function printAssets(string $context, bool $footer_scripts, bool $styles): void {
        if ($styles) {
            foreach (self::$queue[$context]['style'] as $url) {
                echo '<link rel="stylesheet" href="' . htmlspecialchars($url, ENT_QUOTES) . '">' . "\n";
            }
        }
        foreach (self::$queue[$context]['script'] as $script) {
            if ($script['footer'] !== $footer_scripts) continue;
            echo '<script src="' . htmlspecialchars($script['url'], ENT_QUOTES) . '"></script>' . "\n";
        }
    }

    private static function context(string $context): string {
        return $context === 'admin' ? 'admin' : 'front';
    }
}
