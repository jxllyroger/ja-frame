<?php
namespace JA\Core;

/**
 * Admin sessions.
 *
 *  - Cookies are HttpOnly, SameSite=Lax, and Secure whenever the site is served over HTTPS.
 *  - The session id is replaced at sign-in (stops session fixation) and the CSRF token is renewed.
 *  - A session that has been idle for 8 hours is ended.
 *  - Signing out clears the session data, destroys the session and expires the cookie.
 *
 * Use Session::start() instead of calling session_start() directly.
 */
class Session {
    /** Seconds without activity before an admin is signed out. */
    private const IDLE_LIMIT = 28800;

    public static function isHttps(): bool {
        return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || (string) ($_SERVER['SERVER_PORT'] ?? '') === '443'
            || strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https';
    }

    public static function start(): void {
        if (session_status() !== PHP_SESSION_NONE || headers_sent()) return;

        // The cookie covers the whole site (the public site needs it for draft previews),
        // but not other applications on the same domain when this site lives in a sub-folder.
        $path = defined('JA_BASE_URL') ? (string) (parse_url(JA_BASE_URL, PHP_URL_PATH) ?? '') : '';
        if ($path === '') $path = '/';

        ini_set('session.use_strict_mode', '1');   // never accept a session id the server didn't issue
        ini_set('session.use_only_cookies', '1');

        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => $path,
            'secure'   => self::isHttps(),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }

    /** Sign someone in: a new session id, a fresh CSRF token. */
    public static function login(string $email): void {
        self::start();
        session_regenerate_id(true);
        $_SESSION['ja_admin'] = $email;
        $_SESSION['ja_last']  = time();
        $_SESSION['csrf']     = bin2hex(random_bytes(32));
    }

    /** True if an admin is signed in and recently active. Ends stale sessions. */
    public static function check(): bool {
        if (empty($_SESSION['ja_admin'])) return false;

        $last = (int) ($_SESSION['ja_last'] ?? 0);   // sessions from before this existed have none
        if ($last > 0 && (time() - $last) > self::IDLE_LIMIT) {
            self::logout();
            return false;
        }
        $_SESSION['ja_last'] = time();
        return true;
    }

    public static function logout(): void {
        self::start();
        $_SESSION = [];

        if (ini_get('session.use_cookies') && !headers_sent()) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', [
                'expires'  => time() - 42000,
                'path'     => $p['path'],
                'domain'   => $p['domain'],
                'secure'   => $p['secure'],
                'httponly' => $p['httponly'],
                'samesite' => $p['samesite'] ?? 'Lax',
            ]);
        }
        if (session_status() === PHP_SESSION_ACTIVE) session_destroy();
    }
}
