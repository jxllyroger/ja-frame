<?php
namespace JA\Core;

/**
 * JA Framework — Router
 *
 * Plugins register front-end routes from init():
 *
 *   Router::add('/events', function (array $params, $db) {
 *       return ['title' => 'Events', 'content' => '<p>…</p>', 'is_html' => true];
 *   });
 *   Router::add('/events/{slug}', [Events::class, 'show']);
 *
 * A handler returns a page array (title, content), which becomes the page the
 * theme renders. Returning null means "handled, I set things up myself".
 * Returning false means "not mine" — the router keeps looking.
 *
 * Routes are tried in registration order, before the frontend_route hook and
 * before the configured homepage plugin's bootFrontend() fallback.
 */
class Router {
    private static array $routes = [];

    public static function add(string $pattern, callable $handler, string $method = 'GET'): void {
        self::$routes[] = [
            'method'  => strtoupper($method),
            'regex'   => self::compile($pattern),
            'handler' => $handler,
        ];
    }

    /**
     * Request path relative to the site root: '/' for home, '/events/spring' etc.
     */
    public static function path(): string {
        $uri  = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
        $uri  = is_string($uri) ? $uri : '/';
        $base = rtrim(str_replace(['/public', '/ja-admin'], '', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');

        if ($base !== '' && strpos($uri, $base) === 0) {
            $uri = substr($uri, strlen($base));
        }

        $path = '/' . trim($uri, '/');
        return $path === '/index.php' ? '/' : $path;
    }

    /**
     * Try every route against the current request.
     * @return bool true if a route handled the request
     */
    public static function dispatch($db): bool {
        $path   = self::path();
        $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

        foreach (self::$routes as $route) {
            if ($route['method'] !== $method) continue;
            if (!preg_match($route['regex'], $path, $m)) continue;

            $params = [];
            foreach ($m as $key => $value) {
                if (is_string($key)) $params[$key] = urldecode($value);
            }

            $result = call_user_func($route['handler'], $params, $db);
            if ($result === false) continue;

            if (is_array($result)) Content::set($result);
            return true;
        }
        return false;
    }

    private static function compile(string $pattern): string {
        $pattern = rtrim($pattern, '/');
        if ($pattern === '') $pattern = '/';

        $body = preg_replace_callback('/\{(\w+)\}|[^{]+/', function ($m) {
            if (isset($m[1]) && $m[1] !== '') {
                return '(?P<' . $m[1] . '>[^/]+)';
            }
            return preg_quote($m[0], '#');
        }, $pattern);

        return '#^' . $body . '/?$#';
    }
}
