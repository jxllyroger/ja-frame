<?php
namespace JA\Core;

/**
 * Small helpers for admin screens.
 */
class AdminUI {

    /**
     * A one-button POST form for state-changing row actions (enable, delete, …).
     * Using POST + the CSRF field keeps the token out of URLs, server logs and Referer headers,
     * and stops a link click or a prefetch from changing anything.
     *
     * Posts back to the current URL, so ?view=…&tab=…&menu=… are preserved.
     * The dashboard handles the action; row actions use $_POST['ja_action'] and $_POST['id'].
     *
     * $label is output as-is — pass a literal such as 'Delete' or '✕', never user input.
     */
    public static function postButton(string $label, string $action, array $fields, string $csrf, string $class = '', string $confirm = '', string $title = ''): string {
        $h = fn($s) => htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');

        $html  = "<form method='POST' class='ja-inline-form'>";
        $html .= "<input type='hidden' name='csrf' value='" . $h($csrf) . "'>";
        $html .= "<input type='hidden' name='ja_action' value='" . $h($action) . "'>";
        foreach ($fields as $name => $value) {
            $html .= "<input type='hidden' name='" . $h($name) . "' value='" . $h($value) . "'>";
        }

        $attrs = " class='" . $h($class) . "'";
        if ($title !== '') {
            $attrs .= " title='" . $h($title) . "'";
        }
        if ($confirm !== '') {
            $attrs .= ' onclick="return confirm(' . $h(json_encode($confirm)) . ')"';
        }

        $html .= "<button type='submit'{$attrs}>{$label}</button></form>";
        return $html;
    }
}
