<?php
namespace JA\Core;

class Mail {
    public static function sendMagicLink($email, $link) {
        $subject = "Your JA Admin Login Link";
        $host    = $_SERVER['HTTP_HOST'] ?? 'localhost';

        $message = "
        <html>
        <body style='font-family: sans-serif; line-height: 1.6; color: #333;'>
            <h2>JA Admin Login</h2>
            <p>Click the button below to log into your dashboard. This link expires in 15 minutes.</p>
            <p style='margin: 30px 0;'>
                <a href='$link' style='background: #000; color: #fff; padding: 12px 25px; text-decoration: none; border-radius: 5px;'>Log In to JA</a>
            </p>
            <p style='font-size: 12px; color: #999;'>If the button doesn't work, copy and paste this URL into your browser:<br>$link</p>
        </body>
        </html>
        ";

        $headers   = [];
        $headers[] = 'MIME-Version: 1.0';
        $headers[] = 'Content-type: text/html; charset=UTF-8';
        $headers[] = 'From: JA Framework <noreply@' . $host . '>';

        return mail($email, $subject, $message, implode("\r\n", $headers));
    }
}
