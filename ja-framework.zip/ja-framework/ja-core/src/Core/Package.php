<?php
namespace JA\Core;

/**
 * Safe zip installer shared by plugins and themes.
 *
 * A package must contain exactly one top-level folder whose name is a valid id
 * (lowercase letters, numbers, hyphens) and which holds the package's main file.
 * Every entry is checked BEFORE anything is extracted.
 */
class Package {

    /**
     * @param array    $upload     One entry of $_FILES.
     * @param string   $dest_base  Absolute directory the package folder is extracted into.
     * @param callable $main_for   fn(string $id): string — main file path inside the package folder.
     * @param array    $protected  Ids that can never be installed (core components).
     * @return array{ok:bool, message:string, id?:string}
     */
    public static function install(array $upload, string $dest_base, callable $main_for, array $protected = []): array {
        if (($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            return self::fail('Upload failed.');
        }
        if (strtolower(pathinfo($upload['name'] ?? '', PATHINFO_EXTENSION)) !== 'zip') {
            return self::fail('The file must be a .zip.');
        }
        if (!class_exists('ZipArchive')) {
            return self::fail('The PHP zip extension is not available on this server.');
        }

        $zip = new \ZipArchive();
        if ($zip->open($upload['tmp_name']) !== true) {
            return self::fail('Could not open the zip file.');
        }

        $root    = null;
        $entries = [];

        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = (string) $zip->getNameIndex($i);
            if ($name === '') continue;

            // Ignore macOS metadata
            if (strpos($name, '__MACOSX/') === 0 || basename($name) === '.DS_Store') continue;

            // Reject anything that could escape the destination
            if (strpos($name, "\0") !== false
                || strpos($name, '\\') !== false
                || $name[0] === '/'
                || preg_match('#^[A-Za-z]:#', $name)
                || preg_match('#(^|/)\.\.(/|$)#', $name)) {
                $zip->close();
                return self::fail('The zip contains an unsafe file path.');
            }

            if (strpos($name, '/') === false) {
                $zip->close();
                return self::fail('The zip must contain a single folder, not loose files.');
            }

            $top = substr($name, 0, strpos($name, '/'));
            if ($root === null) {
                $root = $top;
            } elseif ($top !== $root) {
                $zip->close();
                return self::fail('The zip must contain exactly one top-level folder.');
            }

            $entries[] = $name;
        }

        if ($root === null || !preg_match('/^[a-z0-9]+(-[a-z0-9]+)*$/', $root)) {
            $zip->close();
            return self::fail('The folder name may only use lowercase letters, numbers and hyphens.');
        }

        if (in_array($root, $protected, true)) {
            $zip->close();
            return self::fail("“{$root}” is a core component and cannot be replaced.");
        }

        $main = $root . '/' . $main_for($root);
        if ($zip->locateName($main) === false) {
            $zip->close();
            return self::fail("The zip is missing its main file ({$main}).");
        }

        $dest_base = rtrim($dest_base, '/');
        $dest      = $dest_base . '/' . $root;
        if (file_exists($dest)) {
            $zip->close();
            return self::fail("“{$root}” is already installed. Remove it first to install a new copy.");
        }

        if (!$zip->extractTo($dest_base, $entries)) {
            $zip->close();
            if (is_dir($dest)) self::removeDir($dest, $dest_base);
            return self::fail('Extraction failed — check folder permissions.');
        }
        $zip->close();

        return ['ok' => true, 'message' => '', 'id' => $root];
    }

    /**
     * Delete a directory, but only if it really lives inside $base.
     */
    public static function removeDir(string $dir, string $base): bool {
        $real_base = realpath($base);
        $real      = realpath($dir);
        if ($real_base === false || $real === false) return false;
        if (strpos($real, $real_base . DIRECTORY_SEPARATOR) !== 0) return false;

        self::rrmdir($real);
        return !is_dir($real);
    }

    private static function rrmdir(string $dir): void {
        foreach (scandir($dir) as $item) {
            if ($item === '.' || $item === '..') continue;
            $path = $dir . '/' . $item;
            if (is_dir($path) && !is_link($path)) {
                self::rrmdir($path);
            } else {
                unlink($path);
            }
        }
        rmdir($dir);
    }

    private static function fail(string $message): array {
        return ['ok' => false, 'message' => $message];
    }
}
