<?php
/**
 * JA Framework - Core Configuration
 */
define('JA_ROOT', dirname(__DIR__, 3));

// Dynamic URL discovery
$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https' : 'http';
$host     = $_SERVER['HTTP_HOST'] ?? 'localhost';
$base     = $protocol . '://' . $host . rtrim(
    str_replace(['/public', '/ja-admin'], '', dirname($_SERVER['SCRIPT_NAME'] ?? '/')),
    '/'
);
define('JA_BASE_URL', $base);

// The admin panel, the login page and the command line always read options straight from MySQL.
// Only the public site may use an options cache driver (see OptionsBackend). The path check is a
// safety net in case an entry script forgets to define JA_BYPASS_CACHE.
$ja_script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
if (defined('JA_BYPASS_CACHE')
    || PHP_SAPI === 'cli'
    || strpos($ja_script, '/ja-admin/') !== false
    || basename($ja_script) === 'ja-login.php') {
    \JA\Core\Options::bypassCache();
}

// Optional options-cache driver. A plugin (for example Redis Cache) installs ja-content/options-cache.php,
// which registers itself with Options::useBackend(). The core ships no driver, so by default
// nothing is cached. A broken driver is logged and ignored.
$ja_dropin = JA_ROOT . '/ja-content/options-cache.php';
if (is_file($ja_dropin)) {
    try {
        require $ja_dropin;
    } catch (\Throwable $e) {
        error_log('JA options-cache driver failed to load: ' . $e->getMessage());
    }
}
unset($ja_dropin);

// Load all options in one query (or from the cache driver on the public site), then read the timezone
\JA\Core\Options::load();
$tz = \JA\Core\Options::get('timezone', 'UTC');
date_default_timezone_set($tz);
