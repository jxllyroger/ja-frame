<?php
/**
 * JA Framework - Core Configuration
 */
define('JA_ROOT', dirname(__DIR__, 3));

// Dynamic URL discovery
$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https' : 'http';
$host     = $_SERVER['HTTP_HOST'] ?? 'localhost';
$base     = $protocol . '://' . $host . rtrim(
    str_replace(['/public', '/ja-admin'], '', dirname($_SERVER['SCRIPT_NAME'] ?? '/')),
    '/'
);
define('JA_BASE_URL', $base);

// Load all options in one query, then use the cache for timezone
// This replaces the previous separate timezone query with a shared load
\JA\Core\Options::load();
$tz = \JA\Core\Options::get('timezone', 'UTC');
date_default_timezone_set($tz);
