<?php
/**
 * JA Framework - Core Configuration
 */
define('JA_ROOT', dirname(__DIR__, 3));

// Settings from .env that are needed before the database is read
$ja_env = \JA\Core\Env::all();

// The site address. If SITE_URL is set in .env it is used as it is, so a forged Host header can never
// change the links in sign-in emails. Otherwise it is detected from the request (with the host name checked).
$ja_site_url = rtrim($ja_env['SITE_URL'] ?? '', '/');
if ($ja_site_url !== '' && strtolower($ja_site_url) !== 'auto'
    && preg_match('#^https?://[A-Za-z0-9.\-\[\]:]+(/[^\s?\#]*)?$#D', $ja_site_url)) {
    define('JA_BASE_URL', $ja_site_url);
    define('JA_SITE_URL_PINNED', true);
} else {
    $ja_host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    if (!preg_match('/^(\[[0-9a-fA-F:.]+\]|[A-Za-z0-9.\-]+)(:\d{1,5})?$/D', $ja_host)) $ja_host = 'localhost';

    define('JA_BASE_URL',
        (\JA\Core\Session::isHttps() ? 'https' : 'http') . '://' . $ja_host
        . rtrim(str_replace(['/public', '/ja-admin'], '', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/')
    );
    define('JA_SITE_URL_PINNED', false);
}

// How long a sign-in link stays valid, in seconds (300 to 3600)
define('JA_LINK_TTL', max(300, min(3600, (int) ($ja_env['MAGIC_LINK_TTL'] ?? 900))));

// The admin panel, the login page and the command line always read options straight from MySQL.
// Only the public site may use an options cache driver (see OptionsBackend). The path check is a
// safety net in case an entry script forgets to define JA_BYPASS_CACHE.
$ja_script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
if (defined('JA_BYPASS_CACHE')
    || PHP_SAPI === 'cli'
    || strpos($ja_script, '/ja-admin/') !== false
    || basename($ja_script) === 'ja-login.php') {
    \JA\Core\Options::bypassCache();
}

// Optional options-cache driver. A plugin (for example Redis Cache) installs ja-content/options-cache.php,
// which registers itself with Options::useBackend(). The core ships no driver, so by default
// nothing is cached. A broken driver is logged and ignored.
$ja_dropin = JA_ROOT . '/ja-content/options-cache.php';
if (is_file($ja_dropin)) {
    try {
        require $ja_dropin;
    } catch (\Throwable $e) {
        error_log('JA options-cache driver failed to load: ' . $e->getMessage());
    }
}
unset($ja_dropin);

// Load all options in one query (or from the cache driver on the public site), then read the timezone
\JA\Core\Options::load();
$tz = \JA\Core\Options::get('timezone', 'UTC');
date_default_timezone_set($tz);
