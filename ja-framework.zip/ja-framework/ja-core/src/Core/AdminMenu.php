<?php
namespace JA\Core;

/**
 * Admin sidebar entries added by plugins (from init()).
 *
 *   AdminMenu::add('Events', 'events', '📅');   // links to ?view=events
 *
 * The slug must match the plugin's admin view: ?view=<slug> loads JA\Plugins\<Slug>::renderAdmin().
 */
class AdminMenu {
    private static array $items = [];

    public static function add(string $label, string $slug, string $icon = '📄'): void {
        self::$items[] = ['label' => $label, 'slug' => $slug, 'icon' => $icon];
    }

    public static function items(): array {
        return self::$items;
    }
}
