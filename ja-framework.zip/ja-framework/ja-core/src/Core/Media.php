<?php
namespace JA\Core;

class Media {
    private static $allowed_ext  = ['jpg', 'jpeg', 'png', 'gif', 'ico', 'svg'];
    private static $allowed_mime = [
        'image/jpeg', 'image/png', 'image/gif',
        'image/x-icon', 'image/vnd.microsoft.icon',
        'image/svg+xml',
    ];

    public static function upload($file, $db) {
        if ($file['error'] !== UPLOAD_ERR_OK) return false;

        $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($file_ext, self::$allowed_ext)) return false;

        // MIME check via finfo — catches renamed files
        $finfo     = new \finfo(FILEINFO_MIME_TYPE);
        $mime_type = $finfo->file($file['tmp_name']);
        if (!in_array($mime_type, self::$allowed_mime)) return false;

        // Strip SVG of script tags and event attributes before saving
        if ($file_ext === 'svg') {
            $svg = file_get_contents($file['tmp_name']);
            $svg = preg_replace('/<script[\s\S]*?<\/script>/i', '', $svg);
            $svg = preg_replace('/\bon\w+\s*=\s*["\'][^"\']*["\']/i', '', $svg);
            file_put_contents($file['tmp_name'], $svg);
        }

        // Organise into year/month subdirectory
        $subdir     = date('Y/m');
        $target_dir = JA_ROOT . "/public/uploads/{$subdir}/";
        if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);

        $new_filename = 'ja_' . bin2hex(random_bytes(8)) . '.' . $file_ext;
        $stored_path  = $subdir . '/' . $new_filename;
        $target_file  = $target_dir . $new_filename;

        if (move_uploaded_file($file['tmp_name'], $target_file)) {
            $stmt = $db->prepare(
                "INSERT INTO ja_media (filename, original_name, file_type, file_size) VALUES (?, ?, ?, ?)"
            );
            $stmt->execute([$stored_path, $file['name'], $mime_type, $file['size']]);
            return $db->lastInsertId();
        }
        return false;
    }

    public static function delete($id, $db) {
        $stmt = $db->prepare("SELECT filename FROM ja_media WHERE id = ?");
        $stmt->execute([(int)$id]);
        $row = $stmt->fetch();
        if (!$row) return false;

        // Delete DB record first — if this fails we still have the file
        $stmt = $db->prepare("DELETE FROM ja_media WHERE id = ?");
        $stmt->execute([(int)$id]);

        // Then remove the physical file
        $path = JA_ROOT . '/public/uploads/' . $row['filename'];
        if (file_exists($path)) unlink($path);

        return true;
    }

    /**
     * Purge expired and used auth tokens to keep the table lean.
     * Call periodically — dashboard.php runs this on ~1% of requests.
     */
    public static function pruneTokens($db) {
        // Keep used tokens for 30 days (login history on dashboard)
        // Purge unused expired tokens after 1 day
        $db->exec(
            "DELETE FROM ja_auth_tokens WHERE 
            (used = 1 AND used_at < NOW() - INTERVAL 30 DAY) OR
            (used = 0 AND expires_at < NOW() - INTERVAL 1 DAY)"
        );
    }

    public static function getAll($db) {
        return $db->query("SELECT * FROM ja_media ORDER BY uploaded_at DESC")->fetchAll();
    }
}
