<?php
namespace JA\Core;

/**
 * The page the front end is about to render.
 *
 * Router handlers, the frontend_route hook and a homepage plugin's bootFrontend() call
 * Content::set(['title' => …, 'content' => …]); index.php hands whatever is set to the theme
 * as $ja_page.
 */
class Content {
    private static mixed $page = null;

    public static function set(mixed $page): void {
        self::$page = $page;
    }

    public static function get(): mixed {
        return self::$page;
    }
}
