<?php
namespace JA\Core;

/**
 * Per-theme options.
 *
 * A theme declares options in theme.json:
 *
 *   "options": {
 *     "content_width": { "label": "Content width", "type": "number", "default": "900", "unit": "px", "min": 600, "max": 1600 },
 *     "show_banner":   { "label": "Show banner",   "type": "checkbox", "default": "1" },
 *     "footer_text":   { "label": "Footer text",   "type": "text", "default": "Hello" },
 *     "accent":        { "label": "Accent colour", "type": "color", "default": "#2563eb" },
 *     "layout":        { "label": "Layout", "type": "select", "default": "wide", "choices": { "wide": "Wide", "narrow": "Narrow" } }
 *   }
 *
 * Types: text, textarea, checkbox, color, number, select. Admins edit them under Themes → Customize.
 *
 * In a template:      Theme::option('footer_text')      Theme::enabled('show_banner')
 * In the theme's CSS: color and number options are exposed as CSS variables on :root, named after the
 *                     key with underscores as hyphens:  var(--content-width), var(--accent)
 *                     (number options get their "unit" appended, e.g. 900px).
 */
class Theme {
    private static string $current = 'default';
    private static bool   $booted  = false;

    public static function setCurrent(string $theme_id): void {
        self::$current = $theme_id;
    }

    public static function current(): string {
        return self::$current;
    }

    /** Print the CSS variables in <head> (the theme must fire the 'head' hook, as all do). */
    public static function boot(): void {
        if (self::$booted) return;
        self::$booted = true;
        Hooks::action('head', [self::class, 'printVars']);
    }

    /**
     * Option definitions from the theme's theme.json, cleaned up.
     * @return array<string, array{label:string,type:string,default:string,help:string,unit:string,choices:array,min:?float,max:?float}>
     */
    public static function schema(string $theme_id): array {
        $file = JA_ROOT . '/ja-themes/' . basename($theme_id) . '/theme.json';
        if (!is_file($file)) return [];

        $data = json_decode((string) file_get_contents($file), true);
        $raw  = (is_array($data) && isset($data['options']) && is_array($data['options'])) ? $data['options'] : [];

        $types  = ['text', 'textarea', 'checkbox', 'color', 'number', 'select'];
        $schema = [];

        foreach ($raw as $key => $def) {
            if (!is_string($key) || !preg_match('/^[a-z][a-z0-9_]*$/', $key) || !is_array($def)) continue;

            $type = (isset($def['type']) && in_array($def['type'], $types, true)) ? $def['type'] : 'text';

            $schema[$key] = [
                'label'   => (isset($def['label']) && is_string($def['label'])) ? $def['label'] : $key,
                'type'    => $type,
                'default' => (isset($def['default']) && is_scalar($def['default'])) ? (string) $def['default'] : '',
                'help'    => (isset($def['help']) && is_string($def['help'])) ? $def['help'] : '',
                'unit'    => isset($def['unit']) && is_string($def['unit']) ? preg_replace('/[^a-zA-Z%]/', '', $def['unit']) : '',
                'choices' => (isset($def['choices']) && is_array($def['choices'])) ? array_map('strval', $def['choices']) : [],
                'min'     => (isset($def['min']) && is_numeric($def['min'])) ? (float) $def['min'] : null,
                'max'     => (isset($def['max']) && is_numeric($def['max'])) ? (float) $def['max'] : null,
            ];
        }
        return $schema;
    }

    /** Saved value, falling back to theme.json's default, then to $default. */
    public static function option(string $key, string $default = '', ?string $theme_id = null): string {
        $theme_id = $theme_id ?? self::$current;
        $schema   = self::schema($theme_id);
        $fallback = isset($schema[$key]) ? $schema[$key]['default'] : $default;

        $unset  = "\0unset";
        $stored = Options::get(self::optionKey($theme_id, $key), $unset);
        return ($stored === $unset || !is_string($stored)) ? $fallback : $stored;
    }

    /** For checkbox options. */
    public static function enabled(string $key, ?string $theme_id = null): bool {
        return self::option($key, '0', $theme_id) === '1';
    }

    /** Validate and store a submitted options form (fields named opt_<key>). */
    public static function saveOptions(string $theme_id, array $post): void {
        foreach (self::schema($theme_id) as $key => $def) {
            $raw = $post['opt_' . $key] ?? null;

            switch ($def['type']) {
                case 'checkbox':
                    $value = (is_string($raw) && $raw === '1') ? '1' : '0';
                    break;
                case 'color':
                    $value = (is_string($raw) && preg_match('/^#[0-9a-fA-F]{6}$/', $raw)) ? $raw : $def['default'];
                    break;
                case 'number':
                    if (!is_string($raw) || !is_numeric($raw)) { $value = $def['default']; break; }
                    $n = (float) $raw;
                    if ($def['min'] !== null) $n = max($n, $def['min']);
                    if ($def['max'] !== null) $n = min($n, $def['max']);
                    $value = (string) $n;
                    break;
                case 'select':
                    $value = (is_string($raw) && isset($def['choices'][$raw])) ? $raw : $def['default'];
                    break;
                default:
                    $value = is_string($raw) ? trim($raw) : $def['default'];
            }

            Options::set(self::optionKey($theme_id, $key), $value);
        }
    }

    public static function printVars(): void {
        $vars = '';
        foreach (self::schema(self::$current) as $key => $def) {
            if ($def['type'] !== 'color' && $def['type'] !== 'number') continue;

            $value = self::option($key);
            if ($def['type'] === 'color') {
                if (!preg_match('/^#[0-9a-fA-F]{3,8}$/', $value)) continue;
            } else {
                if (!is_numeric($value)) continue;
                $value .= $def['unit'];
            }
            $vars .= '--' . str_replace('_', '-', $key) . ':' . $value . ';';
        }

        if ($vars !== '') {
            echo '<style id="ja-theme-vars">:root{' . $vars . "}</style>\n";
        }
    }

    private static function optionKey(string $theme_id, string $key): string {
        return 'theme_' . str_replace('-', '_', $theme_id) . '_' . $key;
    }
}
