<?php
namespace JA\Core;

/**
 * Menus shown on the public site (stored in the 'menus' option).
 * Themes call SiteMenus::get('primary') / get('footer'); the Menus plugin edits them.
 */
class SiteMenus {

    /**
     * Items for a named location ('primary' or 'footer'), or null if nothing is assigned,
     * the menu is disabled, or it has no items. Runs the 'menu_items' filter.
     */
    public static function get(string $slot = 'primary'): ?array {
        $assigned_key = Options::get('menu_slot_' . $slot, '');
        if (!$assigned_key) return null;

        $menu = self::all()[$assigned_key] ?? null;
        if (!$menu || empty($menu['enabled']) || empty($menu['items'])) return null;

        // Strip internal _key markers before passing to theme/filter
        $items = array_map(function ($item) {
            unset($item['_key']);
            return $item;
        }, $menu['items']);

        return Hooks::apply('menu_items', $items, $slot);
    }

    public static function all(): array {
        return json_decode(Options::get('menus', '{}'), true) ?: [];
    }

    public static function save(array $menus): void {
        Options::set('menus', json_encode($menus));
    }
}
