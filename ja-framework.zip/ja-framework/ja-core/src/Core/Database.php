<?php
namespace JA\Core;

use PDO;
use PDOException;

class Database {
    private static $instance = null;

    public static function getConnection() {
        if (self::$instance === null) {
            $env_path = Env::path();

            if (!is_file($env_path)) {
                die("JA Framework Error: .env file not found at " . $env_path);
            }

            $env = Env::all();
            foreach (['DB_HOST', 'DB_NAME', 'DB_USER'] as $required) {
                if (!isset($env[$required]) || $env[$required] === '') {
                    die("JA Framework Error: {$required} is missing from " . $env_path);
                }
            }
            $env['DB_PASS'] = $env['DB_PASS'] ?? '';
            
            try {
                $dsn = "mysql:host={$env['DB_HOST']};dbname={$env['DB_NAME']};charset=utf8mb4";
                self::$instance = new PDO($dsn, $env['DB_USER'], $env['DB_PASS'], [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]);
            } catch (PDOException $e) {
                die("JA Framework Connection Error: " . $e->getMessage());
            }
        }
        return self::$instance;
    }
}

