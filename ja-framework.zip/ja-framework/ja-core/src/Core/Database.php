<?php
namespace JA\Core;

use PDO;
use PDOException;

class Database {
    private static $instance = null;

    public static function getConnection() {
        if (self::$instance === null) {
            // Updated to go up 3 levels to reach the root .env
            $env_path = dirname(__DIR__, 3) . '/.env';
            $env = parse_ini_file($env_path);
            
            if (!$env) {
                die("JA Framework Error: .env file not found at " . $env_path);
            }
            
            try {
                $dsn = "mysql:host={$env['DB_HOST']};dbname={$env['DB_NAME']};charset=utf8mb4";
                self::$instance = new PDO($dsn, $env['DB_USER'], $env['DB_PASS'], [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]);
            } catch (PDOException $e) {
                die("JA Framework Connection Error: " . $e->getMessage());
            }
        }
        return self::$instance;
    }
}

