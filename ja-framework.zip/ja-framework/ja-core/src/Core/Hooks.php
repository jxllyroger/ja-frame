<?php
namespace JA\Core;

/**
 * JA Framework — Hooks
 *
 * Two systems in one class:
 *
 * ACTIONS — fire registered callbacks at named points.
 *   Hooks::action('head', [MyPlugin::class, 'injectMeta']);
 *   Hooks::fire('head');
 *
 * FILTERS — pass a value through registered callbacks, each can modify it.
 *   Hooks::filter('page_content', [MyPlugin::class, 'addReadingTime']);
 *   $html = Hooks::apply('page_content', $html);
 *
 * Declared action slots:
 *   head, body_start, body_end, content_before, content_after,
 *   admin_head, admin_body_end, page_save, media_upload
 *
 * Declared filter slots:
 *   page_content, page_title, menu_items
 */
class Hooks {

    // ---------------------------------------------------------------
    // Action + filter registries
    // ---------------------------------------------------------------
    private static array $actions = [];
    private static array $filters = [];

    // ---------------------------------------------------------------
    // Legacy: admin sidebar menu items
    // ---------------------------------------------------------------
    private static array $admin_menu       = [];
    private static mixed $frontend_content = null;

    // ---------------------------------------------------------------
    // Actions
    // ---------------------------------------------------------------

    /**
     * Register a callback for an action slot.
     *
     * @param string   $slot      e.g. 'head', 'body_end'
     * @param callable $callback  Any callable — closure, [Class::class, 'method'], etc.
     * @param int      $priority  Lower runs first. Default 10.
     */
    public static function action(string $slot, callable $callback, int $priority = 10): void {
        self::$actions[$slot][$priority][] = $callback;
    }

    /**
     * Fire all callbacks registered to an action slot.
     * Any extra args are passed to each callback.
     */
    public static function fire(string $slot, mixed ...$args): void {
        if (empty(self::$actions[$slot])) return;
        ksort(self::$actions[$slot]); // run in priority order
        foreach (self::$actions[$slot] as $callbacks) {
            foreach ($callbacks as $cb) {
                call_user_func_array($cb, $args);
            }
        }
    }

    // ---------------------------------------------------------------
    // Filters
    // ---------------------------------------------------------------

    /**
     * Register a callback for a filter slot.
     * The callback receives the value as its first argument and must return it.
     */
    public static function filter(string $slot, callable $callback, int $priority = 10): void {
        self::$filters[$slot][$priority][] = $callback;
    }

    /**
     * Pass a value through all registered filter callbacks.
     * Returns the (potentially modified) value.
     */
    public static function apply(string $slot, mixed $value, mixed ...$args): mixed {
        if (empty(self::$filters[$slot])) return $value;
        ksort(self::$filters[$slot]);
        foreach (self::$filters[$slot] as $callbacks) {
            foreach ($callbacks as $cb) {
                $value = call_user_func_array($cb, [$value, ...$args]);
            }
        }
        return $value;
    }

    // ---------------------------------------------------------------
    // Admin sidebar menu
    // ---------------------------------------------------------------

    public static function add_menu_item(string $label, string $slug, string $icon = '📄'): void {
        self::$admin_menu[] = ['label' => $label, 'slug' => $slug, 'icon' => $icon];
    }

    public static function get_menu_items(): array {
        return self::$admin_menu;
    }

    // ---------------------------------------------------------------
    // Frontend content
    // ---------------------------------------------------------------

    public static function set_content(mixed $content): void {
        self::$frontend_content = $content;
    }

    public static function get_content(): mixed {
        return self::$frontend_content;
    }

    // ---------------------------------------------------------------
    // Site menus
    // ---------------------------------------------------------------

    /**
     * Get items for a named slot ('primary' or 'footer').
     * Applies the 'menu_items' filter before returning.
     */
    public static function get_menu(string $slot = 'primary'): ?array {
        $assigned_key = Options::get('menu_slot_' . $slot, '');
        if (!$assigned_key) return null;

        $all  = self::get_all_menus();
        $menu = $all[$assigned_key] ?? null;
        if (!$menu || empty($menu['enabled']) || empty($menu['items'])) return null;

        // Strip internal _key markers before passing to theme/filter
        $items = array_map(function($item) {
            unset($item['_key']);
            return $item;
        }, $menu['items']);

        return self::apply('menu_items', $items, $slot);
    }

    public static function get_all_menus(): array {
        return json_decode(Options::get('menus', '{}'), true) ?: [];
    }

    public static function save_menus(array $menus): void {
        Options::set('menus', json_encode($menus));
    }
}
