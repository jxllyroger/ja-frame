<?php
namespace JA\Core;

/**
 * JA Framework — Hooks
 *
 * Two systems in one class (actions and filters). Menus, shortcodes, the current
 * page and the admin sidebar now live in SiteMenus, Shortcodes, Content and AdminMenu;
 * the old Hooks::… names remain as deprecated delegates at the bottom of this file.
 *
 * ACTIONS — fire registered callbacks at named points.
 *   Hooks::action('head', [MyPlugin::class, 'injectMeta']);
 *   Hooks::fire('head');
 *
 * FILTERS — pass a value through registered callbacks, each can modify it.
 *   Hooks::filter('page_content', [MyPlugin::class, 'addReadingTime']);
 *   $html = Hooks::apply('page_content', $html);
 *
 * Declared action slots (extension points — fired by core, nothing in core listens
 * to most of them; plugins are expected to):
 *   head, body_start, body_end, content_before, content_after,
 *   admin_head, admin_body_end, page_save, media_upload, frontend_route
 *
 * For front-end URLs prefer Router::add(); for CSS/JS prefer Assets::style()/script().
 *
 * Declared filter slots:
 *   page_content, page_title, menu_items
 */
class Hooks {

    // ---------------------------------------------------------------
    // Action + filter registries
    // ---------------------------------------------------------------
    private static array $actions = [];
    private static array $filters = [];

    // ---------------------------------------------------------------
    // Actions
    // ---------------------------------------------------------------

    /**
     * Register a callback for an action slot.
     *
     * @param string   $slot      e.g. 'head', 'body_end'
     * @param callable $callback  Any callable — closure, [Class::class, 'method'], etc.
     * @param int      $priority  Lower runs first. Default 10.
     */
    public static function action(string $slot, callable $callback, int $priority = 10): void {
        self::$actions[$slot][$priority][] = $callback;
    }

    /**
     * Fire all callbacks registered to an action slot.
     * Any extra args are passed to each callback.
     */
    public static function fire(string $slot, mixed ...$args): void {
        if (empty(self::$actions[$slot])) return;
        ksort(self::$actions[$slot]); // run in priority order
        foreach (self::$actions[$slot] as $callbacks) {
            foreach ($callbacks as $cb) {
                call_user_func_array($cb, $args);
            }
        }
    }

    // ---------------------------------------------------------------
    // Filters
    // ---------------------------------------------------------------

    /**
     * Register a callback for a filter slot.
     * The callback receives the value as its first argument and must return it.
     */
    public static function filter(string $slot, callable $callback, int $priority = 10): void {
        self::$filters[$slot][$priority][] = $callback;
    }

    /**
     * Pass a value through all registered filter callbacks.
     * Returns the (potentially modified) value.
     */
    public static function apply(string $slot, mixed $value, mixed ...$args): mixed {
        if (empty(self::$filters[$slot])) return $value;
        ksort(self::$filters[$slot]);
        foreach (self::$filters[$slot] as $callbacks) {
            foreach ($callbacks as $cb) {
                $value = call_user_func_array($cb, [$value, ...$args]);
            }
        }
        return $value;
    }

    // ---------------------------------------------------------------
    // Deprecated delegates
    //
    // These used to live here. They moved to focused classes; the old names
    // still work so existing plugins and themes keep running, but new code
    // should call the classes directly:
    //
    //   add_menu_item / get_menu_items  → AdminMenu::add / items
    //   set_content / get_content       → Content::set / get
    //   get_menu / get_all_menus / save_menus → SiteMenus::get / all / save
    //   register_shortcode / do_shortcode     → Shortcodes::register / render
    // ---------------------------------------------------------------

    /** @deprecated Use AdminMenu::add() */
    public static function add_menu_item(string $label, string $slug, string $icon = '📄'): void { AdminMenu::add($label, $slug, $icon); }

    /** @deprecated Use AdminMenu::items() */
    public static function get_menu_items(): array { return AdminMenu::items(); }

    /** @deprecated Use Content::set() */
    public static function set_content(mixed $content): void { Content::set($content); }

    /** @deprecated Use Content::get() */
    public static function get_content(): mixed { return Content::get(); }

    /** @deprecated Use SiteMenus::get() */
    public static function get_menu(string $slot = 'primary'): ?array { return SiteMenus::get($slot); }

    /** @deprecated Use SiteMenus::all() */
    public static function get_all_menus(): array { return SiteMenus::all(); }

    /** @deprecated Use SiteMenus::save() */
    public static function save_menus(array $menus): void { SiteMenus::save($menus); }

    /** @deprecated Use Shortcodes::register() */
    public static function register_shortcode(string $tag, callable $callback): void { Shortcodes::register($tag, $callback); }

    /** @deprecated Use Shortcodes::render() */
    public static function do_shortcode(string $html): string { return Shortcodes::render($html); }
}
