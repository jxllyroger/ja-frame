<?php
namespace JA\Core;

/**
 * Reads the .env file in the site root.
 *
 * A small, forgiving reader, used instead of PHP's INI parser (which rejects a whole file over a single
 * odd character in a comment, or in a password that isn't quoted).
 *
 *   KEY=value            plain value; a trailing  # comment  is ignored
 *   KEY="a value"        quoted: spaces, # and ; are kept as they are. Inside double quotes, \" and \\ are escapes
 *   # comment, ; comment lines starting with # or ; are ignored, and may contain anything
 */
class Env {
    private static ?array $vars = null;

    public static function path(): string {
        return dirname(__DIR__, 3) . '/.env';
    }

    public static function all(): array {
        if (self::$vars !== null) return self::$vars;

        self::$vars = [];
        $file = self::path();
        if (!is_file($file)) return self::$vars;

        $lines = @file($file, FILE_IGNORE_NEW_LINES);
        if ($lines === false) return self::$vars;

        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || $line[0] === '#' || $line[0] === ';') continue;

            $pos = strpos($line, '=');
            if ($pos === false) continue;

            $key = trim(substr($line, 0, $pos));
            if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/D', $key)) continue;

            self::$vars[$key] = self::value(trim(substr($line, $pos + 1)));
        }
        return self::$vars;
    }

    public static function get(string $key, $default = null) {
        $vars = self::all();
        return array_key_exists($key, $vars) ? $vars[$key] : $default;
    }

    private static function value(string $raw): string {
        if ($raw === '') return '';

        $quote = $raw[0];
        if ($quote === '"' || $quote === "'") {
            // Quoted: runs to the closing quote (the last one on the line); anything after it is a comment
            $end = strrpos($raw, $quote);
            if ($end !== false && $end > 0) {
                $inner = substr($raw, 1, $end - 1);
                return $quote === '"' ? str_replace(['\\"', '\\\\'], ['"', '\\'], $inner) : $inner;
            }
        }

        // Plain: a "# comment" must be separated from the value by whitespace, so  pa#ss  stays intact
        $parts = preg_split('/\s+#/', $raw, 2);
        return rtrim($parts[0]);
    }
}
