<?php
namespace JA\Core;

/**
 * A pluggable cache for the options table.
 *
 * The core ships NO implementation, so nothing is cached by default. A plugin adds one by
 * installing ja-content/options-cache.php, which the core loads at startup (before options are
 * read) and which calls Options::useBackend(new YourBackend()).
 *
 * All methods must be safe: return null / do nothing on any failure rather than throw, so a
 * broken cache can never take the site down. The admin panel, the login page and the command
 * line never call fetch() or store(); they always read MySQL.
 */
interface OptionsBackend {
    /** The cached options, or null on a miss or any failure. */
    public function fetch(): ?array;

    /** Store a copy that was just loaded from the database. Only called after a fetch() miss. */
    public function store(array $options): void;

    /** Invalidate the cached copy. Called on every option write. */
    public function forget(): void;
}
