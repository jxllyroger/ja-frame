<?php
/**
 * JA Framework - PSR-4 Autoloader
 */
spl_autoload_register(function ($class) {
    $prefix = 'JA\\';
    $base_dir = dirname(__DIR__) . '/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) return;

    $relative_class = substr($class, $len);

    // 1. Map JA\Core\... to ja-core/src/Core/...
    $core_file = $base_dir . 'ja-core/src/' . str_replace('\\', '/', $relative_class) . '.php';
    if (file_exists($core_file)) {
        require_once $core_file;
        return;
    }

    // 2. Map JA\Plugins\Foo / JA\Plugins\MyPlugin to ja-plugins/ja-foo/ja-foo.php
    //    (or ja-plugins/my-plugin/my-plugin.php). Only enabled or core plugins are
    //    ever loaded this way, so a disabled plugin's classes can't be reached by
    //    URL (e.g. ?view=...) or by a class_exists() check.
    if (strpos($relative_class, 'Plugins\\') === 0) {
        $parts = explode('\\', $relative_class);
        $short = end($parts);
        $kebab = strtolower(preg_replace('/(?<!^)[A-Z]/', '-$0', $short));

        foreach (['ja-' . $kebab, $kebab] as $folder) {
            if (!\JA\Core\Plugins::isActive($folder)) continue;
            $file = $base_dir . 'ja-plugins/' . $folder . '/' . $folder . '.php';
            if (file_exists($file)) {
                require_once $file;
                return;
            }
        }
    }
});

require_once __DIR__ . '/src/Core/config.php';

