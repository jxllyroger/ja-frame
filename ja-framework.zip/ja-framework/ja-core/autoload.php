<?php
/**
 * JA Framework - PSR-4 Autoloader
 */
spl_autoload_register(function ($class) {
    $prefix = 'JA\\';
    $base_dir = dirname(__DIR__) . '/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) return;

    $relative_class = substr($class, $len);

    // 1. Map JA\Core\... to ja-core/src/Core/...
    $core_file = $base_dir . 'ja-core/src/' . str_replace('\\', '/', $relative_class) . '.php';
    if (file_exists($core_file)) {
        require_once $core_file;
        return;
    }

    // 2. Map JA\Plugins\... to ja-plugins/ja-xxx/ja-xxx.php
    if (strpos($relative_class, 'Plugins\\') === 0) {
        $parts = explode('\\', $relative_class);
        $plugin_name = strtolower(end($parts));
        $folder = 'ja-' . $plugin_name;
        $file = $base_dir . 'ja-plugins/' . $folder . '/' . $folder . '.php';
        if (file_exists($file)) {
            require_once $file;
        }
    }
});

require_once __DIR__ . '/src/Core/config.php';

