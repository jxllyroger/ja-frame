<?php
/**
 * JA Framework Plugin Skeleton
 * ============================
 * Rename the folder and file to ja-yourplugin/ja-yourplugin.php
 * Update the class name to match (ucfirst, no dashes).
 * Zip the folder and install from the Plugins page.
 */
namespace JA\Plugins;

use JA\Core\Hooks;
use JA\Core\Options;

class Myplugin {

    // ------------------------------------------------------------------
    // init() — called when the plugin is loaded.
    // Register sidebar menu, hook into actions/filters here.
    // ------------------------------------------------------------------
    public static function init(): void {
        // Add this plugin to the admin sidebar
        Hooks::add_menu_item('My Plugin', 'myplugin', '🔧');

        // Action: inject something into the <head> of every frontend page
        // Hooks::action('head', [self::class, 'injectHead']);

        // Action: run code after a page is saved
        // Hooks::action('page_save', [self::class, 'onPageSave']);

        // Action: run code after a file is uploaded
        // Hooks::action('media_upload', [self::class, 'onMediaUpload']);

        // Filter: modify page content before it renders
        // Hooks::filter('page_content', [self::class, 'filterContent']);

        // Filter: modify page title before it renders
        // Hooks::filter('page_title', [self::class, 'filterTitle']);

        // Filter: modify menu items before they render
        // Hooks::filter('menu_items', [self::class, 'filterMenuItems']);
    }

    // ------------------------------------------------------------------
    // Hook callbacks (uncomment and implement as needed)
    // ------------------------------------------------------------------

    // public static function injectHead(): void {
    //     echo '<meta name="my-plugin" content="active">';
    // }

    // public static function onPageSave(array $page): void {
    //     // $page has: id, title, slug, is_home, in_menu
    //     // e.g. clear a cache, ping a sitemap service, etc.
    // }

    // public static function onMediaUpload(int $id, string $original_name): void {
    //     // React to a new file being uploaded
    // }

    // public static function filterContent(string $content): string {
    //     // Modify the page HTML before it renders
    //     return $content;
    // }

    // public static function filterTitle(string $title): string {
    //     return $title . ' — My Site';
    // }

    // public static function filterMenuItems(array $items, string $slot): array {
    //     // $slot is 'primary' or 'footer'
    //     return $items;
    // }

    // ------------------------------------------------------------------
    // bootFrontend() — optional.
    // Implement this if the plugin drives the public homepage.
    // It will appear in Settings → Frontend → Homepage plugin.
    // ------------------------------------------------------------------
    // public static function bootFrontend($db): void {
    //     Hooks::set_content([
    //         'title'   => 'My Plugin Page',
    //         'content' => '<p>Hello from my plugin.</p>',
    //     ]);
    // }

    // ------------------------------------------------------------------
    // renderAdmin() — renders the admin page for this plugin.
    // $csrf is the current session token — embed in all forms.
    // ------------------------------------------------------------------
    public static function renderAdmin($db, string $csrf = ''): string {
        $html  = "<h1 class='ja-page-header'>My Plugin</h1>";
        $html .= "<div class='ja-card'>";
        $html .= "<h3>Settings</h3>";
        $html .= "<form method='POST'>";
        $html .= "<input type='hidden' name='csrf'      value='" . htmlspecialchars($csrf) . "'>";
        $html .= "<input type='hidden' name='ja_action' value='save_myplugin'>";

        // Example setting stored in ja_options
        $my_value = Options::get('myplugin_example', '');
        $html .= "<label class='ja-label'>Example setting</label>";
        $html .= "<input type='text' name='myplugin_example' class='ja-input' value='" . htmlspecialchars($my_value) . "'>";

        $html .= "<button type='submit' class='ja-btn ja-btn-primary'>Save</button>";
        $html .= "</form></div>";
        return $html;
    }

    // ------------------------------------------------------------------
    // handleSave() — called by dashboard on POST with ja_action matching.
    // Prefix your option keys with your plugin name to avoid collisions.
    // ------------------------------------------------------------------
    public static function handleSave($db, array $post): bool {
        // Only handle our own action
        if (($post['ja_action'] ?? '') !== 'save_myplugin') return false;

        // Save settings — use prefixed keys
        Options::set('myplugin_example', trim($post['myplugin_example'] ?? ''));

        return true;
    }
}
