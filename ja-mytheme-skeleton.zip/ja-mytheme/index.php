<?php
/**
 * JA Framework Theme Skeleton
 * ============================
 * Rename the folder to ja-yourtheme/
 * Update the stylesheet link to match.
 * Zip the folder and install from the Themes page.
 *
 * Available variables:
 *   $ja_page['title']   — page title (already filtered)
 *   $ja_page['content'] — page HTML content (already filtered)
 *
 * Available APIs:
 *   Options::get('site_name')       — any option from ja_options
 *   Hooks::get_menu('primary')      — items array or null
 *   Hooks::get_menu('footer')       — items array or null
 *   Hooks::fire('head')             — let plugins inject into <head>
 *   Hooks::fire('body_start')       — after <body>
 *   Hooks::fire('body_end')         — before </body>
 *   Hooks::fire('content_before')   — before page content
 *   Hooks::fire('content_after')    — after page content
 *   Hooks::apply('page_title', ...) — run title through filters
 *   Hooks::apply('page_content',..) — run content through filters
 *   JA_BASE_URL                     — site root URL (no trailing slash)
 */
use JA\Core\Options;
use JA\Core\Hooks;

$site_name = Options::get('site_name', 'My Site');
$site_lang = Options::get('site_lang', 'en');
$slogan    = Options::get('site_slogan', '');
$logo      = Options::get('site_logo', '');
$favicon   = Options::get('site_favicon', '');

$primary_nav = Hooks::get_menu('primary');
$footer_nav  = Hooks::get_menu('footer');

$page_title   = Hooks::apply('page_title',   $ja_page['title']   ?? '');
$page_content = Hooks::apply('page_content', $ja_page['content'] ?? '');
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($site_lang) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?> | <?= htmlspecialchars($site_name) ?></title>
    <?php if ($favicon): ?>
        <link rel="icon" href="<?= JA_BASE_URL ?>/uploads/<?= htmlspecialchars($favicon) ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="<?= JA_BASE_URL ?>/ja-themes/ja-mytheme/style.css">
    <?php Hooks::fire('head'); ?>
</head>
<body>
<?php Hooks::fire('body_start'); ?>

<header class="site-header">
    <div class="container">
        <a href="<?= JA_BASE_URL ?>/" class="site-brand">
            <?php if ($logo): ?>
                <img src="<?= JA_BASE_URL ?>/uploads/<?= htmlspecialchars($logo) ?>" alt="<?= htmlspecialchars($site_name) ?>">
            <?php endif; ?>
            <span class="site-name"><?= htmlspecialchars($site_name) ?></span>
            <?php if ($slogan): ?>
                <span class="site-slogan"><?= htmlspecialchars($slogan) ?></span>
            <?php endif; ?>
        </a>
        <?php if ($primary_nav): ?>
            <nav class="site-nav">
                <?php foreach ($primary_nav as $item): ?>
                    <a href="<?= htmlspecialchars($item['url']) ?>"><?= htmlspecialchars($item['label']) ?></a>
                <?php endforeach; ?>
            </nav>
        <?php endif; ?>
    </div>
</header>

<main class="site-main">
    <div class="container">
        <?php Hooks::fire('content_before', $ja_page); ?>
        <h1 class="page-title"><?= htmlspecialchars($page_title) ?></h1>
        <div class="page-content"><?= $page_content ?></div>
        <?php Hooks::fire('content_after', $ja_page); ?>
    </div>
</main>

<footer class="site-footer">
    <div class="container">
        <span>&copy; <?= date('Y') ?> <?= htmlspecialchars($site_name) ?></span>
        <?php if ($footer_nav): ?>
            <nav class="footer-nav">
                <?php foreach ($footer_nav as $item): ?>
                    <a href="<?= htmlspecialchars($item['url']) ?>"><?= htmlspecialchars($item['label']) ?></a>
                <?php endforeach; ?>
            </nav>
        <?php endif; ?>
    </div>
</footer>

<?php Hooks::fire('body_end'); ?>
</body>
</html>
